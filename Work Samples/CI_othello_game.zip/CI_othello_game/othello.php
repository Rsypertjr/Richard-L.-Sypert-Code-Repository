<?php
class Othello extends CI_Controller {
    
    
	public function __construct()
	{
        
            parent::__construct();  
            //  LOAD HELPERS AND LIBRARIES
            $this->load->helper('url'); 
            $this->load->helper('html');
            $this->load->helper('file');
            $this->load->helper('form');
            $this->load->library('form_validation');
            $this->load->helper('cookie');
         
            
           $this->data["boardRows"] = array( "........", "........", "........", "...XO...", "...OX...", "........", "........", "........");

           $this->data["twoDimBoard"] = array();
            $this->data["winner"] = null;
            $this->data["turnHash"] = "";
            //$gameId = $_POST["gameId"];
            $this->data["board"] = "";
            $this->data["round"] = 0;
            $this->data["turn"] = null;
            $this->data["randTurn"] = null;
            $this->data["playerKeyShaMap"] = array();
            
            $this->data["doc"] = new DOMDocument();
            $this->data["doc2"] = new DOMDocument();
            $this->data["doc"]->validateOnParse = true;
          
            $this->data["myinitboard"] = $this->load->view("othello/myinitboard","",TRUE);
            $this->data["doc2"]->loadHTML($this->data["myinitboard"]);
            $thebody = $this->data["doc2"]->getElementById('gboard');
            
            $file = "application/views/othello/myboard.php";             
            $fp = fopen($file, 'w');
            fwrite($fp, null);
            fclose($fp); 
         
            file_put_contents("application/views/othello/myboard.php",$this->data["doc2"]->saveXML($thebody));
         
            $this->data["myBoard"] = $this->load->view("othello/myboard","",TRUE);
            $this->data["doc"]->loadHTML($this->data["myBoard"]);
            $this->data["x"] = new DOMXPath($this->data["doc"]);
            
            $this->data["cells"] = array(); 
            $this->data["cellArray"] = array();
            for($i=1;$i<=8;$i++)
                {
                        $rows = $this->data["doc"]->getElementById("row".$i);
                        $this->data["cells"][$i-1] = $rows->getElementsByTagName("div");
                      $j= 0;
                     foreach($this->data["cells"][$i-1] as $cell)
                            {
                                $this->data["cellArray"][$i-1][$j] = $cell->nodeValue;
                                $j++;
                            }                  
                }
        
            $this->data["rows"] = array(	 $this->data["x"]->query("//*[@id='row1']")->item(0),
                                                             $this->data["x"]->query("//*[@id='row2']")->item(0),
                                                             $this->data["x"]->query("//*[@id='row3']")->item(0),
                                                             $this->data["x"]->query("//*[@id='row4']")->item(0),
                                                             $this->data["x"]->query("//*[@id='row5']")->item(0),
                                                             $this->data["x"]->query("//*[@id='row6']")->item(0),
                                                             $this->data["x"]->query("//*[@id='row7']")->item(0),
                                                             $this->data["x"]->query("//*[@id='row8']")->item(0)
                                                         );

            $this->data["flipSpaces"] = array();

            $this->data["possibleMoves"] = array();
            //$this->data["emptySpaces"] = array();
            $this->data["randMove"] = array();
            $this->data["player"] = array();
            $this->data["player"][0][0] = 2;
            $this->data["player"][0][1] = 3;
            $this->data["player"][0][2] = 'O';
            $this->data["player"][1][0] = 4;
            $this->data["player"][1][1] = 2;
            $this->data["player"][1][2] = 'O';
            $this->data["message"] = "";
                
            $this->data["count"]=0;
            $this->data["symbol"] = 'O';
            $this->data["gamebegin"] = 0;
            
            $this->data["cheight"]= 80;
        
            $this->data["playr1Key"] = "richardlsypertjr";
            $this->data["playr2Key"] = "autoplayer";
          // $this->data["twoDimBoard"] = $this->getTwoDimBoard($this->data["boardRows"]);  
           $this->data["twoDimBoard"] = $this->data["cellArray"];
           
           //print_r( $this->data["twoDimBoard"]);
         
           // Clear Boards
            $this->printBoard($this->data["twoDimBoard"],$this->data["cells"],$this->data["doc"]);
            $this->data['css'] = "http://".base_url('css/othello2.css');
            $this->data['jqueryloc']="http://".base_url('assets/js/jquery-1.10.2.js');
            $this->data['jqfile']="http://".base_url('assets/js/global.js');
            $this->data['cellpost']= "http://". site_url('othello/index'); 
            
           
      /*Generate JSON
                  $jsonString = '{"winner":'.$winner.
                        ',"turnHash":'.$turnHash.
                        ',"gameId":'.$gameId.
                        ',"board": ["'.implode($twoDimBoard[0]).
                        '","'.implode($twoDimBoard[1]).
                        '","'.implode($twoDimBoard[2]).
                        '","'.implode($twoDimBoard[3]).
                        '","'.implode($twoDimBoard[4]).
                        '","'.implode($twoDimBoard[5]).
                        '","'.implode($twoDimBoard[6]).
                        '","'.implode($twoDimBoard[7]).
                        '"],"round":'.$round.
                        ',"turn":'.$turn.
                        ',"playerKeyShaMap": {'.
                        $playr1Key.":".$turn.','.
                        $playr2Key.":".$randTurn.'}}';
                        
                        echo $jsonString;    */
    }

function index()
        { 
                // Initialize Player Input Board
             $this->data["display1"] = "none";
             $this->data["display2"] = "block";
             $this->data["display3"] = "block";
             $this->data["display4"] = "none";
          
             $this->data["cheight"] = "250";
             $this->data["message"] ="Press button to Play! Your Symbol is ".$this->data["symbol"]; 
                // Display Board
             $this->data["flag"] = 'no';  
             $this->load->view('othello/header',$this->data);
             $this->load->view('othello/myinitboard');
             $this->load->view('othello/footer');  
             
        }
    
    
    function playbegin()
    {  
                $this->load->helper('form');
                $this->load->library('form_validation');
                $this->form_validation->set_rules('xvalue', 'X Value', 'required');
                $this->form_validation->set_rules('yvalue', 'Y Value', 'required');
                
                $x = $this->input->post('xvalue');
                $y = $this->input->post('yvalue');
                $this->data["flag"] = 'no';  
                 if($this->form_validation->run() === FALSE)
                     {
                         // Display Last Board if Errors
                         $this->load->view('othello/header',$this->data);
                         $this->load->view('othello/myboard');
                         $this->load->view('othello/footer');
                 }
                 
                
              else if( $this->input->post('submit') == 'Press to Play' )
                      {    
                              $this->data["display1"] = "block";
                              $this->data["display2"] = "none";
                              $this->data["display3"] = "block";
                              $this->data["display4"] = "none";
                              
                              $symbol = $this->data["symbol"];
                              
                              $this->data["flag"] = 'no';  
                              $this->data["cheight"] = 130;
                              $this->data["message"]="Your symbol is '".$symbol."'. -- Input Coordinates or "."<br/><div id='clkspace' style='display:inline;color:brown'>**Click A Space**</div>"." for Your Move.";
                              $this->printBoard($this->data["twoDimBoard"],$this->data["cells"],$this->data["doc"]);	// Generate Board to html file
                              $this->load->view('othello/header',$this->data);
                              $this->load->view('othello/myboard');
                              $this->load->view('othello/footer');     
                              
                     }
             else if( $this->input->post('submit') == 'Press to Continue' )
                      {
                              if($this->data["symbol"]== 'X')
                                        $this->data["symbol"]= 'O';
                              else if($this->data["symbol"]== 'O')
                                        $this->data["symbol"]= 'X';
                             
                              $this->com_player();         
                       
                  }  
            else if($this->input->post('submit') == 'Submit This Move')
                      {          
                               $this->playermove($x,$y,$this->input->post('hid') );
                      }      
          
             
        
        }
    
    
        


function check()
{
        header('Content-type: application/x-javascript');
        function execute() 
        {
            jQFunction();
        }
        execute();

    }  
    

    
   function getboardInverse()
   {
        $file = file_get_contents("application/views/othello/thebody2.php");
           file_put_contents("application/views/othello/myboard.php",$file);
           
          $myboard= $this->load->view("othello/myboard","",TRUE);
            $doc = new DOMDocument();
            $doc->loadHTML($myboard);
         
            $cells= array(); 
            $cellArray = array();
            for($i=1;$i<=8;$i++)
                {
                       $rows = $doc->getElementById("row".$i);
                       $cells = $rows->getElementsByTagName("div");
                      $j= 0;
                    foreach($cells as $cell)
                          {
                            $cellArray[$j][$i-1] = $cell->nodeValue;          //Flip Board Indices between players
                                                                                                     // Because computer player algorithm is nested loop          
                            
                           $j++;
                        }                  
            }   
       
            return $cellArray;
       }
    
   function com_player()
       {
        // Retrieving the board
           $this->data["twoDimBoard"] = $this->getboardInverse();
           $name = "boardArray";
 
        //  print_r($this->data["twoDimBoard"]);  
           
           $this->data["emptySpaces"] = $this->getEmptySpaces($this->data["twoDimBoard"]);
          // print_r($this->data["emptySpaces"]);
           $this->data["possibleMoves"] = $this->getPossibleMoves($this->data["emptySpaces"],$this->data["symbol"],$this->data["twoDimBoard"]);  // Get Open Spaces on Board for moves
          //print_r($this->data["possibleMoves"]);
           
            if(count($this->data["possibleMoves"]) > 0)   // If good moves exist
            {
                  foreach($this->data["possibleMoves"]  as $move)
                    {   
                                  $x = $move[0];
                                  $y = $move[1];
                                  $this->data["symbol"] = $move[2];
                                  $symbol =  $this->data["symbol"];
                                  $oflipSpaces = $this->verifyMove($x,$y,$symbol,$this->data["twoDimBoard"]);
                                   //print_r($this->data["flipSpaces"]);
                                   
                                  if($oflipSpaces != null)
                                            {
                                                $oflipSpaces = array_slice( $oflipSpaces ,1, (count( $oflipSpaces ) -1)   );
                                            }
                                   
                                  foreach($oflipSpaces as $boardspace)
                                        {
                                                        $x = $boardspace[0];
                                                        $y = $boardspace[1];
                                                        $symbol =  $boardspace[2];
                                    
                                                        $this->data["flipSpaces"] = $this->verifyMove($x,$y,  $symbol ,$this->data["twoDimBoard"]);
                                                        $this->data["flipSpaces"] = array_slice($this->data["flipSpaces"],1, (count($this->data["flipSpaces"]) -1)   );
                                                         
                                                        // print_r($this->data["flipSpaces"] );
                                                        if( isset($this->data["flipSpaces"][2]))
                                                            { 
                                                                   $this->data["twoDimBoard"] = $this->updateGameBoard($this->data["flipSpaces"],$this->data["twoDimBoard"]); // Update Game Board	
                                                                   $this->printBoard($this->data["twoDimBoard"],$this->data["cells"],$this->data["doc"]);	// Generate Board to html file
                                                              
                                                                 // Display Board
                                                                      $this->data["display1"] = "block";
                                                                      $this->data["display2"] = "none";
                                                                      $this->data["display3"] = "block";
                                                                      $this->data["display4"] = "none";
                                                      
                                                                  $symbol = $this->data["symbol"];
                                                                  if($symbol == 'X')
                                                                                $this->data["symbol"]= 'O';
                                                                  else if($symbol == 'O')
                                                                                $this->data["symbol"]= 'X';
                                                                                
                                                                  $symbol = $this->data["symbol"];
                                                                  $this->data["flag"] = 'yes';  
                                                                  $this->data["cheight"] = 130;
                                                                  $this->data["message"]="Your symbol is '".$symbol."'. ------ Input Coordinates for Your Move.";
                                                                 
                                                                  $this->load->view('othello/header',$this->data);
                                                                  $this->load->view('othello/myboard');
                                                                  $this->load->view('othello/footer'); 
                                                                 
                                                                   // Save Board to File
                                                                   $file = file_get_contents("application/views/othello/myboard.php");
                                                                   file_put_contents("application/views/othello/thebody2.php",$file);
                                                                
                                                                  if($symbol == 'X')
                                                                                $this->data["symbol"]= 'O';
                                                                  else if($symbol == 'O')
                                                                                $this->data["symbol"]= 'X';
                                                                 return;
                                                    }
                                   }                
                     }
                }
            else  
                      {
                              $finScore = $this->calculateFinalScore();
                              if($finScore['O'] > $finScore['X'])
                                    $result = "SHUCKS!! YOU WIN";
                              else
                                    $result = "HA!  HA!  I WIN!!!!!!!";
                              $this->data["message"]= "<span id='prbutton' style='color:purple;font-size:150%'>!!!GAME OVER!!!</span> <br/>I CAN'T MOVE AGAIN<br/><span style='color:purple'> The Score is:<br/>O: ".$finScore['O'].' X: '.$finScore['X']."</span><br/>".$result;
                            
                               $this->data["display2"] = "none";
                               $this->data["display3"] = "block";
                               $this->data["display4"] = "none";
                               $this->data["display1"] = "none";
                               $this->data["cheight"]= 160;
                             
                               
                               $this->load->view('othello/header',$this->data);
                               $this->load->view('othello/myboard');
                               $this->load->view('othello/footer'); 
                        
                        }
                 
        }
  
  
function playermove($x,$y,$flag)
{        
            if($flag == 'yes')
                {
                        // Retrieving Board
                       $this->data["twoDimBoard"] =$this->getboardInverse();
                       //print_r($this->data["twoDimBoard"]);  
                }
         
            // Choose form elements to display
            $this->data["display1"] = "block";
            $this->data["display2"] = "none";
            $this->data["display3"] = "block";
            $this->data["display4"] = "none";
            $symbol = $this->data["symbol"];
         
           $oflipSpaces = $this->verifyMove($x,$y,$symbol,$this->data["twoDimBoard"]);
          //echo "<br/> x: ".$x." y: ".$y." sym: ".$symbol;
         
           if($oflipSpaces != null )
                        {
                            $oflipSpaces = array_slice( $oflipSpaces ,1, (count( $oflipSpaces ) -1)   );
                        }
                    $this->load->library('javascript');
         if( isset($oflipSpaces [2]))
            {    
               foreach($oflipSpaces as $boardspace)
                    {
                     
                        $x = $boardspace[0];
                        $y = $boardspace[1];
                        $symbol =  $boardspace[2]; 
                        
                        $this->data["flipSpaces"] = $this->verifyMove($x,$y,$symbol,$this->data["twoDimBoard"]);
                       //print_r($this->data["flipSpaces"]);
                        if($this->data["flipSpaces"] != null &&  (count($this->data["flipSpaces"]) >= 2 ))
                                {
                                    $this->data["flipSpaces"] = array_slice($this->data["flipSpaces"],1, (count($this->data["flipSpaces"]) -1)   );
                                }

                        if( isset($this->data["flipSpaces"][2]))
                                {    
                                       $this->data["twoDimBoard"] = $this->updateGameBoard($this->data["flipSpaces"],$this->data["twoDimBoard"]); // Update Game Board	
                                       //print_r( $this->data["twoDimBoard"] );
                                     
                                      // Generate Board
                                       $this->printBoard($this->data["twoDimBoard"],$this->data["cells"],$this->data["doc"]);	// Generate Board to html file
                                  
                                        $this->data["display1"] = "none";
                                        $this->data["display2"] = "block";
                                        $this->data["display3"] = "none";
                                        $this->data["display4"] = "block";
                                         $this->data["cheight"]= 150;
                                        $this->data["message"] ="This is Your move with symbol: '".$this->data["symbol"]."'.<br/><span id='prbutton' style='color:purple'>**Press Button**</span> for Computer Move"; 
                                        $this->data["flag"] = 'no';
                                       // Display Board
                                        $this->load->view('othello/header',$this->data);
                                        $this->load->view('othello/myboard');
                                        $this->load->view('othello/footer');  
                                      
                                      // Save Board to File
                                       $file = file_get_contents("application/views/othello/myboard.php");
                                       file_put_contents("application/views/othello/thebody2.php",$file);
                                  
                            }
                      
                    }
            }  
            else 
            {
           // Determine if any moves left     
           $this->data["emptySpaces"] = $this->getEmptySpaces($this->data["twoDimBoard"]);
          // print_r($this->data["emptySpaces"]);
           $this->data["possibleMoves"] = $this->getPossibleMoves($this->data["emptySpaces"],$this->data["symbol"],$this->data["twoDimBoard"]);  // Get Open Spaces on Board for moves
          //print_r($this->data["possibleMoves"]);      
                
            $isThereStillAMove = false;
            foreach($this->data["possibleMoves"]  as $move)
                    {   
                                  $x = $move[0];
                                  $y = $move[1];
                                  $this->data["symbol"] = $move[2];
                                  $symbol =  $this->data["symbol"];
                                  $oflipSpaces = $this->verifyMove($x,$y,$symbol,$this->data["twoDimBoard"]);
                                   //print_r($this->data["flipSpaces"]);
                                   
                                  if($oflipSpaces != null)
                                            {
                                                $oflipSpaces = array_slice( $oflipSpaces ,1, (count( $oflipSpaces ) -1)   );
                                        }
                                 if(count($oflipSpaces) > 0)
                                    $isThereStillAMove = true;
            
                     }
                
             
          
           $this->data["flag"] = 'yes';    // Post flag for next board screen type
           if($isThereStillAMove == true )
                    $this->data["message"]= "NOT A GOOD MOVE<br/>PLEASE TRY AGAIN !!!"."--Your symbol is '".$this->data["symbol"]."'";
           else
                    {
                        
                     $finScore = $this->calculateFinalScore();
                      if($finScore['O'] > $finScore['X'])
                            $result = "SHUCKS!! YOU WIN";
                      else 
                            $result = "HA!  HA!  I WIN!!!!!!!";
                            
                      $espaces = $this->data["emptySpaces"] = $this->getEmptySpaces($this->data["twoDimBoard"]);     
                      if(count($espaces) > 0)
                          $result = "HA! Since the Board is Not Full, <br/><span id='prbutton2' style='color:purple;font-size:150%'>!!YOU LOSE!! Despite The Score!!</span>";
                     
                      $this->data["message"]= "<span id='prbutton' style='color:purple;font-size:150%'>!!!GAME OVER!!!</span> <br/>It Appears You Have No Moves Left<br/><span style='color:purple'> The Score is:    O:".$finScore['O'].' X:'.$finScore['X']." </span><br/>".$result;
                      $this->data["display1"] = "none";
                      $this->data["display2"] = "none";
                      $this->data["display3"] = "block";
                      $this->data["display4"] = "none";
                    }
        
            $this->data["cheight"]= 140;
           $this->load->view('othello/header',$this->data);
           $this->load->view('othello/myboard');
           $this->load->view('othello/footer'); 

            }
}
   
   

function printBoard($twDimBoard,$cells,$dc)
{
	for($i=0;$i<8;$i++)
		{
                $j=0;
                foreach($cells[$i] as $cell)
                    {
                    $cell->nodeValue =  $twDimBoard[$j][$i];  //Transpose rows to columns
                    $this->data["cellArray"][$i][$j] = $twDimBoard[$i][$j]; 
                    $j++;
                }
        }
        //print_r($this->data["cellArray"]);
        $this->data["twoDimBoard"] = $this->data["cellArray"];
        //print_r( $this->data["twoDimBoard"] );
        $thebody = $dc->getElementById('gboard');
		file_put_contents("application/views/othello/myboard.php",$dc->saveHTML($thebody));
}	
 
   
public function message($to = 'World')
        {
            echo "Hello {$to}!".PHP_EOL;
        }
    
    
public function getTwoDimBoard($boardRows)
    {
           $boardRowArr = array();
            $twoDBoard = array();
            for( $i=0;$i < 8;$i++)
                {
                    $boardRowArr = str_split($boardRows[$i],1);
                    
                    //print_r($boardRows[$i]);
                    for( $j=0;$j<count($boardRowArr);$j++)
                        {
                            $twoDBoard[$i][$j] = $boardRowArr[$j];
                            
                        }
                }
                return $twoDBoard;  
    }
    

public function getTwoDimBoardSpace($x, $y, $twDimBoard)
       {
            for( $i=0;$i < 8;$i++)
                {
                    for( $j=0;$j<8;$j++)
                        {
                            if($i == $x && $j==$y)
                                return $twDimBoard[$i][$j];
                        }
                }

        }
    
  
function getEmptySpaces($twDimBoard)
        {
            $emptySpaces = array();
            $count = 0;
            for($i=0;$i<8;$i++)
                {
                    for( $j=0;$j<8;$j++)
                        {
                            if($twDimBoard[$i][$j] == '.')
                                {
                                    $emptySpaces[$count][0]=$i;
                                    $emptySpaces[$count][1]=$j;
                                    ++$count;
                                }
                        }
                }
            return $emptySpaces;
        }
  


function getPossibleMoves($emptySpaces,$symbol,$twDimBoard)
    {
        
        //echo count($emptySpaces);
        $goodMoves = array();
        $x=0;
        $y=0;
        $count = 0;
        //echo count($emptySpaces);
        for($i=0;$i<count($emptySpaces);$i++)
            {
                $x = $emptySpaces[$i][0];
                //
                $y = $emptySpaces[$i][1];
                $this->data["flipSpaces"] = $this->verifyMove($x,$y,$symbol,$twDimBoard); 
                
               if(count($this->data["flipSpaces"]) >=1 )
                    {  
                        $goodMoves[$count][0]=$x;
                        $goodMoves[$count][1]=$y;
                        $goodMoves[$count][2]=$symbol;
                        ++$count;
                     }
            }
           return $goodMoves;
}

  
  
  
// Send 2-d array with the first index being for another array of length 3 containing the x,y,symbol triplet
// This array is built after a move is submitted and several spaces on the board need to be changed (flipped) 
function updateGameBoard($xyArr,$twDimBoard)
{
	for($i = 0;$i < count($xyArr);$i++)
		{
					$x = $xyArr[$i][0];
					$y = $xyArr[$i][1];
					$symbol = $xyArr[$i][2];
					$twDimBoard = $this->changeGameBoardSpace($x,$y,$symbol,$twDimBoard);
			  
		}
		return $twDimBoard;
}
  
 
 
 function changeGameBoardSpace($x,$y,$symb,$twDimBoard)
{
		$twDimBoard[$x][$y] = $symb;		
	    return $twDimBoard;
}
 
 
  
  


 
function verifyMove($x,$y,$sym,$twDimBoard)
	{
	    if($sym == 'X')
			{
				$symb = 'X';
				$osymb = 'O';
			}
	    else if($sym == 'O')
			{
				$symb = 'O';
				$osymb = 'X';
			}
		$flipSpaces = array();
		$tempSpaces = array();
		$flipSpaces[0][0] = null;
		$flipSpaces[0][1] = null;
    	$flipSpaces[0][2] = null;

       
		//echo $symb;
		if($this->getGameBoardSpace($x,$y,$twDimBoard) == '.')  // Make sure move is to empty space
				{
					// Verify to the East
					$count = 1;
					$ix = $x;
					$iy = $y;
					$tempSpaces[0][0] = $x;
				    $tempSpaces[0][1] = $y;
				    $tempSpaces[0][2] = $symb;
            
                    if(  ($ix+1)  < 8  )
                        {
                                while($this->getGameBoardSpace(++$ix,$iy, $twDimBoard) == $osymb)
                                    {
                                      $tempSpaces[$count][0] = $ix;
                                      $tempSpaces[$count][1] = $iy;
                                      $tempSpaces[$count][2] = $symb;
                                      $count++;
                                    }
                                if(($count > 1) && ($this->getGameBoardSpace($ix,$iy, $twDimBoard) == $symb))
                                        { 
                                            $tempSpaces[$count][0] = $ix;
                                            $tempSpaces[$count][1] = $iy;
                                            $tempSpaces[$count][2] = $symb;
                                            $flipSpaces = array_merge($flipSpaces,$tempSpaces);
                                        }
                                else
                                    $tempSpaces = null;
						}
						
					 // Verify to the North East
					$count = 1;
					$ix = $x;
					$iy = $y;
					$tempSpaces[0][0] = $x;
				    $tempSpaces[0][1] = $y;
				    $tempSpaces[0][2] = $symb;
						
                     if(    ( ($ix+1)  < 8)  &&  ( ( $iy+1)  < 8)  )
                        {
                            while($this->getGameBoardSpace(++$ix,++$iy, $twDimBoard) == $osymb)
                                { 
                                  
                                  $tempSpaces[$count][0] = $ix;
                                  $tempSpaces[$count][1] = $iy;
                                  $tempSpaces[$count][2] = $symb;
                                  $count++;
                                }
                            if(($count > 1) && $this->getGameBoardSpace($ix,$iy, $twDimBoard) == $symb)
                                    {
                                       
                                        $tempSpaces[$count][0] = $ix;
                                        $tempSpaces[$count][1] = $iy;
                                        $tempSpaces[$count][2] = $symb;
                                        $flipSpaces = array_merge($flipSpaces,$tempSpaces);
                                    }
                            else
                                $tempSpaces = null;
                      }
						
					 // Verify to the North
					$count = 1;
					$ix = $x;
					$iy = $y;
					$tempSpaces[0][0] = $x;
				    $tempSpaces[0][1] = $y;
				    $tempSpaces[0][2] = $symb;
				       
                    if(  ($iy+1)  < 8  )
                        {
                                while($this->getGameBoardSpace($ix,++$iy, $twDimBoard) == $osymb)
                                    {
                                      $tempSpaces[$count][0] = $ix;
                                      $tempSpaces[$count][1] = $iy;
                                      $tempSpaces[$count][2] = $symb;
                                      $count++;
                                }
                            
                              // echo $symb;
                                if(($count > 1) && $this->getGameBoardSpace($ix,$iy, $twDimBoard) == $symb  )  
                                        { 
                                            $tempSpaces[$count][0] = $ix;
                                            $tempSpaces[$count][1] = $iy;
                                            $tempSpaces[$count][2] = $symb;
                                            $flipSpaces = array_merge($flipSpaces,$tempSpaces);
                                        }
                                else
                                    $tempSpaces = null;
                        }
					
					// Verify to the North West
					$count = 1;
					$ix = $x;
					$iy = $y;
					$tempSpaces[0][0] = $x;
				    $tempSpaces[0][1] = $y;
				    $tempSpaces[0][2] = $symb;
                    
                      if(    ( ($ix-1)  > 0)  &&  ( ( $iy+1) < 8)  )
                        {
										
                            while($this->getGameBoardSpace(--$ix,++$iy, $twDimBoard) == $osymb)
                                {
                                  $tempSpaces[$count][0] = $ix;
                                  $tempSpaces[$count][1] = $iy;
                                  $tempSpaces[$count][2] = $symb;
                                  $count++;
                                }
                            if(($count > 1) && ($this->getGameBoardSpace($ix,$iy, $twDimBoard) == $symb))
                                    {
                                        $tempSpaces[$count][0] = $ix;
                                        $tempSpaces[$count][1] = $iy;
                                        $tempSpaces[$count][2] = $symb; 
                                        $flipSpaces = array_merge($flipSpaces,$tempSpaces);
                                    }
                            else
                                $tempSpaces = null;
                        }
					
					
					// Verify to the West
					$count = 1;
					$ix = $x;
					$iy = $y;
					
					$tempSpaces[0][0] = $x;
				    $tempSpaces[0][1] = $y;
				    $tempSpaces[0][2] = $symb;
                    
                      if(  ($ix-1)  > 0  )
                        {
					
                                while($this->getGameBoardSpace(--$ix,$iy, $twDimBoard) == $osymb)
                                    {
                                      $tempSpaces[$count][0] = $ix;
                                      $tempSpaces[$count][1] = $iy;
                                      $tempSpaces[$count][2] = $symb;
                                      $count++;
                                    }
                                if(($count > 1) && ($this->getGameBoardSpace($ix,$iy, $twDimBoard) == $symb))
                                        {
                                            $tempSpaces[$count][0] = $ix;
                                            $tempSpaces[$count][1] = $iy;
                                            $tempSpaces[$count][2] = $symb;
                                            $flipSpaces = array_merge($flipSpaces,$tempSpaces);
                                        }
                                else
                                    $tempSpaces = null;
                            }
						
					// Verify to the South West
					$count = 1;
					$ix = $x;
					$iy = $y;
					$tempSpaces[0][0] = $x;
				    $tempSpaces[0][1] = $y;
				    $tempSpaces[0][2] = $symb;
                             
                             
                      if(    ( ($ix-1)  > 0)  &&  ( ( $iy-1) > 0)  )
                        {
										
                                while($this->getGameBoardSpace(--$ix,--$iy, $twDimBoard) == $osymb)
                                    {
                                      $tempSpaces[$count][0] = $ix;
                                      $tempSpaces[$count][1] = $iy;
                                      $tempSpaces[$count][2] = $symb;
                                      $count++;
                                    }
                                if(($count > 1) && ($this->getGameBoardSpace($ix,$iy, $twDimBoard) == $symb))
                                        {
                                            $tempSpaces[$count][0] = $ix;
                                            $tempSpaces[$count][1] = $iy;
                                            $tempSpaces[$count][2] = $symb; 
                                            $flipSpaces = array_merge($flipSpaces,$tempSpaces);
                                        }
                                else
                                    $tempSpaces = null;
                        }
					
				
			      // Verify to the South 
					$count = 1;
					$ix = $x;
					$iy = $y;
					//echo "x= ".$ix." y= ".$iy." other symb= ".$osymb."</br>";
					
					$tempSpaces[0][0] = $x;
				    $tempSpaces[0][1] = $y;
				    $tempSpaces[0][2] = $symb;
                    
                       if(  ($iy-1)  > 0  )
                        {
                            
                            while($this->getGameBoardSpace($ix,--$iy,$twDimBoard) == $osymb)
                                {
                                  $tempSpaces[$count][0] = $ix;
                                  $tempSpaces[$count][1] = $iy;
                                  $tempSpaces[$count][2] = $symb;
                                  $count++;
                                }
                            if(($count > 1) && ($this->getGameBoardSpace($ix,$iy,$twDimBoard) == $symb))
                                    {
                                        $tempSpaces[$count][0] = $ix;
                                        $tempSpaces[$count][1] = $iy;
                                        $tempSpaces[$count][2] = $symb;
                                        $flipSpaces = array_merge($flipSpaces,$tempSpaces);
                                        
                                    }
                            else
                                $tempSpaces = null;
                        }
                    
			
					// Verify to the South East 
					$count = 1;
					$ix = $x;
					$iy = $y;
					$tempSpaces[0][0] = $x;
				    $tempSpaces[0][1] = $y;
				    $tempSpaces[0][2] = $symb;
                               
                      if(    ( ($ix+1)  < 8)  &&  ( ( $iy-1) > 0)  )
                        {
                                    while($this->getGameBoardSpace(++$ix,--$iy, $twDimBoard) == $osymb)
                                        {
                                          $tempSpaces[$count][0] = $ix;
                                          $tempSpaces[$count][1] = $iy;
                                          $tempSpaces[$count][2] = $symb;
                                          $count++;
                                        }
                                    if(($count > 1) && ($this->getGameBoardSpace($ix,$iy, $twDimBoard) == $symb))
                                            {
                                                  $tempSpaces[$count][0] = $ix;
                                                  $tempSpaces[$count][1] = $iy;
                                                  $tempSpaces[$count][2] = $symb;
                                                  $flipSpaces = array_merge($flipSpaces,$tempSpaces);
                                            }
                                    else
                                        $tempSpaces = null;
                        }
						
						
				if($flipSpaces != null)
					{
						return $flipSpaces; 
					}					
				else
					return null;
			
				}
				else 
					return null;
	}

	 
  
  
 
function getGameBoardSpace($x, $y, $twDimBoard)
    {
         //echo "<br/> x: ".$x." y: ".$y." sym: ".$twDimBoard[$y][$x];
         if(($x < 0) || ($x >= 8) || ($y<0) || ($y >= 8))
                return '@';
                
        $boardRowArr = array();
       //echo $twDimBoard[$y][$x];
       
        return $twDimBoard[$x][$y];
    } 
  
  
 function calculateFinalScore()
    {
        $board = $this->getBoardInverse();
        $Ocount = 0;
        $Xcount = 0;
       
        for($i=0;$i<8;$i++)
            for($j=0;$j<8;$j++)
                    {
                            if($board[$i][$j] == 'O')
                                $Ocount += 1;
                            else if($board[$i][$j] == 'X')
                                $Xcount += 1;
                        
                    }
       $finalScore = array('O' => $Ocount,'X' =>$Xcount,);
        return $finalScore;
        
    }
  
  
  
  
    
}
/* End of file tools.php_logo_guid */
/* Location: ./application/controllers/othello.php
