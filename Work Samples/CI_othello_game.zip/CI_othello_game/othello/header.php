
<html>
    <head>
        <meta http-equiv="content-type" content="text/html;charset=UTF-8">
        
        
        <!--  the following two lines load the jQuery library and JavaScript files -->
        <script src="<?php echo $jqueryloc; ?>" type="text/javascript"></script>
        <script src="<?php echo $jqfile; ?>" type="text/javascript"></script>


         <link href = "<?php echo $css; ?>" rel="stylesheet" type="text/css" />
        <title>Othello Game</title>
        
        
        <script type="text/javascript">
            function JQFunctions()
                {              
           /*         $('.cell').bind('mouseup',function()
                            {
                                        var y = $(this).parent().attr('id').substring(3);
                                        y = y - 1;
                                        var x = $(this).attr('title');
                                        
                                    $("#xval input[name='xvalue']").val(x);
                                    $("#yval input[name='yvalue']").val(y); 
                              
                            });   
                            */
                      
                      $(document).bind('mouseover',function()
                        {
                             
                                   $('#clkspace').slideDown('medium');
                                   $('#clkspace').slideUp('medium');
                                      
                                    $('#prbutton').slideDown('medium');
                                    $('#prbutton').slideUp('medium');
                                            
                                    $('#prbutton2').slideDown('medium');
                                    $('#prbutton2').slideUp('medium');
                                        
                         });      
                
                         $("#cross").mouseover(function()
                         {
                             
                                          
                                           var x = $("#xval input[name='xvalue']").val(); 
                                           var y =  $("#yval input[name='yvalue']").val();
                                        
                                          if(   ( x < 0  ||  x > 7)  || ( y < 0  ||  y > 7)  )
                                            {
                                                    $('#message').css('font-size','75%');
                                                    $('#message').text("Your Selection is Not between 0 and 7.  \nPlease Select Again");
                                              //     $("#xval input[name='xvalue']").val('');
                                                 //   $("#yval input[name='yvalue']").val('');
                                                    $("#subbutton input[name='submit']").hide();
                                            }
                        })
                              
                         $("#xval input[name='xvalue']").keydown(function()
                             {
                                      $('#message').css('font-size','50%');
                                      $("#subbutton input[name='submit']").show();
                             
                             });
               
                        $('.cell').mouseup(function()
                            {
                                   $('#message').css('font-size','60%');
                                $('#message').text('');
                                   $('#message').append($("<span id='prbutton' style='font-size:250%;color:purple'>**Press Button** </span><span style='font-size:250%'>to Submit Move</span>"));
                                   $("#subbutton input[name='submit']").show();
                                        var y = $(this).parent().attr('id').substring(3);
                                        y = y - 1;
                                        var x = $(this).attr('title');
                                 
                                    $("#xval input[name='xvalue']").val(x)
                                    $("#yval input[name='yvalue']").val(y); 
                                    
                                    
                                  
                              
                            });   
                           
                  
               }    // end of JQFunction() function
                
         
              function clearInput()
                  {
               
                     $("#xval input[name='xvalue']").attr('value','');
                      $("#yval input[name='yvalue']").attr('value',''); 
                   }
         
                
                
                
                            
        </script>

</head>

<body onload="JQFunctions()">
 <div class="oframe" id="oframe">
    <h1>Othello Game</h1>
    <div id="status">
        <div id="formcontainer">
             <?php echo validation_errors(); ?>
                        <?php 
                                $attributes = array('id'=>'moveinputform');
                                echo form_open('othello/playbegin',$attributes); 
                        ?>
                <div id="xval" style="display:<?php echo $display1; ?>">
                    <label>Enter X value of Move</label>
                    <input name="xvalue" type="text" size="35"  value="Enter X Value Here"  onclick="clearInput()"/>
                </div>
                <div id="yval"  style="display:<?php echo $display1; ?>">
                    <label>Enter Y value of Move</label>
                    <input name="yvalue" type="text" size="35"  value="Enter Y Value Here"  onclick="clearInput()"/>
                </div>
                <div id="botcontainer">
                            <div id="message"  style="font-size:<?php echo $cheight; ?>%"><?php echo $message; ?>
                            </div>
                            <div id="mask" style="display:<?php echo $display3; ?>">
                                    <div id="subbutton"   style="display:<?php echo $display1; ?>">
                                            <div id="cross">
                                            <input type="submit" name="submit"  style="height:50px;font-size:100%" value="Submit This Move" />
                                            </div>
                                            <input type="hidden" name="hid" value="<?php echo $flag; ?>"/>
                                         
                                    </div>
                                    <div id="playbutton" style="display:<?php echo $display2; ?>" >
                                            <input type="submit" name="submit" style="height:80px;width:160px;font-size:140%" value="Press to Play" />
                                          
                                    </div>
                            </div>
                            <div id="nextbutton" style="display:<?php echo $display4; ?>" >
                                    <input type="submit" name="submit"  style="height:65px;font-size:120%"  value="Press to Continue" />
                            </div>
                </div>
            </form>
        </div>
    </div>

