	
/* Global JavaScript File for working with jQuery library */

// execute when the HTML file's (document object model: DOM) has loaded
$(document).ready(function() {

              //alert ('Hello World');
            $('.cell').bind('mouseenter',function()
                    {
                           $(this).css('color','tan').css('border-color','black');
                             
                    });


            $('.cell').bind('mouseleave',function()
                    {
                            $(this).css('color','black').css('background-color','yellow');
                             
                    });

            $('.cell').bind('mousedown',function()
                    {
                            $(this).css('background-color','tan').css('color','black');
                             
                    });

	


});
