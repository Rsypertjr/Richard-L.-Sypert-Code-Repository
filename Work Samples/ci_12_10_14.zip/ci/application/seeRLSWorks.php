<?php
namespace vendor;

use \Behat\Mink\Driver\GoutteDriver;
use \Behat\Mink\Driver\SahiDriver;
use \Behat\Mink\Session;
use \Behat\Mink\Mink;
use \Behat\Mink\Element\NodeElement;


require_once 'autoload.php';
require '/PHPUnit/Framework/Assert/Functions.php';

class RLSWorksTest extends \PHPUnit_Framework_TestCase
{
private $baseUrl;
private $baseUrl2;
private $doc1URL;
private $url2;
private $url3;
private $client;
private $goutteDriver;
private $sahiDriver;
private $goutteSession;
private $sahiSession;
private $mink;
private $gouttePage;
private $sahiPage;
private $el;
private $namedSelector;
private $cssSelector;
private $handler;


        protected function setup()
        {
        $this->baseUrl = 'rlsworks';  
        $this->baseUrl2 = 'index.php/othello/index2';
        $this->doc1URL = 'showPDF1';
        $this->url2 = 'http://www.wikipedia.com';
        $this->url3 = 'http://67.23.226.231/~rlsworks/ci/';
        $this->href = 'http://www.key-project.org/download/hoare/';
        $this->goutteDriver = new GoutteDriver();
        $this->sahiDriver = new SahiDriver('chrome');
        $this->goutteSession = new Session($this->goutteDriver);
        $this->sahiSession = new Session($this->sahiDriver);
        $this->mink = new Mink();
        $this->mink->registerSession('sahi',$this->sahiSession);

         
        }

        protected function teardown()
        {
        $this->goutteDriver= NULL;
        $this->SahiDriver= NULL;
        $this->goutteSession= NULL;
        $this->sahiSession= NULL;
        $this->mink= NULL;
        $this->namedSelector= NULL;
        $this->cssSelector= NULL;
        $this->handler=NULL;
        }
         

        function testRLSWorks()
        {

        //$this->goutteDriver = new GoutteDriver();
        //$this->sahiDriver = new SahiDriver('firefox');
        //$this->goutteSession = new Session($this->goutteDriver);
        //$this->sahiSession = new Session($this->sahiDriver);
        $this->sahiSession = $this->mink->getSession('sahi');
        //$this->sahiSession->start();
        $this->sahiSession->visit($this->url3);
        
        //Check for Front Page -- Assertion #1
        AssertContains($this->baseUrl,$this->sahiSession->getCurrentUrl(),'Intended web page not reached!'); 
        $frontPage = $this->sahiSession->getPage();

        // Check for Orominer Program Button -- Assertion #2
        $orominerButton = $frontPage->find('css','DIV#orominer');
        AssertSame($orominerButton->isVisible(),true,'Orominer Program Selection Not Found!');
        $orominerButton->mouseOver();
        //Create delay during mouseover
        sleep(3);
        
        $orominerButton->click();
        $orominerButton->click();
        
        $orominerPage = $this->sahiSession->getPage();
        // Check for Page Change -- Assertion #3
        AssertContains($this->baseUrl2,$this->sahiSession->getCurrentUrl(),'Intended web page not reached!'); 
        
        // Check for Orominer Program Page Header  -- Assertion #4
        $orominerHeading = $orominerPage->find('css','DIV#protitle');
        AssertSame($orominerHeading->isVisible(),true,'Orominer Program Page Not Reached!');
       // Create wait time while showing orominer program
         sleep(4);
        /* Could do Demo of Orominer Program 

        */

        // Back to Front Page
        $this->sahiDriver->back();

        // Check for Orominer Histo Button -- Assertion #5
        $orominerHistoButton = $frontPage->find('css','DIV#oroHist');
        AssertSame($orominerHistoButton->isVisible(),true,'Orominer Histological Program Selection Not Found!');
        //Create delay during mouseover
        sleep(3);
        // Double-Click OrominerHisto Button
        $orominerHistoButton->click();
        $orominerHistoButton->click();
        
        $orominerHistoPage = $this->sahiSession->getPage();
        // Verify Page Change -- Assertion #6
        AssertContains($this->baseUrl2,$this->sahiSession->getCurrentUrl(),'Intended web page not reached!'); 

        // Check for Right Page of Orominer Histological Program -- Assertion #7
        $orominerHistoHViewHeader = $orominerHistoPage->find('xpath','//div[text()="Hierarchical View"]');
        AssertSame($orominerHistoHViewHeader->isVisible(),true,'Orominer Histological Program Page Not Found!');
        //create wait time while viewing orominer histological program
        sleep(4);
   
        //Back to Front Page
        $this->sahiDriver->back();

        //Check for Othello Game Button -- Assertion #8
        $othelloButton = $frontPage->find('xpath','//div[contains(text(),"Othello")]');
        AssertSame($othelloButton->isVisible(),true,'Othello Game Selection Not Found!');
        $othelloButton->mouseOver();
        
        // create delay during mouseover event
        sleep(3);
        // Double-Click Othello Game Button
        $othelloButton->click();
        $othelloButton->click();
        
        $othelloGamePage = $this->sahiSession->getPage();
        // Verify Page Change -- Assertion #9
        AssertContains($this->baseUrl2,$this->sahiSession->getCurrentUrl(),'Intended web page not reached!'); 

        // Check for Right Page of Othello Game -- Assertion #10
        $othelloGameHeader = $othelloGamePage->find('xpath','//div[contains(text(),"Othello Game")]');
        AssertSame($othelloGameHeader->isVisible(),true,'Othello Game Page Not Found!');
        // create delay while showing Othello Game
        sleep(4);
        
        // Back to Front Page
        $this->sahiDriver->back();

        //Check for Mini-Motif Game Button -- Assertion #11
        $miniMotifButton = $frontPage->find('xpath','//div[contains(text(),"Mini-Motif")]');
        AssertSame($miniMotifButton->isVisible(),true,'Mini-Motif Program Selection Not Found!');
        $miniMotifButton->mouseOver();
        //Create delay during mouse over event
        sleep(3);
        
        // Double-Click Mini-Motif Program Button
        $miniMotifButton->click();
        $miniMotifButton->click();
        $miniMotifProgramPage = $this->sahiSession->getPage();
        // Verify Page Change -- Assertion #12
        AssertContains($this->baseUrl2,$this->sahiSession->getCurrentUrl(),'Intended web page not reached!'); 

        // Check for Right Page of Mini-Motif Program -- Assertion #13
        $miniMotifHeader = $miniMotifProgramPage->find('xpath','//h1[contains(text(),"Minimotif Search")]');
        AssertSame($miniMotifHeader->isVisible(),true,'MiniMotif Program Page Not Found!');

       //Create delay while showing the miniMotif Program
       sleep(4);
        // Back to Front Page
        $this->sahiDriver->back();

        //Check for Technical Writing Button -- Assertion #14
        $technicalWritingButton = $frontPage->find('xpath','//div[contains(text(),"Technical")]');
        AssertSame($technicalWritingButton->isVisible(),true,'Technical Writing Selection Not Found!');
        $technicalWritingButton->mouseOver();
        //Create delay during mouseover event
        sleep(3);
        
        // Double-Click Technical Writing Button -- Assertion #15
        $technicalWritingButton->click();
        $technicalWritingButton->click();
        $technicalWritingPage = $this->sahiSession->getPage();
        // Verify Page Change -- Assertion #16
        AssertContains($this->baseUrl2,$this->sahiSession->getCurrentUrl(),'Intended web page not reached!'); 

        // Check for Right Page of Technical Writing Documents -- Assertion #16
        $technicalWritingHeader = $technicalWritingPage->find('xpath','//div[contains(text(),"Technical Writing Documents")]');
        AssertSame($technicalWritingHeader->isVisible(),true,'Technical Writing Page Not Found!');

        // Check First Document (Grainger ABCDEF Series B) -- Assertion #17
        $doc1Button = $technicalWritingPage->find('css','DIV#doc1');
        AssertSame($doc1Button->isVisible(),true,'Grainger ABCDE Series B Document Selection Not Found!');
        $doc1Button->mouseOver();
        
        //Create delay during mouseover event
        $scrip1a = "$('#doc1').mouseover()";
        $scrip1b = "$('#doc1').mouseleave()";
        $this->sahiSession->evaluateScript($scrip1a);
        $this->sahiDriver->wait(2000,$scrip1a);
        $this->sahiDriver->wait(3000,$scrip1b);  

        // Check Second Document (Grainger CDE) -- Assertion #18
        $doc2Button = $technicalWritingPage->find('css','DIV#doc2');
        AssertSame($doc2Button->isVisible(),true,'Grainger CDE Document Selection Not Found!');
        $doc2Button->mouseOver();
    
       //Create delay during mouseover event
        $scrip2a = "$('#doc2').mouseover()";
        $scrip2b = "$('#doc2').mouseleave()";
        $this->sahiSession->evaluateScript($scrip2a);
        $this->sahiDriver->wait(2000,$scrip2a);
        $this->sahiDriver->wait(3000,$scrip2b);

        // Check Third Document (MEC Product Manual VT 1.6) -- Assertion #19
        $doc3Button = $technicalWritingPage->find('css','DIV#doc3');
        AssertSame($doc3Button->isVisible(),true,'MEC Product Manual VT 1.6');
        $doc3Button->mouseOver();
      
       //Create delay during mouseover event
        $scrip3a = "$('#doc3').mouseover()";
        $scrip3b = "$('#doc3').mouseleave()";
        $this->sahiSession->evaluateScript($scrip3a);
        $this->sahiDriver->wait(2000,$scrip3a);
        $this->sahiDriver->wait(3000,$scrip3b);
        
        // Check Forth Document (MEC White Paper) -- Assertion #20
        $doc4Button = $technicalWritingPage->find('css','DIV#doc4');
        AssertSame($doc4Button->isVisible(),true,'MEC White Paper');
        $doc4Button->mouseOver();
      
       //Create delay during mouseover event
        $scrip4a = "$('#doc4').mouseover()";
        $scrip4b = "$('#doc4').mouseleave()";
        $this->sahiSession->evaluateScript($scrip4a);
        $this->sahiDriver->wait(2000,$scrip4a);
        $this->sahiDriver->wait(3000,$scrip4b);

        // Check Fifth Document (Improvement Plan Requirements) -- Assertion #21
        $doc5Button = $technicalWritingPage->find('css','DIV#doc5');
        AssertSame($doc5Button->isVisible(),true,'Improvement Plan Requirements');
        $doc5Button->mouseOver();
       
        //Create delay during mouseover event
        $scrip5a = "$('#doc5').mouseover()";
        $scrip5b = "$('#doc5').mouseleave()";
        $this->sahiSession->evaluateScript($scrip5a);
        $this->sahiDriver->wait(2000,$scrip5a);
        $this->sahiDriver->wait(3000,$scrip5b);

        // Back to Front Page
        $this->sahiDriver->back();

          //Check for 'Resume for Richard' Button -- Assertion #22
        $ResumeButton = $frontPage->find('xpath','//div[contains(text(),"Resume")]');
        AssertSame($ResumeButton->isVisible(),true,'Resume for Richard Selection Not Found!');
        $ResumeButton->mouseOver();
        // Create delay during mouse Over event
        sleep(3);
       
        // Double-Click Resume Button
        $ResumeButton->click();
        $ResumeButton->click();
        $resumePage = $this->sahiSession->getPage();
        // Verify Page Change -- Assertion #23
        AssertContains($this->baseUrl2,$this->sahiSession->getCurrentUrl(),'Intended web page not reached!'); 

        //Assertion #24
        $resumePageHeader = $resumePage->find('xpath','//div[contains(text(),"Hover")]');
        AssertSame($resumePageHeader->isVisible(),true,'Resume Page Header Not Found!');
        
        $resumePage = $this->sahiSession->getPage();
        $viewPDF= $resumePage->find('xpath','//div[contains(text(),"View PDF")]');
        
        // Show then hide Technical Skills List
        $findtwT = '$("div#techSkillsTitle").show()';
        $findtwC = '$("div#techSkills").show()';
         $findtwTh = '$("div#techSkillsTitle").hide()';
        $findtwCh= '$("div#techSkills").hide()';
      
        $this->sahiSession->evaluateScript($findtwT);
        $this->sahiSession->evaluateScript($findtwC);
        sleep(3);
        $this->sahiSession->evaluateScript($findtwTh);
        $this->sahiSession->evaluateScript($findtwCh);

       //Show then hide UNLV Job
       $findUNLVJobAdd = '$("div.employerAddress:contains(\'University of Nevada\')").show()';
       $findUNLVJobAddh = '$("div.employerAddress:contains(\'University of Nevada\')").hide()';
       $findUNLVJob = '$("div.jobTitle:contains(\'Research Assistant\')").show()';
       $findUNLVJobh = '$("div.jobTitle:contains(\'Research Assistant\')").hide()';
       $this->sahiSession->evaluateScript($findUNLVJobAdd);
       $this->sahiSession->evaluateScript($findUNLVJob);
       sleep(3);
       $this->sahiSession->evaluateScript($findUNLVJobAddh);
       $this->sahiSession->evaluateScript($findUNLVJobh);
       
       // Show and hide first jobless period
       $findJobless = '$("div.joblessContainer:contains(\'April 2011\') div.joblessDescription").show()';
       $findJoblessh = '$("div.joblessContainer:contains(\'April 2011\') div.joblessDescription").hide()';
       $this->sahiSession->evaluateScript($findJobless);
       sleep(3);
       $this->sahiSession->evaluateScript($findJoblessh);
       
       //Show then hide InsureZone Job
       $findIZJobAdd = '$("div.employerAddress:contains(\'Horizon Ridge\')").show()';
       $findIZJobAddh = '$("div.employerAddress:contains(\'Horizon Ridge\')").hide()';
       $findIZJob = '$("div.jobTitle:contains(\'Software Developer\')").show()';
       $findIZJobh = '$("div.jobTitle:contains(\'Software Developer\')").hide()';
       $this->sahiSession->evaluateScript($findIZJobAdd);
       $this->sahiSession->evaluateScript($findIZJob);
       sleep(3);
       $this->sahiSession->evaluateScript($findIZJobAddh);
       $this->sahiSession->evaluateScript($findIZJobh);
       
       //Show then hide Power Efficiency Job
       $findPEJobAdd = '$("div.employerAddress:contains(\'Pilot Road\')").show()';
       $findPEJobAddh = '$("div.employerAddress:contains(\'Pilot Road\')").hide()';
       $findPEJob = '$("div.jobTitle:contains(\'Engineering Support Analyst\')").show()';
       $findPEJobh = '$("div.jobTitle:contains(\'Engineering Support Analyst\')").hide()';
       $this->sahiSession->evaluateScript($findPEJobAdd);
       $this->sahiSession->evaluateScript($findPEJob);
       sleep(3);
       $this->sahiSession->evaluateScript($findPEJobAddh);
       $this->sahiSession->evaluateScript($findPEJobh);
       
       // Show and hide second jobless period
       $findJobless2 = '$("div.joblessContainer:contains(\'March 2006\') div.joblessDescription").show()';
       $findJobless2h = '$("div.joblessContainer:contains(\'March 2006\') div.joblessDescription").hide()';
       $this->sahiSession->evaluateScript($findJobless2);
       sleep(3);
       $this->sahiSession->evaluateScript($findJobless2h);
       
        //Show then hide Southern Nevada Health District Job
       $findSNHDJobAdd = '$("div.employerAddress:contains(\'Shadow Lane\')").show()';
       $findSNHDJobAddh = '$("div.employerAddress:contains(\'Shadow Lane\')").hide()';
       $findSNHDJob = '$("div.jobTitle:contains(\'Health Engineer\')").show()';
       $findSNHDJobh = '$("div.jobTitle:contains(\'Health Engineer\')").hide()';
       $this->sahiSession->evaluateScript($findSNHDJobAdd);
       $this->sahiSession->evaluateScript($findSNHDJob);
       sleep(3);
       $this->sahiSession->evaluateScript($findSNHDJobAddh);
       $this->sahiSession->evaluateScript($findSNHDJobh);
       
       
        //Show then hide Aderholt Specialty Job
       $findASJobAdd = '$("div.employerAddress:contains(\'Valley View\')").show()';
       $findASJobAddh = '$("div.employerAddress:contains(\'Valley View\')").hide()';
       $findASJob = '$("div.jobTitle:contains(\'Construction\')").show()';
       $findASJobh = '$("div.jobTitle:contains(\'Construction\')").hide()';
       $this->sahiSession->evaluateScript($findASJobAdd);
       $this->sahiSession->evaluateScript($findASJob);
       sleep(3);
       $this->sahiSession->evaluateScript($findASJobAddh);
       $this->sahiSession->evaluateScript($findASJobh);
       
       
        //Show then hide Red Inc. Communications Job
       $findRIJobAdd = '$("div.employerAddress:contains(\'3320 North\')").show()';
       $findRIJobAddh = '$("div.employerAddress:contains(\'3320 North\')").hide()';
       $findRIJob = '$("div.jobTitle:contains(\'Editor\')").show()';
       $findRIJobh = '$("div.jobTitle:contains(\'Editor\')").hide()';
       $this->sahiSession->evaluateScript($findRIJobAdd);
       $this->sahiSession->evaluateScript($findRIJob);
       sleep(3);
       $this->sahiSession->evaluateScript($findRIJobAddh);
       $this->sahiSession->evaluateScript($findRIJobh);
       
       
        //Show then hide Center for Enterprise and Information Job
       $findCEIJobAdd = '$("div.employerAddress:contains(\'Clark County\')").show()';
       $findCEIJobAddh = '$("div.employerAddress:contains(\'Clark County\')").hide()';
       $findCEIJob = '$("div.jobTitle:contains(\'Systems Technician\')").show()';
       $findCEIJobh = '$("div.jobTitle:contains(\'Systems Technician\')").hide()';
       $this->sahiSession->evaluateScript($findCEIJobAdd);
       $this->sahiSession->evaluateScript($findCEIJob);
       sleep(3);
       $this->sahiSession->evaluateScript($findCEIJobAddh);
       $this->sahiSession->evaluateScript($findCEIJobh);
       
        // Show and hide third jobless period
       $findJobless3 = '$("div.joblessContainer:contains(\'1996 to May 2001\') div.joblessDescription").show()';
       $findJobless3h = '$("div.joblessContainer:contains(\'1996 to May 2001\') div.joblessDescription").hide()';
       $this->sahiSession->evaluateScript($findJobless3);
       sleep(3);
       $this->sahiSession->evaluateScript($findJobless3h);
       
       //Show then hide Allied-Signal Aerospace Job
       $findASAJobAdd = '$("div.employerAddress:contains(\'Bannister Road\')").show()';
       $findASAJobAddh = '$("div.employerAddress:contains(\'Bannister Road\')").hide()';
       $findASAJob = '$("div.jobTitle:contains(\'Process Engineer\')").show()';
       $findASAJobh = '$("div.jobTitle:contains(\'Process Engineer\')").hide()';
       $this->sahiSession->evaluateScript($findASAJobAdd);
       $this->sahiSession->evaluateScript($findASAJob);
       sleep(3);
       $this->sahiSession->evaluateScript($findASAJobAddh);
       $this->sahiSession->evaluateScript($findASAJobh);
       
       
         // Show and hide first educational period
       $education1 = '$("div.joblessContainer:contains(\'1980 to May 1983\') div.joblessDescription").show()';
       $education1h = '$("div.joblessContainer:contains(\'1980 to May 1983\') div.joblessDescription").hide()';
       $this->sahiSession->evaluateScript($education1);
       sleep(3);
       $this->sahiSession->evaluateScript($education1h);
       
         // Show and hide second educational period
       $education2 = '$("div.joblessContainer:contains(\'1996 to May 2002\') div.joblessDescription").show()';
       $education2h = '$("div.joblessContainer:contains(\'1996 to May 2002\') div.joblessDescription").hide()';
       $this->sahiSession->evaluateScript($education2);
       sleep(3);
       $this->sahiSession->evaluateScript($education2h);
       
          // Show and hide third educational period
       $education3 = '$("div.joblessContainer:contains(\'1998 to May 2001\') div.joblessDescription").show()';
       $education3h = '$("div.joblessContainer:contains(\'1998 to May 2001\') div.joblessDescription").hide()';
       $this->sahiSession->evaluateScript($education3);
       sleep(3);
       $this->sahiSession->evaluateScript($education3h);
       
       
        // Back to Front Page
        $this->sahiDriver->back();
        }
         
         
         
         
}


?>
