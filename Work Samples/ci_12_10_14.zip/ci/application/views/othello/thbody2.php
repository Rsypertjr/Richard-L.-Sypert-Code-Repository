<div id="gboard">
            <div class="topbar" id="topbar">
                <div class="tcell">\</div>
                <div class="tcell">0</div>
                <div class="tcell">1</div>
                <div class="tcell">2</div>
                <div class="tcell">3</div>
                <div class="tcell">4</div>
                <div class="tcell">5</div>
                <div class="tcell">6</div>
                <div class="tcell">7</div>
            </div>
            <div class="sidebar" id="sidebar">
                <div class="scell">0</div>
                <div class="scell">1</div>
                <div class="scell">2</div>
                <div class="scell">3</div>
                <div class="scell">4</div>
                <div class="scell">5</div>
                <div class="scell">6</div>
                <div class="scell">7</div>
            </div>
            <div id="playarea">     
                    <div class="grow" id="row1">
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                    </div>
                    <div class="grow" id="row2">
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                    </div>
                    <div class="grow" id="row3">
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                    </div>
                    <div class="grow" id="row4">
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">X</div>
                        <div class="cell">O</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                    </div>
                    <div class="grow" id="row5">
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">O</div>
                        <div class="cell">X</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                    </div>
                    <div class="grow" id="row6">
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                    </div>
                    <div class="grow" id="row7">
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                    </div>
                    <div class="grow" id="row8">
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                        <div class="cell">.</div>
                    </div>
             </div>
        </div>