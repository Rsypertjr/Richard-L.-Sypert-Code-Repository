	<div id="gboard"  onmouseover="JQFunctions();">
            <div class="topbar" id="topbar">
                <div id="xbar" ><div id="inner2">X<span style="visibility:hidden">---</span>COORDINATES</div></div>
                <div class="tcell"></div>
                <div class="tcell">0</div>
                <div class="tcell">1</div>
                <div class="tcell">2</div>
                <div class="tcell">3</div>
                <div class="tcell">4</div>
                <div class="tcell">5</div>
                <div class="tcell">6</div>
                <div class="tcell">7</div>
            </div>
            <div class="sidebar" id="sidebar">
                <div id="ybar" ><div id="inner"><br/>Y<br/><br/>COORDINATES</div></div>
                <div class="scell">0</div>
                <div class="scell">1</div>
                <div class="scell">2</div>
                <div class="scell">3</div>
                <div class="scell">4</div>
                <div class="scell">5</div>
                <div class="scell">6</div>
                <div class="scell">7</div>
            </div>
            <div id="playarea" >     
                    <div class="grow" id="row1">
                        <div class="cell"  title="0">.</div>
                        <div class="cell"  title="1">.</div>
                        <div class="cell"  title="2">.</div>
                        <div class="cell"  title="3">.</div>
                        <div class="cell"  title="4">.</div>
                        <div class="cell"  title="5">.</div>
                        <div class="cell"  title="6">.</div>
                        <div class="cell"  title="7">.</div>
                    </div>
                    <div class="grow" id="row2">
                         <div class="cell"  title="0">.</div>
                        <div class="cell"  title="1">.</div>
                        <div class="cell"  title="2">.</div>
                        <div class="cell"  title="3">.</div>
                        <div class="cell"  title="4">.</div>
                        <div class="cell"  title="5">.</div>
                        <div class="cell"  title="6">.</div>
                        <div class="cell"  title="7">.</div>
                    </div>
                    <div class="grow" id="row3">
                          <div class="cell"  title="0">.</div>
                        <div class="cell"  title="1">.</div>
                        <div class="cell"  title="2">.</div>
                        <div class="cell"  title="3">.</div>
                        <div class="cell"  title="4">.</div>
                        <div class="cell"  title="5">.</div>
                        <div class="cell"  title="6">.</div>
                        <div class="cell"  title="7">.</div>
                    </div>
                    <div class="grow" id="row4">
                          <div class="cell"  title="0">.</div>
                        <div class="cell"  title="1">.</div>
                        <div class="cell"  title="2">.</div>
                        <div class="cell"  title="3">X</div>
                        <div class="cell"  title="4">O</div>
                        <div class="cell"  title="5">.</div>
                        <div class="cell"  title="6">.</div>
                        <div class="cell"  title="7">.</div>
                    </div>
                    <div class="grow" id="row5">
                        <div class="cell"  title="0">.</div>
                        <div class="cell"  title="1">.</div>
                        <div class="cell"  title="2">.</div>
                        <div class="cell"  title="3">O</div>
                        <div class="cell"  title="4">X</div>
                        <div class="cell"  title="5">.</div>
                        <div class="cell"  title="6">.</div>
                        <div class="cell"  title="7">.</div>
                    </div>
                    <div class="grow" id="row6">
                        <div class="cell"  title="0">.</div>
                        <div class="cell"  title="1">.</div>
                        <div class="cell"  title="2">.</div>
                        <div class="cell"  title="3">.</div>
                        <div class="cell"  title="4">.</div>
                        <div class="cell"  title="5">.</div>
                        <div class="cell"  title="6">.</div>
                        <div class="cell"  title="7">.</div>
                    </div>
                    <div class="grow" id="row7">
                        <div class="cell"  title="0">.</div>
                        <div class="cell"  title="1">.</div>
                        <div class="cell"  title="2">.</div>
                        <div class="cell"  title="3">.</div>
                        <div class="cell"  title="4">.</div>
                        <div class="cell"  title="5">.</div>
                        <div class="cell"  title="6">.</div>
                        <div class="cell"  title="7">.</div>
                    </div>
                    <div class="grow" id="row8">
                        <div class="cell"  title="0">.</div>
                        <div class="cell"  title="1">.</div>
                        <div class="cell"  title="2">.</div>
                        <div class="cell"  title="3">.</div>
                        <div class="cell"  title="4">.</div>
                        <div class="cell"  title="5">.</div>
                        <div class="cell"  title="6">.</div>
                        <div class="cell"  title="7">.</div>
                    </div>
             </div>
        </div>