<?xml version="1.0" standalone="yes"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<html><body><div class="oframe">
    <h1>Othello Game</h1>
    <div id="status">Player1 Move!</div>
    <div class="grow" id="row1">.<div class="cell">.</div>.<div class="cell">.</div>.<div class="cell">.</div>.<div class="cell">.</div>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
    </div>'
    <div class="grow" id="row2">.<div class="cell">.</div>.<div class="cell">.</div>.<div class="cell">.</div>.<div class="cell">.</div>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
    </div>'.
    <div class="grow" id="row3">.<div class="cell">.</div>.<div class="cell">.</div>.<div class="cell">.</div>.<div class="cell">.</div>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
    </div>'
    <div class="grow" id="row4">.<div class="cell">.</div>0<div class="cell">X</div>O<div class="cell">.</div>.<div class="cell">.</div>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
    </div>'
    <div class="grow" id="row5">.<div class="cell">.</div>.<div class="cell">0</div>X<div class="cell">.</div>.<div class="cell">.</div>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
    </div>'
    <div class="grow" id="row6">.<div class="cell">.</div>.<div class="cell">.</div>0<div class="cell">.</div>.<div class="cell">.</div>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
    </div>'
    <div class="grow" id="row7">.<div class="cell">.</div>.<div class="cell">.</div>.<div class="cell">.</div>.<div class="cell">.</div>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
    </div>'
    <div class="grow" id="row8">.<div class="cell">.</div>.<div class="cell">.</div>.<div class="cell">.</div>.<div class="cell">.</div>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
        <div class="cell"/>
    </div>'
</div></body></html>
