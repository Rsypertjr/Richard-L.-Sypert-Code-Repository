<!-- This file runs the orominer program that shows histological data. The function doSystems is recursively called and it uses XML data objects of 
xmlDoc for the xml database, and nodeDoc for the open/active node record, and tableDoc for created tables  -->


<script type="text/javascript">
// JAVASCRIPT FUNCTIONS ---------------------------------------------------------------------------


 var svgNS = "http://www.w3.org/2000/svg";   // namespace for svg graphic methods

function doTransform(nds)
{
  var xmlHttp = getXMLHttp();
  xmlHttp.onreadystatechange = function()
  {
    if(xmlHttp.readyState == 4 && xmlhttp.status==200)
    {
      alert(xmlHttp.responseText);
    }

  }
  xmlHttp.open("GET","transformXML.php?nodes="+nds, true);
  xmlHttp.send(null);
}


function buildHView(hlist_xml)  // create xml object for xml database and make initial call to doSystems 
{
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
		var xmlDoc=xmlhttp.responseXML.documentElement;
	
		doSystems(xmlDoc,"top",null,null);

    }
  }
xmlhttp.open("GET",hlist_xml,true);
xmlhttp.send();
}


function getXMLDoc2()  // create XML object for open/active nodes
{
var text = "<top><Active_Nodes></Active_Nodes><Draw_Nodes></Draw_Nodes><All></All><Select></Select><Layers></Layers><Tables></Tables></top>";
try //Internet Explorer 
	{
	xmlDoc=new ActiveXObject("Microsoft.XMLDOM"); xmlDoc.async="false";
	xmlDoc.loadXML(text);
	}
	catch(e) 
	{
		try //Firefox, Mozilla, Opera, etc.
		{
			parser=new DOMParser();
			xmlDoc=parser.parseFromString(text,"text/xml");
		}
		catch(e) {alert(e.message)}
	}
/*	try 
	{
		document.write("xmlDoc is loaded, ready for use"); 
	}
	catch(e) 
	{
		alert(e.message)
	} */
    return xmlDoc;
}


function getXMLDoc3()
{
var text = "<top><Layers></Layers><Tables></Tables></top>";
try //Internet Explorer 
	{
	xmlDoc=new ActiveXObject("Microsoft.XMLDOM"); xmlDoc.async="false";
	xmlDoc.loadXML(text);
	}
	catch(e) 
	{
		try //Firefox, Mozilla, Opera, etc.
		{
			parser=new DOMParser();
			xmlDoc=parser.parseFromString(text,"text/xml");
		}
		catch(e) {alert(e.message)}
	}
/*	try 
	{
		document.write("xmlDoc is loaded, ready for use"); 
	}
	catch(e) 
	{
		alert(e.message)
	} */
    return xmlDoc;
}



function addNode(xmlDoc,nodeDoc,tableDoc,nm,nlevel,sc,si,oi,pi,ci)  // create record of open/active nodes
{
	var anode_name = nm + "_anode";
	
	var nme = nm.split("_1-"); 
	nme = nme[0].split("_");
	nme = nme[nme.length-1];

		anode = nodeDoc.createElement("anode");
		newtext = nodeDoc.createTextNode(anode_name);
		anode.appendChild(newtext);
		
				
		var active_nodes = nodeDoc.getElementsByTagName("Active_Nodes");
		active_nodes[0].appendChild(anode);
		//alert(nodeDoc.getElementsByTagName("anode")[0].childNodes[0].nodeValue);
		//alert(nodeDoc.getElementsByTagName("anode").length);
		
		
		var all = nodeDoc.getElementsByTagName("All");
	
		
		if(nlevel=="system")
			{
				
				// build xml record of node
				syst = nodeDoc.createElement("System");
				systext = nodeDoc.createTextNode(nme);
				syst.appendChild(systext);
				syst.setAttribute("id",nm);
				syst.setAttribute("name",si);
				// index not used	
				index = nodeDoc.createElement("index");
				indextext = nodeDoc.createTextNode(si);
				index.appendChild(indextext);
				
				// put color and index in xml
				color = nodeDoc.createElement("color");
				colortext = nodeDoc.createTextNode(sc);
				color.appendChild(colortext);
				syst.appendChild(index);
				syst.appendChild(color);
				all[0].appendChild(syst);
		
			}
		else if(nlevel == "organ")
			{
			    
				org = nodeDoc.createElement("Organ");
				orgtext = nodeDoc.createTextNode(nme);
				org.appendChild(orgtext);
				org.setAttribute("id",nm);
				org.setAttribute("name",oi);
				
				index = nodeDoc.createElement("index");
				indextext = nodeDoc.createTextNode(oi);
				index.appendChild(indextext);
				color = nodeDoc.createElement("color");
				colortext = nodeDoc.createTextNode(sc);
				color.appendChild(colortext);
				org.appendChild(index);
				org.appendChild(color);
				
				sys = all[0].getElementsByTagName("System");
				//alert("gets to organ");
				if(sys.length > 0)
					{
					    
						for(s=0;s<sys.length;s++)
							{   
							    
								sy = sys[s].getAttribute("name");
								if(sy == si)
									{
							
										sys[s].appendChild(org);
																		
									}
							}
					}
				else
					;
				
			}
		else if(nlevel == "part")
			{
			    
				part = nodeDoc.createElement("Part");
				parttext = nodeDoc.createTextNode(nme);
				part.appendChild(parttext);
				part.setAttribute("id",nm);
				part.setAttribute("name",pi);
				index = nodeDoc.createElement("index");
				indextext = nodeDoc.createTextNode(pi);
				index.appendChild(indextext);
				color = nodeDoc.createElement("color");
				colortext = nodeDoc.createTextNode(sc);
				color.appendChild(colortext);
				part.appendChild(index);
				part.appendChild(color);
				
				sys = all[0].getElementsByTagName("System");
				if(sys.length > 0)
					{
					    for(s=0;s<sys.length;s++)
							{
								sy = sys[s].getAttribute("name");
								if(sy == si)
									{
										org = sys[s].getElementsByTagName("Organ");
										if(org.length > 0)
											{
												for(o=0;o<org.length;o++)
													{
														or = org[o].getAttribute("name");
														if(or == oi)
															{
																org[o].appendChild(part);
															
															}
													}
											}
										
										
						  				
										
									
									}
							}
					}  
			
			}  
			else if (nlevel == "histo")
				{
						 
					histo = nodeDoc.createElement("histo_Layer");
					histotext = nodeDoc.createTextNode(nme);
					histo.appendChild(histotext);
					histo.setAttribute("id",nm);
					index = nodeDoc.createElement("index");
					indextext = nodeDoc.createTextNode(ci);
					index.appendChild(indextext);
					color = nodeDoc.createElement("color");
					colortext = nodeDoc.createTextNode(sc);
					color.appendChild(colortext);
					histo.appendChild(index);
					histo.appendChild(color);
					//histo.setAttribute("index",ci);
							
					sys = all[0].getElementsByTagName("System");
					if(sys.length > 0)
						{
							for(s=0;s<sys.length;s++)
								{
									sy = sys[s].getAttribute("name");
									if(sy == si)
										{
											org = sys[s].getElementsByTagName("Organ");
											if(org.length > 0)
												{
													for(o=0;o<org.length;o++)
														{
															or = org[o].getAttribute("name");
															if(or == oi)
																{
																   parts = org[o].getElementsByTagName("Part")
																   for(p=0;p<parts.length;p++)
																		{
																			pn = parts[p].getAttribute("name");
																			if(pn==pi)
																				{
																						
																					if(nlevel=="cell")
																						{
																							parts[p].appendChild(cell);
																						}
																					else if(nlevel=="ecell")
																						{
																							parts[p].appendChild(ecell);
																						}
																					else if(nlevel=="histo")
																						{
																							parts[p].appendChild(histo);
																						}
																	
																					
																				}
																		}
																
																
																}
														}
												}
											
											
											
											
										
										}
								}
						}  
				
			}
	
}



function drawNodes(nodeDoc,tableDoc)
{
// Draw Nodes from the xml store of active nodes in nodeDoc XML object under the <All> tag.  Also displays tables for organ layer, subpart, and histological layer
// when node is clicked
	drawNodesXML = getXMLDoc3();
	all = nodeDoc.getElementsByTagName("All");
	n = 0;

	// clear out display
	mysvg = document.getElementById("mySVG");
	el = mysvg.firstChild;
	while(el)
		{
			el.parentNode.removeChild(el);
			el = mysvg.firstChild;
		}  
	
	grhdr = document.getElementById("grahdr");
	grhdr.innerHTML="<div id='intromess'  style='position:relative;top:10px;height:40px;z-index:-1;left:420px;font-size:30px'>PRESS ANY SYSTEM NODE FOR THE MENU</div>";
		
	sys = all[0].getElementsByTagName("System")
	ind = 0;
	txval = 0;
	tyval = 0;
	if(sys.length > 0)
		{
		        
					
				x1 = 850;
				y1 = 500;
				yadd = 500; 
				var scale = 0;
				
				
				//outside graphical contaniner
				og = document.createElementNS(svgNS,"g");
				og.setAttributeNS(null,"width","4000");
				og.setAttributeNS(null,"height","4000");
				og.setAttributeNS(null,"transform","scale(1)");
				og.setAttributeNS(null,"transform","translate(0,0)");
				og.setAttributeNS(null,"id","outerg");
		
				// Create translate value and put in XML
				all = nodeDoc.getElementsByTagName("All");
			
				tx = all[0].getElementsByTagName("translatex");
				ty = all[0].getElementsByTagName("translatey");
								
				if(tx.length <= 0 && ty.length <= 0)
					{
						translatex = nodeDoc.createElement("translatex");
						translatey = nodeDoc.createElement("translatey");
						tranxtext = nodeDoc.createTextNode("0");
						tranytext = nodeDoc.createTextNode("0");
						translatex.appendChild(tranxtext);
						translatey.appendChild(tranytext);
						all[0].appendChild(translatex);
						all[0].appendChild(translatey);
					}
				
			
				txval=tx[0].childNodes[0].nodeValue;
				tyval=ty[0].childNodes[0].nodeValue;
				///alert(tyval);
				
				scalefactor = nodeDoc.createElement("scale");
				scaletext = nodeDoc.createTextNode("1");
				scalefactor.appendChild(scaletext);		
				all = nodeDoc.getElementsByTagName("All");
				all[0].appendChild(scalefactor);
				
				
				var sysrad = 60;
				var orgrad = 45;
				var partrad = 35;
				var histrad = 25;
				
				for(sn=0;sn<sys.length;sn++)
					{
					
						tx = all[0].getElementsByTagName("translatex");
						ty = all[0].getElementsByTagName("translatey");
						
						txval=tx[0].childNodes[0].nodeValue;
						tyval=ty[0].childNodes[0].nodeValue;
					
						ind++;
						
						if(ind % 2 == 0)
							xadd = -2300;
						else
							xadd = 2300;
						system = sys[sn];
												
						scalefac = nodeDoc.getElementsByTagName("scale");
						var fac = scalefac[0].childNodes[0].nodeValue;
						og.setAttributeNS(null,"transform","scale(" + fac + ")" + " translate(" + txval + "," + tyval + ")");
				
						// draw system node
						sysname = system.childNodes[0].nodeValue;
						color = system.getElementsByTagName("color");
						syscolor = color[0].childNodes[0].nodeValue;
				
					    g = document.createElementNS(svgNS,"g");
						g.setAttributeNS(null,"id",sysname);
						
						circle = document.createElementNS(svgNS,"circle");
						circle.setAttributeNS(null,"cx",x1);
						circle.setAttributeNS(null,"cy",y1);
						circle.setAttributeNS(null,"r",sysrad);
						circle.setAttributeNS(null,"stroke","black");
						circle.setAttributeNS(null,"stroke-width",5);
						circle.setAttributeNS(null,"fill",syscolor);
						circle.setAttributeNS(null,"z-index",5);
						circle.setAttributeNS(null,"opacity",1);
						circle.setAttributeNS(null,"id",sysname+"node");
						circle.setAttributeNS(null,"cursor","pointer");
						
						//Menu display
						circle.onclick = function()
							{
							    menubg="wheat";
								menutable = document.getElementById("menutable");
								if(menutable)
									menutable.parentNode.removeChild(menutable);
							
								// Begin building the menu table
								menutable = document.createElement("table");
								menutable.setAttribute("z-index",3);
								menutable.setAttribute("border",2);
								menutable.setAttribute("bgcolor","white");
								menutable.setAttribute("id","menutable");
								//menutable.setAttribute("style","opacity:0.5");
								
								//Menu header
							    tr = document.createElement("tr");
								th = document.createElement("th");
								th.setAttribute("bgcolor","yellow");
								th.setAttribute("width","450px");
								th.setAttribute("height","80px");
								th.innerHTML = "<big><big><big>MENU</big></big></big>";
								
								tr.appendChild(th);
								
								//Zoom in label 
								trin = document.createElement("tr");
								trin.setAttribute("height","60px");
								$trin = $(trin);
								$trin.css('cursor','pointer');
								//trin.setAttribute("cursor","pointer");
								trin.setAttribute("bgcolor",menubg);
							
								trin.innerHTML = "<td><big><big><center>ZOOM-IN</center></big></big></td>";
								
								//Zoom out label 
								trout = document.createElement("tr");
								trout.setAttribute("height","60px");
								trout.setAttribute("bgcolor",menubg);
								$trout = $(trout);
								$trout.css('cursor','pointer');
								//trout.setAttribute("cursor","pointer");
								trout.innerHTML = "<td><big><big><center>ZOOM-OUT</center></big></big></td>";
								
								// Menu exit label
								trex = document.createElement("tr");
								trex.setAttribute("height","60px");
								trex.setAttribute("bgcolor","red");
								$trex = $(trex);
								$trex.css('cursor','pointer');
								//trex.setAttribute("cursor","pointer");
								trex.innerHTML = "<td><big><big><center>EXIT</center></big></big></td>";
								
								// How to Translate Menu Translate label
								
								trtransht = document.createElement("tr");
								trtransht.setAttribute("height","60px");
								trtransht.setAttribute("bgcolor",menubg);
								$trtransht = $(trtransht);
								$trtransht.css('cursor','pointer');
								//trtransht.setAttribute("cursor","pointer");
								trtransht.innerHTML = "<td><big><big><center>HOW TO TRANSLATE IMAGE</center></big></big></td>";
								
								getnodeinfo = document.createElement("tr");
								getnodeinfo.setAttribute("height","60px");
								getnodeinfo.setAttribute("bgcolor",menubg);
								$getnodeinfo = $(getnodeinfo);
								$getnodeinfo.css('cursor','pointer');
								//getnodeinfo.setAttribute("cursor","pointer");
								getnodeinfo.innerHTML = "<td><big><big><center>HOW TO GET NODE INFO</center></big></big></td>";
								
								
								menutable.appendChild(tr);
								menutable.appendChild(trin);
								menutable.appendChild(trout);
								menutable.appendChild(trtransht);
								menutable.appendChild(getnodeinfo);
								menutable.appendChild(trex);
								
								// Create zoom scale factor and put in XML
								scalefactor = nodeDoc.createElement("scale");
								scaletext = nodeDoc.createTextNode("1.5");
								scalefactor.appendChild(scaletext);
								all = nodeDoc.getElementsByTagName("All");
								all[0].appendChild(scalefactor);
								var fac = 0;
								// Exit menu function
							    trex.onclick = function()
									{
										menutable = document.getElementById("menutable");
										if(menutable)
											menutable.parentNode.removeChild(menutable);
											
											
										grhdr = document.getElementById("grahdr");
										grhdr.innerHTML="<div id='intromess' style='position:relative;color:red;top:10px;height:40px;z-index:-1;left:420px;font-size:30px'>PRESS ANY SYSTEM NODE FOR THE MENU</div>";
									}
									
								// Zoom in menu function
								trin.onclick = function()
									{
									
										//xpos = this.getAttributeNS(null,"cx");
										//ypos = this.getAttributeNS(null,"cy");
										// Get scale factor from xml
										scalefac = nodeDoc.getElementsByTagName("scale");
										fac = scalefac[0].childNodes[0].nodeValue;
										outerg = mysvg.getElementById("outerg");
										
										// Get translation values from xml
										all = nodeDoc.getElementsByTagName("All");
										all[0].appendChild(translatex);
										all[0].appendChild(translatey);
										tx = all[0].getElementsByTagName("translatex");
										ty = all[0].getElementsByTagName("translatey");
										txval = tx[0].childNodes[0].nodeValue;
										tyval = ty[0].childNodes[0].nodeValue;
										
										fac = parseFloat(fac) + 0.5;
										//outerg.transform.scale = fac;
										outerg.setAttributeNS(null,"transform","scale(" + fac + ")" + " translate(" + txval + "," + tyval + ")");
										
										scalefac[0].childNodes[0].nodeValue = fac;
										
									}  
									
								// Zoom in menu function
								trout.onclick = function()
									{
										// Get scale factor from xml
										scalefac = nodeDoc.getElementsByTagName("scale");
										fac = scalefac[0].childNodes[0].nodeValue;
										
										// Get translation values from xml
										all = nodeDoc.getElementsByTagName("All");
										all[0].appendChild(translatex);
										all[0].appendChild(translatey);
										tx = all[0].getElementsByTagName("translatex");
										ty = all[0].getElementsByTagName("translatey");
										txval = tx[0].childNodes[0].nodeValue;
										tyval = ty[0].childNodes[0].nodeValue;
										
										outerg = document.getElementById("outerg");
										fac = parseFloat(fac) - 0.5;
										outerg.setAttributeNS(null,"transform","scale(" + fac + ")" + " translate(" + txval + "," + tyval + ")");
										scalefac[0].childNodes[0].nodeValue = fac;
										
									}  	
								
										
								mysvg.onmousedown = function()
									{
										x1 = window.event.clientX; 
										y1 = window.event.clientY;
										mysvg.onmousemove = function()
											{
												//alert("lets move");
												mysvg.onmouseup = function()
												{
													
													x2 = window.event.clientX; 
													y2 = window.event.clientY;
													dx = x2 - x1;
													dy = y2 - y1;
													
													all = nodeDoc.getElementsByTagName("All");
													all[0].appendChild(translatex);
													all[0].appendChild(translatey);
													
													tx = all[0].getElementsByTagName("translatex");
													ty = all[0].getElementsByTagName("translatey");
													
													// get and update xml record of translate
													xval = tx[0].childNodes[0].nodeValue;
													yval = ty[0].childNodes[0].nodeValue;
													xval = parseInt(xval);
													yval = parseInt(yval);
													xval += parseInt(dx);
													yval += parseInt(dy);
													
													tx[0].childNodes[0].nodeValue = xval;
													ty[0].childNodes[0].nodeValue = yval;
													
													scalefac = nodeDoc.getElementsByTagName("scale");
													fac = scalefac[0].childNodes[0].nodeValue;
													
													outerg = mysvg.getElementById("outerg");
													outerg.setAttributeNS(null,"transform","scale(" + fac + ")" + " translate(" + xval + "," + yval + ")");
												
												}
											}
									}   // end of translate
								
													
								trtransht.onclick = function()
									{
										alert("TO MOVE/PAN IMAGE: (1) Hold Down Left Mouse Button--Preferably Not over a display Object; (2) Move Cursor to Desired Location; (3) Release Mouse Button. ");
								
									}
						
								getnodeinfo.onclick = function()
										{
											alert("TO GET NODE INFO: (1) Click-On_Node to See Node Information; (2) Click Again to Remove Node Information.");
										}
							
								intro = document.getElementById("intromess");
								intro.parentNode.removeChild(intro);
						
								imgvw = document.getElementById("imgview");
								el = imgvw.firstChild;
								while(el)
									{
										el.parentNode.removeChild(el);
										el = imgvw.firstChild;
									}  
									
								document.getElementById("imgview").appendChild(menutable);
								
							}  // end circle onclick

						og.appendChild(g);
						g.appendChild(circle);
						document.getElementById("mySVG").appendChild(og);
						
						
						text = document.createElementNS(svgNS,"text");
						text.setAttributeNS(null,"x",x1);
						text.setAttributeNS(null,"y",(y1+110));
						text.setAttributeNS(null,"fill","black");
						text.setAttributeNS(null,"text-anchor","middle");
						text.setAttributeNS(null,"opacity",1);  
						text.setAttributeNS(null,"font-size",60);
						systext = document.createTextNode(sysname);
						text.appendChild(systext);
						og.appendChild(g);
						g.appendChild(text);
						document.getElementById("mySVG").appendChild(og);

						organs = system.getElementsByTagName("Organ");
						n = organs.length;
					
						if(n>0)
						{
							var organgleinc = (2*Math.PI)/n;
							
							for(o2=0;o2<n;o2++)
								{
									orgname = organs[o2].childNodes[0].nodeValue;
									if (o2==0)
										organgle = 0;
									
									linecalcradius = 450;
									
									x2 = x1 + linecalcradius*Math.cos(organgle);
									y2 = y1 + linecalcradius*Math.sin(organgle);
									
									// Draw line to organ node
								    g = document.createElementNS(svgNS,"g");
									g.setAttributeNS(null,"id",sysname+orgname);
									
									var line = document.createElementNS(svgNS,"line");
									line.setAttributeNS(null,"x1",x1+sysrad*Math.cos(organgle));
									line.setAttributeNS(null,"y1",y1+sysrad*Math.sin(organgle));
									line.setAttributeNS(null,"x2",x2);
									line.setAttributeNS(null,"y2",y2);
									line.setAttributeNS(null,"stroke","rgb(255,0,0)");
									line.setAttributeNS(null,"stroke-width",5);
									line.setAttributeNS(null,"z-index",2);
									line.setAttributeNS(null,"opacity",1);  
									og.appendChild(g);
									g.appendChild(line);
									document.getElementById("mySVG").appendChild(og);
									
									// Draw Organ node
									circle = document.createElementNS(svgNS,"circle");
									circle.setAttributeNS(null,"cx",x2);
									circle.setAttributeNS(null,"cy",y2);
									circle.setAttributeNS(null,"r",orgrad);
									circle.setAttributeNS(null,"stroke","black");
									circle.setAttributeNS(null,"stroke-width",5);
									circle.setAttributeNS(null,"fill",syscolor);
									circle.setAttributeNS(null,"id",sysname+orgname+"node");
									circle.setAttributeNS(null,"z-index",5);
									circle.setAttributeNS(null,"name",sysname+orgname);
									// Menu display and Organ Layer table display on left click
									
									// Toggle Display of Organ Layer Table
								    circle.onclick = function()
										{
													  
											tablename = this.getAttribute("name");  // get root name
											tablename = tablename+"organlayertable";
											tablename = tablename.replace(/\s|\-|\_/gi,'');
											imgview = document.getElementById("imgview");
											thetable =  document.getElementById(tablename);
											tables = tableDoc.getElementsByTagName("Tables");
											if(thetable)  // erase table
												{
													
													tables[0].appendChild(thetable.cloneNode(true));
													imgview.removeChild(thetable);
												}
											else if(!thetable)
												{  
													//Retrieve table
													thetable2 = tableDoc.getElementById(tablename);
												
													// ReDraw tables, Place new table at top 
													imgview = document.getElementById("imgview");
													imgview.insertBefore(thetable2,imgview.childNodes[0]);
													
													
												}
										}
				
								
									og.appendChild(g);
									g.appendChild(circle);
									document.getElementById("mySVG").appendChild(og);
									
									// Draw node label
									text = document.createElementNS(svgNS,"text");
									text.setAttributeNS(null,"x",(x2));
									text.setAttributeNS(null,"y",(y2-67));
									text.setAttributeNS(null,"fill","black");
									text.setAttributeNS(null,"text-anchor","middle");
									text.setAttributeNS(null,"opacity",1);  
									text.setAttributeNS(null,"font-size",52);
									
									orgnm = document.createTextNode(orgname);
									text.appendChild(orgnm);
									og.appendChild(g);
									g.appendChild(text);
									document.getElementById("mySVG").appendChild(og);
									
									
									parts = organs[o2].getElementsByTagName("Part");
									pl = parts.length;
									
									if(pl > 0)
										{
										
											x1b = x2;
											y1b = y2;
											var partangleinc = (2*Math.PI)/pl;
											
											for(pi=0;pi<pl;pi++)
												{
												
												    partname = parts[pi].childNodes[0].nodeValue;
													
													if (pi==0)
														{
															partangle = organgle + 90/(2*Math.PI);
															
														}
												
													linecalcradius2 = 300;
													var x2b = x1b + linecalcradius2*Math.cos(partangle);
													var y2b = y1b + linecalcradius2*Math.sin(partangle);
													
													// Draw line to part node
													var line = document.createElementNS(svgNS,"line");
													line.setAttributeNS(null,"x1",x1b+orgrad*Math.cos(partangle));
													line.setAttributeNS(null,"y1",y1b+orgrad*Math.sin(partangle));
													line.setAttributeNS(null,"x2",x2b);
													line.setAttributeNS(null,"y2",y2b);
													line.setAttributeNS(null,"stroke","rgb(255,0,0)");
													line.setAttributeNS(null,"stroke-width",5);
													line.setAttributeNS(null,"opacity",1);  
													og.appendChild(g);
													g.appendChild(line);
													document.getElementById("mySVG").appendChild(og);
													
													// Draw part node
													g = document.createElementNS(svgNS,"g");  // group for part-hist node assembly to rotate
													g.setAttributeNS(null,"id",sysname+orgname+partname+"rotate");
													
													var circle = document.createElementNS(svgNS,"circle");
													circle.setAttributeNS(null,"cx",x2b);
													circle.setAttributeNS(null,"cy",y2b);
													circle.setAttributeNS(null,"r",partrad);
													circle.setAttributeNS(null,"stroke","black");
													circle.setAttributeNS(null,"stroke-width",5);
													circle.setAttributeNS(null,"fill",syscolor);
													circle.setAttributeNS(null,"z-index",5);
													circle.setAttributeNS(null,"id",sysname+orgname+partname+"node");
													circle.setAttributeNS(null,"name",sysname+orgname+partname);
													
													// Toggle Display of Subpart Table
													circle.onclick = function()
														{
													  
														tablename = this.getAttribute("name");  // get root name
														tablename = tablename+"subparttable";
														tablename = tablename.replace(/\s|\-|\_/gi,'');
														imgview = document.getElementById("imgview");
														thetable =  document.getElementById(tablename);
														tables = tableDoc.getElementsByTagName("Tables");
														if(thetable)  // erase table
															{
																
																tables[0].appendChild(thetable.cloneNode(true));
																imgview.removeChild(thetable);
															}
														else if(!thetable)
															{  
																//Retrieve table
																thetable2 = tableDoc.getElementById(tablename);
																
																// ReDraw tables, Place new table at top 
																imgview = document.getElementById("imgview");
																imgview.insertBefore(thetable2,imgview.childNodes[0]);
																
															}
														}
																		
																	
													og.appendChild(g);
													g.appendChild(circle);
													document.getElementById("mySVG").appendChild(og);
													
													// Draw part node label
													var text = document.createElementNS(svgNS,"text");
													text.setAttributeNS(null,"x",(x2b));
													text.setAttributeNS(null,"y",(y2b-42));
													text.setAttributeNS(null,"fill","black");
													text.setAttributeNS(null,"text-anchor","middle");
													text.setAttributeNS(null,"opacity",1);  
													text.setAttributeNS(null,"font-size",42);
													
													prtnm = document.createTextNode(partname);
													text.appendChild(prtnm);
													og.appendChild(g);
													g.appendChild(text)
													document.getElementById("mySVG").appendChild(og);
																									
													histolyrs = parts[pi].getElementsByTagName("histo_Layer");
													hly = histolyrs.length;
													
													if(hly > 0)
														{	
															x1c = x2b;
															y1c = y2b;
															var histangleinc = (2*Math.PI)/hly;
													
															for(hr=0;hr<hly;hr++)
															 {
															 
																	 histolyrname = histolyrs[hr].childNodes[0].nodeValue;
																	
																	if (hr==0)
																		histangle = partangle + 90/(2*Math.PI);
																		
																		
																	linecalcradius2 = 200;
																	x2c = x1c + linecalcradius2*Math.cos(histangle);
																	y2c = y1c + linecalcradius2*Math.sin(histangle);
																	
																	// Draw line to histo node								
																	var line = document.createElementNS(svgNS,"line");
																	line.setAttributeNS(null,"x1",x1c+partrad*Math.cos(histangle));
																	line.setAttributeNS(null,"y1",y1c+partrad*Math.sin(histangle));
																	line.setAttributeNS(null,"x2",x2c);
																	line.setAttributeNS(null,"y2",y2c);
																	line.setAttributeNS(null,"stroke","rgb(255,0,0)");
																	line.setAttributeNS(null,"stroke-width",5);
																	line.setAttributeNS(null,"opacity",(.6));  
																	og.appendChild(g);
																	g.appendChild(line);
																	document.getElementById("mySVG").appendChild(og);
																	
																	// Draw histo node
																	var circle = document.createElementNS(svgNS,"circle");
																	circle.setAttributeNS(null,"cx",x2c);
																	circle.setAttributeNS(null,"cy",y2c);
																	circle.setAttributeNS(null,"r",histrad);
																	circle.setAttributeNS(null,"stroke","black");
																	circle.setAttributeNS(null,"stroke-width",6);
																	circle.setAttributeNS(null,"fill",syscolor);
																	circle.setAttributeNS(null,"opacity",1);
																	circle.setAttributeNS(null,"z-index",5);
																	circle.setAttributeNS(null,"id",sysname+orgname+partname+histolyrname+"node");
																	circle.setAttributeNS(null,"name",sysname+orgname+partname+histolyrname);
																	
																	// Toggle Display of Histological Table
																	circle.onclick = function()
																	{
																  
																	tablename = this.getAttribute("name");  // get root name
																	tablename = tablename+"histotable";
																	tablename = tablename.replace(/\s|\-|\_/gi,'');
																	imgview = document.getElementById("imgview");
																	thetable =  document.getElementById(tablename);
																	tables = tableDoc.getElementsByTagName("Tables");
																	if(thetable)  // erase table
																		{
																			
																		    tables[0].appendChild(thetable.cloneNode(true));
																		    imgview.removeChild(thetable);
																		}
																	else if(!thetable)
																		{  
																		    //Retrieve table
																			thetable2 = tableDoc.getElementById(tablename);
																		
																			// ReDraw tables, Place new table at top 
																			imgview = document.getElementById("imgview");
																			imgview.insertBefore(thetable2,imgview.childNodes[0]);

																	
																		}
																	}
											
																	og.appendChild(g);
																	g.appendChild(circle);
																	document.getElementById("mySVG").appendChild(og);
																	
																	// Draw histo node label
																	var text = document.createElementNS(svgNS,"text");
																	text.setAttributeNS(null,"x",(x2c));
																	text.setAttributeNS(null,"y",(y2c-35));
																	text.setAttributeNS(null,"fill","black");
																	text.setAttributeNS(null,"text-anchor","middle");
																	text.setAttributeNS(null,"opacity",1);  
																	text.setAttributeNS(null,"font-size",37);
																	hslname = document.createTextNode(histolyrname);
																	text.appendChild(hslname);
																	g.appendChild(text);
																	og.appendChild(g);
																	document.getElementById("mySVG").appendChild(og);
																	histangle = histangle + histangleinc;
															
															 }  // end of for loop for histological layers
														}
												  partangle = partangle + partangleinc;	
												}  // end of for loop for part
										}
																
									organgle = organgle + organgleinc ;
								}
								
								angle = 0;
						}
							y1 = y1 + yadd;	
							x1 = x1 + xadd;
					}
		}
}

function xml_to_string(xml_node) // used to convert xml object to string representation
    {
        if (xml_node.xml)
            return xml_node.xml;
        else if (XMLSerializer)
        {
            var xml_serializer = new XMLSerializer();
            return xml_serializer.serializeToString(xml_node);
        }
        else
        {
            alert("ERROR: Extremely old browser");
            return "";
        }
    }



function getsubparts(xmlDoc,tableDoc,lname,sysid,organid,partid,cl)
{ 
	 // Store subpart records in xml and build their display tables
     // ********************************************************************	 
	
	sys = new Array();
	org = new Array();
	part = new Array();
	layers = new Array();
	
	// Change name of xml file
	sys = xmlDoc.getElementsByTagName("System");
	org = sys[sysid].getElementsByTagName("Organ");
	part = org[organid].getElementsByTagName("Part");
	sysname = sys[sysid].childNodes[0].nodeValue;
	orgname = org[organid].childNodes[0].nodeValue;
	partname = part[partid].childNodes[0].nodeValue;
	
	// get sub parts
	subpart = part[partid].getElementsByTagName("Subpart");
	sl = subpart.length;
	
	// create output elements
	layers = tableDoc.getElementsByTagName("Layers");
    
	// create system component of subpart record
	subpartsys = tableDoc.createElement("System");
	spstext = tableDoc.createTextNode(sys[sysid].childNodes[s].nodeValue);
	subpartsys.appendChild(spstext);

	// create organ component of subpart record
	subpartorg = tableDoc.createElement("Organ");
	spotext = tableDoc.createTextNode(org[organid].childNodes[0].nodeValue);
	subpartorg.appendChild(spotext);
	subpartsys.appendChild(subpartorg);
	
	// create part component of subpart record\
	subpartpart = tableDoc.createElement("Part");
	spptext = tableDoc.createTextNode(part[partid].childNodes[0].nodeValue);
	subpartpart.appendChild(spptext);
	subpartorg.appendChild(subpartpart);
	layers[0].appendChild(subpartsys);
	prt = part[partid].childNodes[0].nodeValue;
	
	
	if(sl > 0)
		{
		   tables = tableDoc.getElementsByTagName("Tables");
		   table1 = document.createElement("table");
		   table1.setAttribute("border","1");
		   table1.setAttribute("font-size","30px");
		   tname = sysname+orgname+partname+"subparttable";
		   tname = tname.replace(/\s|\_|\-/gi,'');  // Strip non-alpha chars out
		   table1.setAttribute("id",tname);
		   
		    tr = document.createElement("tr");
			th = document.createElement("th");
			th.setAttribute("width","400px");
			th.setAttribute("height","50px");
			th.innerHTML="<big><big><big>"+ "Subpart(s) for " + "<font color='"+cl+ "'>"+ prt + "</font>" + " Part" + "</big></big></big>";
			tr.appendChild(th);
			table1.appendChild(tr);	
				
		   for(sp=0;sp<subpart.length;sp++)
				{
				    subprt = tableDoc.createElement("Subpart")
				    sptext = tableDoc.createTextNode(subpart[sp].childNodes[0].nodeValue);
				    subprt.appendChild(sptext);
				    subpartpart.appendChild(subprt);  // append subpart to xml record
				    spname = subpart[sp].childNodes[0].nodeValue;
					tr = document.createElement("tr");
					td = document.createElement("td");
					td.innerHTML =  "<big><big><big><center>"+ "<font color='" + cl + "'>" + spname + "</font><center></big></big></big>";
					tr.appendChild(td);
					table1.appendChild(tr);
				}
				
				// End previous table with grey-colored row
				tr = document.createElement("tr");
				td = document.createElement("td");
				td.innerHTML =  "<div style='background:grey;height:30px'></div>";
				tr.appendChild(td);
				table1.appendChild(tr);
				document.getElementById("imgview").appendChild(table1.cloneNode(true));
				tables[0].appendChild(table1.cloneNode(true)); 
		}

}




function getorganlayers(xmlDoc,tableDoc,lname,sysid,organid,partid,cl)
{
    
	 // Store organ layer records in xml and build their display tables
     // ********************************************************************	 
	organlayer = new Array();
	sys = new Array();
	org = new Array();
	part = new Array();
	layers = new Array();
	// get input elements
	
	// change xml file 
	nodeDoc = tableDoc;
	sys = xmlDoc.getElementsByTagName("System");
	org = sys[sysid].getElementsByTagName("Organ");
	part = org[organid].getElementsByTagName("Part");
	sysname = sys[sysid].childNodes[0].nodeValue;
	orgname = org[organid].childNodes[0].nodeValue;
	
	// get organ layers
	organlayer = org[organid].getElementsByTagName("Organ_Layer");
	orname = org[organid].childNodes[0].nodeValue;

	if(organlayer.length > 0)
		{
		   tables = nodeDoc.getElementsByTagName("Tables");
		   table1 = document.createElement("table");
		   table1.setAttribute("border","1");
		   table1.setAttribute("font-size","30px");
		   tname = sysname+orgname+"organlayertable";
		   tname = tname.replace(/\s|\_|\-/gi,'');  // Strip non-alpha chars out of name
		   table1.setAttribute("id",tname);
		
		    tr = document.createElement("tr");
			th = document.createElement("th");
			th.setAttribute("width","400px");
			th.setAttribute("height","50px");
			th.innerHTML="<big><big><big>"+ "Organ Layer(s) for " + "<font color='"+cl+ "'>"+ orname + "</font>" + " Organ" + "</big></big></big>";
			tr.appendChild(th);
			table1.appendChild(tr);	
   
		   for(or=0;or<organlayer.length;or++)
				{
				   olname = organlayer[or].childNodes[0].nodeValue;
					
					tr = document.createElement("tr");
					td = document.createElement("td");
					td.innerHTML =  "<big><big><big><center>"+ "<font color='" + cl + "'>" + olname + "</font><center></big></big></big>";
					tr.appendChild(td);
					table1.appendChild(tr);
				}
				// End previous table with grey-colored row
				tr = document.createElement("tr");
				td = document.createElement("td");
				td.innerHTML =  "<div style='background:grey;height:30px'></div>";
				tr.appendChild(td);
				table1.appendChild(tr);
				imgview = document.getElementById("imgview");
				imgview.appendChild(table1.cloneNode(true));
				tables[0].appendChild(table1); 
		}
}

function histologicallayers(xmlDoc,tableDoc,lname,sysid,organid,partid,histoid,cl)
{
	   
	 // Store histology records in xml and build their display tables
     // ********************************************************************	 
	
	sys = new Array();
	org = new Array();
	part = new Array();
	layers = new Array();
	// get input elements
	
	// change xml file name
	nodeDoc = tableDoc;
	
	sys = xmlDoc.getElementsByTagName("System");
	org = sys[sysid].getElementsByTagName("Organ");
	part = org[organid].getElementsByTagName("Part");
	histolyr = part[partid].getElementsByTagName("histo_Layer");
	sysname = sys[sysid].childNodes[0].nodeValue;
	orgname = org[organid].childNodes[0].nodeValue;
	partname = part[partid].childNodes[0].nodeValue;
	histoname = histolyr[histoid].childNodes[0].nodeValue;
	
	// histological layer
	hist = part[partid].getElementsByTagName("histo_Layer");
	hl = hist.length;
	
	// create output elements
	layers = nodeDoc.getElementsByTagName("Layers");
    
	// create system component of histology record
	histsys = nodeDoc.createElement("System");
	htext = nodeDoc.createTextNode(sys[sysid].childNodes[0].nodeValue);
	histsys.appendChild(htext);
	layers[0].appendChild(histsys);
	
	// create organ component of histology record
	historg = nodeDoc.createElement("Organ");
	hotext = nodeDoc.createTextNode(org[organid].childNodes[0].nodeValue);
	historg.appendChild(hotext);
	histsys.appendChild(historg);
	
	// create part component of histology record
	histpart = nodeDoc.createElement("Part");
	hptext = nodeDoc.createTextNode(part[partid].childNodes[0].nodeValue);
	histpart.appendChild(hptext);
	historg.appendChild(histpart);
	
	
	prt = part[partid].childNodes[0].nodeValue;
	
	// create subpart component of histology record
	tables = tableDoc.getElementsByTagName("Tables");
    table1 = document.createElement("table");
    table1.setAttribute("border","1");
    table1.setAttribute("font-size","30px");
	tname = sysname+orgname+partname+histoname+"histotable";
	tname = tname.replace(/\s|\_|\-/gi,'');
    table1.setAttribute("id",tname);
	
	
	histlayr = part[partid].getElementsByTagName("histo_Layer");
	if(histlayr.length==0)
		histlayr = part[partid].getElementsByTagName("histo_Layer");
		
	histsublayr = 0;
	histchar = 0;
	hlname = 0;
	hslname = 0;
	hchname = 0;
	hlname = histlayr[histoid].childNodes[0].nodeValue;	
	tr = document.createElement("tr");
	th = document.createElement("th");
	th.setAttribute("width","400px");
	th.setAttribute("height","50px");
	th.innerHTML="<big><big><big>"+ "Histological Layer: " + "<font color='"+cl+ "'>"+ hlname + "</font></big></big></big>";
	tr.appendChild(th);
	table1.appendChild(tr);	
		
	histsublayr = histlayr[histoid].getElementsByTagName("histo_Sublayer");
	tr = document.createElement("tr");
	th = document.createElement("th");
	th.setAttribute("width","400px");
	th.setAttribute("height","50px");
	th.innerHTML="<big><big><big>"+ "Histological Sublayer(s) for " + "<font color='"+cl+ "'>"+ hlname + "</font>" + " Histological Layer" + "</big></big></big>";
	tr.appendChild(th);
	table1.appendChild(tr);	

   for(hsl=0;hsl<histsublayr.length;hsl++)   // Write sublayers
	{
		
			hslname = histsublayr[hsl].childNodes[0].nodeValue;
			tr = document.createElement("tr");
			td = document.createElement("td");
			td.innerHTML =  "<big><big><big><center>"+ "<font color='" + cl + "'>" + hslname + "</font><center></big></big></big>";
			tr.appendChild(td);
			table1.appendChild(tr);	
			
			histchar = histsublayr[hsl].getElementsByTagName("histo_Char");
			tr = document.createElement("tr");
			th = document.createElement("th");
			th.setAttribute("width","400px");
			th.setAttribute("height","50px");
			th.innerHTML="<big><big><big>"+ "Histological Characteristic(s) for " + "<font color='"+cl+ "'>"+ hslname + "</font>" + " Histological Sublayer" + "</big></big></big>";
			tr.appendChild(th);
			table1.appendChild(tr);	
			for(hc=0;hc<histchar.length;hc++)  // Writing histological characteristics
				{
					hcname = histchar[hc].childNodes[0].nodeValue;
					
				
				
					tr = document.createElement("tr");
					td = document.createElement("td");
					td.innerHTML =  "<big><big><big><center>"+ "<font color='" + cl + "'>" + hcname + "</font><center></big></big></big>";
					tr.appendChild(td);
					table1.appendChild(tr);	
					cell = histchar[hc].getElementsByTagName("Cell");
					ecell = histchar[hc].getElementsByTagName("Ecell_Matrix");
					
					   // Write cells and ecells to Table
							for(cl2=0;cl2<cell.length;cl2++)
								{
									if(cl2==0)
										{
											tr = document.createElement("tr");
											th = document.createElement("th");
											th.setAttribute("width","400px");
											th.setAttribute("height","50px");
											th.innerHTML="<big><big><big>"+ "Cell(s) for " + "<font color='"+cl+ "'>"+ hcname + "</font>" + " Histological Characteristics" + "</big></big></big>";
											tr.appendChild(th);
											table1.appendChild(tr);	
										}
									
									cellname = cell[cl2].childNodes[0].nodeValue;
									tr = document.createElement("tr");
									td = document.createElement("td");
									td.innerHTML =  "<big><big><big><center>"+ "<font color='" + cl + "'>" + cellname + "</font><center></big></big></big>";
									tr.appendChild(td);
									table1.appendChild(tr);	
								
								}
							for(cl3=0;cl3<ecell.length;cl3++)
								{
									if(cl3==0)
										{
											tr = document.createElement("tr");
											th = document.createElement("th");
											th.setAttribute("width","400px");
											th.setAttribute("height","50px");
											th.innerHTML="<big><big><big>"+ "Ecell_Matrix(s) for " + "<font color='"+cl+ "'>"+ hcname + "</font>" + " Histological Characteristics" + "</big></big></big>";
											tr.appendChild(th);
											table1.appendChild(tr);	
										}
										
							
									ecellname = ecell[cl3].childNodes[0].nodeValue;
									tr = document.createElement("tr");
									td = document.createElement("td");
									td.innerHTML =  "<big><big><big><center>"+ "<font color='" + cl + "'>" + ecellname + "</font><center></big></big></big>";
									tr.appendChild(td);
									table1.appendChild(tr);	
									
									
									
								}
					  // End of writing cells
					
				}  // End of writing Histological Characteristics
			
			
			
			
	}  // End of writing sublayers
	// End previous table with grey-colored row
	tr = document.createElement("tr");
	td = document.createElement("td");
	td.innerHTML =  "<div style='background:grey;height:30px'></div>";
	tr.appendChild(td);
	table1.appendChild(tr);
	
   document.getElementById("imgview").appendChild(table1.cloneNode(true));
   tables[0].appendChild(table1.cloneNode(true)); 
	
}


	
function doSystems(xmlDoc,nme,nodeDoc,tableDoc)  // main recursive function that generates hierarchical display, and calls functions for 
{                                               // graphical and table display
   
	var sysname = new Array();
	var orgname = new Array();
	var partname = new Array();
	var sname = new Array();
	var oname = new Array();
	var pname = new Array();
	var hname = new Array();
	var histolayername = new Array();
	
	var count = 0;
	var systop = 0;
	var height = 85;
	var thisOrganSelected = new Array();
	var thisPartSelected = new Array();
	var thisCellSelected = new Array();
	var thisCellStaySelected = new Array();
	
	var systemcolor = new Array();
	systemcolor[0] = "green";
	systemcolor[1] = "SlateBlue";
	systemcolor[2] = "Brown";
	systemcolor[3] = "Orange";
	systemcolor[4] = "MediumVioletRed";
	systemcolor[5] = "Indigo";
	systemcolor[6] = "Olive";
	systemcolor[7] = "SpringGreen";
	systemcolor[8] = "Chocolate";
	systemcolor[9] = "Grey";
	systemcolor[10] = "GoldenRod";  
	
	
	document.getElementById("hierdiv").innerHTML="";
	
	
	if(nodeDoc==null)
		{
		var nodeDoc = getXMLDoc2();
		tp = nodeDoc.getElementsByTagName("top")[0];
		}
	
	if(tableDoc==null)
		{
		var tableDoc = getXMLDoc3();
		tp = tableDoc.getElementsByTagName("top")[0];
		
		}
	
	    // Adjust Table Zoom
	    var $bwidth = $(document.body).width();
	/*	var $ofwidth = $('#outframe').width();
		var fac = (1.2*$bwidth)/$ofwidth;
		$('#outframe').css('zoom',fac);  */
	
	
	var systems=xmlDoc.getElementsByTagName("System");
	
	if(systems)
	{
			 // initialize variables for click-organ selections	
			// produce system nodes		
			var openthissystemsorgans = false;
				
			
			for (i=0;i<systems.length;i++)
			   {   
			   
				if(systems[i].childNodes[0].nodeValue != "null")
					{
						   // Build name system for node
						   systop = systop+height;
						   sysname[i] = systems[i].childNodes[0].nodeValue;
						   tname = sysname[i];
						   sname[i] = tname;
						   name = tname + "_" + "1" + "-" + i;    // Node index built into name
						   
						   //  building node HTML
						   od = document.createElement("div");
						   od.innerHTML = "<div class = 'sys_od' style='top:"+ (systop) + "px' ></div>";
						   id1 = document.createElement("div");
						   id1.innerHTML = "<div class='sys_id1'></div>";
						   od.firstChild.appendChild(id1);
						   id2 = document.createElement("div");
						   id2.innerHTML = "<div class='sys_id2' style='color:" + systemcolor[i] + "'>" +  tname + "</div>";
						   id2.setAttribute("id",name);
						   id2.setAttribute("name",name); 
						  
						   od.firstChild.appendChild(id2);
						   id3 = document.createElement("div");
						   id3.innerHTML = "<div style='position:relative;margin:10px;width:300px;height:100px;font-size:25px;left:75px;top:-100px;color:black' class='imdiv'>Click to Open</div>";
						   
						 
						   od.firstChild.appendChild(id3);
						   document.getElementById("hierdiv").appendChild(od);    // create HTML display
						   var odd = document.getElementById(name);
						
						
						   // Set up OnClick for Node
						   odd.onclick=function()
						   {
						   
						   id = this.getAttribute("id");
						   el = document.getElementById(id).nextSibling.childNodes[0];
						   if(el.innerHTML=="Click to Open")
						   {
								
							   // add node to active node xml record
							   nm = this.getAttribute("name");
							
							   var nme = nm.split("_1-");  // raw name
							
							   // split out index for thisOrganSelected
							   var indx = nm.split("_");
							   indx = indx[indx.length-1];
							   indx2 = indx.split("-");
							   indx3 = indx2[0] + indx2[1];
							   
							  // add node to xml record of active nodes used to draw nodes
							   addNode(xmlDoc,nodeDoc,tableDoc,nm,"system",systemcolor[indx2[1]],indx2[1],"","","");
							  
												   
							   // store xml variable for whether to open organ display to true
							   select = nodeDoc.getElementById(nm+"openthis");
							   if(!select)
									{
							   
									   select = nodeDoc.getElementsByTagName("Select");
									   openThisSystemsOrgans = nodeDoc.createElement("openThisSystemsOrgans");
									   openThisSystemsOrgans.setAttribute("id",nm+"openthis");
									   openThisSystemsOrgans.setAttribute("name",nm);
									   openThisSystemsOrgans.setAttribute("value","true");
									   select[0].appendChild(openThisSystemsOrgans);
									 }
								else
									{
										select.setAttribute("value","true");
									}
							   doSystems(xmlDoc,nm,nodeDoc,tableDoc);
							
							   id = this.getAttribute("id");
							   el = document.getElementById(id).nextSibling.childNodes[0];
							   el.style.color="green";
							   el.innerHTML ="Click to Close";
							   el.focus();
							   
								
						   }
						   else if( el.innerHTML == "Click to Close")
								{
									  
								   nm = this.getAttribute("name");
								   var anode = nm + "_anode";
								   
								   // Indices of system for specific display node
								   var indx = nm.split("_");
								   indx = indx[indx.length-1];
								   indx2 = indx.split("-");
								   indx3 = indx2[0] + indx2[1];
								   
								   
									// Remove element node from XML tree
									sy = nodeDoc.getElementById(nm);
									sy.parentNode.removeChild(sy);
						
									 // Set display of Organs to false
									select = nodeDoc.getElementById(nm+"openthis");
									select.setAttribute("value","false");
				
								 doSystems(xmlDoc,nm,nodeDoc,tableDoc);
									
							   } 
							  else;
					
			
						   }   // End of onclick
			
							//ORGANS Section
							openthissystemsorgans = false;
						
							// Retrieve xml variable to determine whether to open Organs
							if(nodeDoc.getElementById(name+"openthis"))
								{
									
									select = nodeDoc.getElementById(name+"openthis");
									if(select)
										{
											
										   if(select.getAttribute("value")=="true")
												{
													openthissystemsorgans = true;
													 el = document.getElementById(name).nextSibling.childNodes[0];
													 el.style.color="green";
													 el.innerHTML ="Click to Close";
													 
												}
										   else if(select.getAttribute("value")=="false")
												{
													
													openthissystemsorgans = false;
													select.parentNode.removeChild(select);
													
												}  
										}	
											
								}			
							
			
							var orgtop = systop;   
							var organs = systems[i].getElementsByTagName("Organ"); 
							
							if(organs && openthissystemsorgans)
								{    
								  
								   var lnames = new Array();
								   var openthisorgansparts = "";
								   for (j=0;j<organs.length;j++)
									 {
									   
										if(j==0)
										{
										orgtop = orgtop+height+50;
										}
										else
											orgtop = orgtop+height;
										 
										 //Build name system for node
										 name = organs[j].childNodes[0].nodeValue;
										 oname[j] = name;
										 orgname[j] = sysname[i] + "_" + name;
										 var lname = orgname[j] + "_" + "1" + "-" + i + "-" + j;  //node index built into name
																	
										//  building node HTML
										od = document.createElement("div");
										od.innerHTML = "<div class = 'org_od' style='top:"+ (orgtop) + "px' ></div>";
										
										id1 = document.createElement("div");
										id1.innerHTML = "<div class='org_id1'></div>";
										od.firstChild.appendChild(id1);
										
										id2 = document.createElement("div");
										id2.innerHTML = "<div class='org_id2' style='color:" + systemcolor[i] + "'>" + "ORGAN:  " + name + "</div>";
										id2.setAttribute("id",lname);
										id2.setAttribute("name",lname); 
										od.firstChild.appendChild(id2);
										
										id3 = document.createElement("div");
										id3.innerHTML = "<div style='position:relative;margin:10px;width:300px;height:100px;font-size:25px;left:75px;top:-100px;color:black' class='imdiv'>Click to Open</div>";
										od.firstChild.appendChild(id3);
										document.getElementById("hierdiv").appendChild(od);         

									   // Events for adding and deleting a ORGAN node from display
									   odd = document.getElementById(lname);
									   odd.onclick=function()
										   {
											   id = this.getAttribute("id");
											   el = document.getElementById(id).nextSibling.childNodes[0];
											   if(el.innerHTML=="Click to Open")
												   {
														// add node to xml for active nodes
													   nm = this.getAttribute("name");   // get specific name attribute for node
												
													   // indices for system, organs for specific display node
													   var indx = nm.split("_");
													   indx = indx[indx.length-1];
													   indx2 = indx.split("-");
													   indx3 = indx2[0].toString() + indx2[1].toString() + indx2[2].toString();
														
													   // Add node to xml record of active nodes
													   addNode(xmlDoc,nodeDoc,tableDoc,nm,"organ",systemcolor[indx2[1]],indx2[1],indx2[2],"","");
																							
													   // store xml variable for whether to open Part display to true
													   select = nodeDoc.getElementById(nm+"openthis");
													   if(!select)
															{
													   
															   select = nodeDoc.getElementsByTagName("Select");
															   openThisOrgansParts = nodeDoc.createElement("openThisOrgansParts");
															   openThisOrgansParts.setAttribute("id",nm+"openthis");
															   openThisOrgansParts.setAttribute("name",nm);
															   openThisOrgansParts.setAttribute("value","true");
															   select[0].appendChild(openThisOrgansParts);
															   doSystems(xmlDoc,nm,nodeDoc,tableDoc);  // redraw gui
															}
														else
															{
																select.setAttribute("value","true");
															}
													   
													   getorganlayers(xmlDoc,tableDoc,nm,indx2[1],indx2[2],"",systemcolor[indx2[1]]);
													
													   id = this.getAttribute("id");
													   el = document.getElementById(id).nextSibling.childNodes[0];
													   el.style.color="green";
													   el.innerHTML ="Click to Close";
													   el.focus();
												
												   }
											   else if( el.innerHTML == "Click to Close")
												   {
													   nm = this.getAttribute("name");
													   var anode = nm + "_anode";
													  
													   var nme = nm.split("_1-");  // raw name
													   nme = nme[0];
													  
													  // find specific node and delete
													   var indx = nm.split("_");
													   indx = indx[indx.length-1];
													   indx2 = indx.split("-");
													   indx3 = indx2[0].toString() + indx2[1].toString() + indx2[2].toString();
													 
													   // Set display of Parts to false
														select = nodeDoc.getElementById(nm+"openthis");
														select.setAttribute("value","false");
										
														// Remove element node from XML tree
														or = nodeDoc.getElementById(nm);
														or.parentNode.removeChild(or);
													
														doSystems(xmlDoc,nm,nodeDoc,tableDoc);
														// clear image view
														
														// Remove organlayer table from display
														tablename = nme+"organlayertable";
														tablename = tablename.replace(/\s|\-|\_/gi,'');
														thistable = document.getElementById(tablename);
														thistable.parentNode.removeChild(thistable);
														
												   } 

										   }  // end of onclick
										   
										// PART SECTION
														  
									  // Retrieve xml variable to tell whether to Open Parts
										openthisorgansparts = false;
										select = nodeDoc.getElementById(lname+"openthis");
										if(select)
											{
												
											   if(select.getAttribute("value")=="true")
													{
														openthisorgansparts = true;
														 el = document.getElementById(lname).nextSibling.childNodes[0];
														 el.style.color="green";
														 el.innerHTML ="Click to Close";
														 
													}
												   else if(select.getAttribute("value")=="false")
													{
														
														openthisorgansparts = false;
														select.parentNode.removeChild(select);
														
													}  
											}			
									
										var prttop = orgtop;
										var parts = organs[j].getElementsByTagName("Part");
										 
										if(parts && openthisorgansparts)
											{
											   
												var openthispartscells = "";
												for (k=0;k<parts.length;k++)
												 {
											
													if(k==0)
														{
															prttop = prttop+height+50;
														}
													else if(k==(parts.length))
														{
															orgtop = orgtop+height+50;
														}
													
													else
													  prttop = prttop + height;
													  
													  
													name = parts[k].childNodes[0].nodeValue;
													pname[k] = name;
													partname[k] = orgname[j] + "_" + name;
													var lname = partname[k] + "_" + "1" + "-" + i + "-" + j + "-" + k;
													
													// Building node HTML			
													od = document.createElement("div");
													od.innerHTML = "<div class = 'prt_od' style='top:"+ (prttop) + "px' ></div>";
													
													id1 = document.createElement("div");
													id1.innerHTML = "<div class='prt_id1'></div>";
													od.firstChild.appendChild(id1);
													
													id2 = document.createElement("div");
													id2.innerHTML = "<div class='prt_id2' style='color:" + systemcolor[i] + "'>" + "PART:  " + name + "</div>";
													id2.setAttribute("id",lname);
													id2.setAttribute("name",lname); 
													od.firstChild.appendChild(id2);
													
													var id3 = document.createElement("div");
													id3.innerHTML = "<div style='position:relative;margin:10px;width:300px;height:100px;font-size:25px;left:75px;top:-100px;color:black' class='imdiv'>Click to Open</div>";
													od.firstChild.appendChild(id3);
													document.getElementById("hierdiv").appendChild(od); 
												
													// Events for adding and deleting a Part node from display
													odd = document.getElementById(lname);
													odd.onclick=function()
													   {
														   id = this.getAttribute("id");
														   el = document.getElementById(id).nextSibling.childNodes[0];
														   if(el.innerHTML=="Click to Open")
																  {
																	
																	// add node to xml for active nodes
																   nm = this.getAttribute("name");  // get specific name attribute for node
															 
																   // indices for system, organ, part for this specific display node
																   var indx = nm.split("_");
																   indx = indx[indx.length-1];
																   indx2 = indx.split("-");
																   indx3 = indx2[0].toString() + indx2[1].toString() + indx2[2].toString() + indx2[3].toString();
																   
																   // Add display node to Active Nodes xml record
																   addNode(xmlDoc,nodeDoc,tableDoc,nm,"part",systemcolor[indx2[1]],indx2[1],indx2[2],indx2[3],"");
																	
																														   
																	// store xml variable for whether to open Part display to true
																   select = nodeDoc.getElementById(nm+"openthis"); 	
																   if(!select)
																		{
																		   select = nodeDoc.getElementsByTagName("Select");
																		   openThisPartsCells = nodeDoc.createElement("openThisPartsCells");
																		   openThisPartsCells.setAttribute("id",nm+"openthis");
																		   openThisPartsCells.setAttribute("name",nm);
																		   openThisPartsCells.setAttribute("value","true");
																		   select[0].appendChild(openThisPartsCells);
																		 }
																	else
																		{
																			select.setAttribute("value","true");
																		}
																   
																																											   
																   // Store xml variable for organ layer and subpart
																	getsubparts(xmlDoc,tableDoc,nm,indx2[1],indx2[2],indx2[3],systemcolor[indx2[1]]);
																	
																   doSystems(xmlDoc,nm,nodeDoc,tableDoc);   // Redraw gui
																   
																   id = this.getAttribute("id");
																   el = document.getElementById(id).nextSibling.childNodes[0];
																   el.style.color="green";
																   el.innerHTML ="Click to Close";
																   el.focus();
														
																 
																	}
															   else if( el.innerHTML == "Click to Close")
																	{
																	   nm = this.getAttribute("name");
																	   var anode = nm + "_anode";
																	  
																	   var nme = nm.split("_1-");  // raw name
																	   nme = nme[0];
																	   
																	   // find specific node and delete
																	   var indx = nm.split("_");
																	   indx = indx[indx.length-1];
																	   indx2 = indx.split("-");
																	   indx3 = indx2[0].toString() + indx2[1].toString() + indx2[2].toString() +indx2[3].toString() ;
													
																		// Set display of Parts to false
																		select = nodeDoc.getElementById(nm+"openthis");
																		select.setAttribute("value","false");
																		
																		// Remove element node from Active Nodes XML tree
																		pr = nodeDoc.getElementById(nm);
																		pr.parentNode.removeChild(pr);
																																		
																		doSystems(xmlDoc,nm,nodeDoc,tableDoc);
																		
																		// Remove subpart table from image view
																		tablename = nme + "subparttable";
																		tablename = tablename.replace(/\_|\s|\-/gi,'');
																		thistable = document.getElementById(tablename);
																		thistable.parentNode.removeChild(thistable);  
																		
																   } 
														}  // End of onclick
													
													// HISTOLOGICAL LAYER Section, used to be CELL section
													 // Retrieve xml variable to tell whether to Open hist layers
													openthispartscells = false;
													
												   select = nodeDoc.getElementById(lname+"openthis");	
												   if(select)
													{
														
														if(select.getAttribute("value")=="true")
															{
																 openthispartscells = true;
																 el = document.getElementById(lname).nextSibling.childNodes[0];
																 el.style.color="green";
																 el.innerHTML ="Click to Close";
																 
															}
														else if(select.getAttribute("value")=="false")
															{
																
																openthispartscells = false;
																select.parentNode.removeChild(select);
																
															}  
													}			
												
													var celltop = prttop;
													var cells = 0;
													var ecells = 0;
													var histolayers = parts[k].getElementsByTagName("histo_Layer");  // Get cells from XML
												
													//Get node selection status from XML
												 if(histolayers && openthispartscells)   
													{
													   
														for (m=0;m<histolayers.length;m++)
														{
															if(m==0)
															{
															  celltop = celltop+height+50;
															}
															else
															  celltop = celltop + height;	
															
															name = histolayers[m].childNodes[0].nodeValue;
															hname[m] = name;
															histolayername[m] = partname[k] + "_" + name;
															var lname = histolayername[m] + "_" + "1" + "-" + i + "-" + j + "-" + k + "-" + m;
														
															// Build HTML for nodes		
															od = document.createElement("div");
															od.innerHTML = "<div class = 'cell_od' style='top:"+ (celltop) + "px' ></div>";
															
															id1 = document.createElement("div");
															id1.innerHTML = "<div class='cell_id1'></div>";
															od.firstChild.appendChild(id1);
															
															id2 = document.createElement("div");
																												
															id2.innerHTML = "<div class='cell_id2' style='color:" + systemcolor[i] + "'>" + "Histological Layer:  " + name + "</div>";
															
															id2.setAttribute("id",lname);
															id2.setAttribute("name",lname); 
															od.firstChild.appendChild(id2);
															
															// Set histology node to open or close
															
														// Retrieve xml variable to tell whether to Open Cells
															var open = false
															select = nodeDoc.getElementById(lname+"openthis");
															if(select)
																{
																   if(select.getAttribute("value")=="true")
																		open = true;
																   else if(select.getAttribute("value")=="false")
																		open = false;
																}	
															if(open == true)
																{
																
																 id3 = document.createElement("div");
																 id3.innerHTML = "<div style='position:relative;margin:10px;width:300px;height:100px;font-size:25px;left:33%;top:-100px;color:green;margin:15px' class='imdiv'>Click to Close</div>"; 
																 od.firstChild.appendChild(id3);
																 document.getElementById("hierdiv").appendChild(od); 
													
																}
															else if(open == false)
																{
																	id3 = document.createElement("div");
																	id3.innerHTML = "<div style='position:relative;margin:10px;width:300px;height:100px;font-size:25px;left:33%;top:-100px;color:black;margin:15px' class='imdiv'>Click to Open</div>"; 
																	od.firstChild.appendChild(id3);
																	document.getElementById("hierdiv").appendChild(od); 
																}
										
															// Events for adding and deleting a node from display
															odd = document.getElementById(lname);
															odd.onclick=function()
																	{
																	   id = this.getAttribute("id");
																	   nm = this.getAttribute("name");
																	   el = document.getElementById(id).nextSibling.childNodes[0];
																	   if(el.innerHTML=="Click to Open")
																			{
																			   nm = this.getAttribute("name");   // get specific name attribute for node
																		   
																				// split out indices for parent and thisCellSelected
																			   var indx = nm.split("_");
																			   indx = indx[indx.length-1];
																			   indx2 = indx.split("-");
																			   pndx = indx2[3];
																			   cndx = indx2[4];
																			   indx3 = indx2[3].toString() + indx2[4].toString();
																			
																			   str = this.innerHTML;
																			   
																			   // add node to xml reocrd
																			   addNode(xmlDoc,nodeDoc,tableDoc,nm,"histo",systemcolor[indx2[1]],indx2[1],indx2[2],indx2[3],indx2[4]);
																			
																			   // store xml variable for whether to open Histological Layer Table display to true
																			   select = nodeDoc.getElementById(nm+"openthis");
																			   if(!select)
																					{
																					   select = nodeDoc.getElementsByTagName("Select");
																					   openThisHistologicalLayer = nodeDoc.createElement("openThisHistologicalLayer");
																					   openThisHistologicalLayer.setAttribute("id",nm+"openthis");
																					   openThisHistologicalLayer.setAttribute("name",nm);
																					   openThisHistologicalLayer.setAttribute("value","true");
																					   select[0].appendChild(openThisHistologicalLayer);
																					}
																				else
																					{
																						select.setAttribute("value","true");
																					}
																			
																			   // generate histological tables
																			   histologicallayers(xmlDoc,tableDoc,nm,indx2[1],indx2[2],indx2[3],indx2[4],systemcolor[indx2[1]]);
																																																				 
																			   //redraw node
																			   document.getElementById("hierdiv").innerHTML="";
																			   doSystems(xmlDoc,nm,nodeDoc,tableDoc);
																			
																			   id = this.getAttribute("id");
																			   el = document.getElementById(id).nextSibling.childNodes[0];
																			   el.style.color="green";
																			   el.innerHTML ="Click to Close";
																			   el.focus();
																			}
																	   else if( el.innerHTML == "Click to Close")
																			{
																			   // Parse Name info
																			   var indx = nm.split("_");
																			   indx = indx[indx.length-1];
																			   indx2 = indx.split("-");
																			
																			   nm = this.getAttribute("name");
																			   var anode = nm + "_anode";
																		
																				var nme = nm.split("_1-");  // raw name
																				nme = nme[0];
																				
																				// Set display of Histological Tables to false
																				select = nodeDoc.getElementById(nm+"openthis");
																				select.setAttribute("value","false");
																																			
																				// Delete Active XML Node
																				hs = nodeDoc.getElementById(nm);
																				hs.parentNode.removeChild(hs);
																			
																				doSystems(xmlDoc,nm,nodeDoc,tableDoc);
																				
																				// Remove histological table from image view
																				tablename = nme+"histotable";
																				tablename = tablename.replace(/\s|\_|\-/gi,'');
																				thistable = document.getElementById(tablename);
																				thistable.parentNode.removeChild(thistable);
																					
																			}   // End of  Else if Click to Close
																	}  // End of onclick
															//drawNodes(nodeDoc,tableDoc,i,j,k,m);
														}  // end of for histological layers
														prttop = celltop;
													}  // end of if parts, END of PART section
													//drawNodes(nodeDoc,tableDoc,i,j,k,0);
												}  // end of for parts
											 orgtop = prttop;
										}  // end of if parts
										//drawNodes(nodeDoc,tableDoc,i,j,0,0);
									}  // end of for organs
								  systop = orgtop;
							}  // end of if organs, END of Systems section
							//drawNodes(nodeDoc,tableDoc,i,0,0,0);
					}
				}  // end of for systems
		}  // end if systems
	drawNodes(nodeDoc,tableDoc);	
	
} // end of doSystems

     


function JQFunctions()   // loads html of gui on body load
{



var gui = '<div id="outframe"><div id="topbar" style="position:relative;width:2670px;font-size:50px;text-align:center">Organism Relation Ontology (ORO) Miner</div>\
	<div id="hholder">\
	<div id ="htitle" >Hierarchical View</div><div id = "gtitle">Graph View</div><div id="ttitle">Table Display</div>\
	</div>\
	<div id="outrdiv">\
	<div id="hierdiv" style="position:relative;left:0px;top:-1px;width:903px;height:1001px;border:2px solid black;border-left:0;border-top:0;border-bottom:0;\
	overflow-x:scroll;overflow-y:scroll"></div><div id="grahdr" style="z-index:1;position:relative;left:904px;top:-1002px;width:1093px;height:56px;border:2px solid black;\
	border-top:0;border-left:0;border-right:0"><div></div><div></div></div><div id="grview" class="thisdiv" style="position:relative;font-size:200%;left:904px;top:-998px;width:1093px;\
	height:941px;border:2px solid black;border-top:0;border-bottom:0;border-right:0;border-left:0;"><svg id="mySVG" width="1093px" height="941px" viewBox = "0 0 4000 4000" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
</svg></div>\
	<div id="imgview" style="position:relative;font-size:200%;left:1998px;top:-2001px;width:644px;height:1003px;border:2px solid black;border-top:0;border-bottom:0;\
	border-right:0;overflow-x:scroll;overflow-y:scroll"></div></div></div>';
    

document.getElementById("gui").innerHTML = gui;

var hlist_xml = "http://www.rlsworks.com/xml/oro_xml.xml";
buildHView(hlist_xml);  // initiate xml database retreival and hierachical display

	
}

// END OF JAVASCRIPT FUNCTIONS --------------------------------------------------------------------------------
</script>


<div id="gui" name="gui"></div>

<div><input type="hidden" id="hidval" value=""/></div>
