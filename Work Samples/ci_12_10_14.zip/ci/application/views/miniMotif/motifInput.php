<script type="text/javascript">
function mobileLoader(message)
	{
	
			$('#wait').html('');
			$("#wait").append("<p id='loaderMessage'>"+message+"</p><img src='<?php echo $loaderImage; ?>'>");

		var i = 0;
		setInterval(function()
			{
				$('#wait img').css({"transform": "rotate("+(30*i)+"deg)"});
				i++;
			},50 ); 
	}
	
	
function JQFunctions()
	{
	
	$('.aButton2')
	    .on('mouseover',function()
			{
				$(this)
					.css('color','blue')
					.css('background-color','#C0C0C0');
			})
		.on('mouseleave',function()
			{
				$(this)
					.css('color','black')
					.css('background-color','white');
			})
		.on('mousedown',function()
			{
				$(this)
					.css('background-color','grey')
					.css('box-shadow','2px 2px 2px blue')
					.css('color','blue');
			
			})
		  .on('mouseup',function()
			{
				$(this)
					.css('background-color','white')
					.css('box-shadow','none')
					.css('color','black');
			});		
			
			
			
			
			
	}

function valInput()
{
var inform = document.forms["filein"];
var fnm = inform.elements["fname"].value;
var rcvid = "wait";

if(!fnm.match(/(\w|\d|(\Q-_\E))*\.txt/))
  {
  var inform = document.forms["filein"];
  inform.elements["fname"].value = "Please input a FASTA type file";
  }
else
   {
          var mess = "Please Wait while Database Tables are being Built!";
          makeRequest(fnm,rcvid,"no",mess);

   }
}



function getXMLHttp()
{
  var xmlHttp

  try
  {
    //Firefox, Opera 8.0+, Safari
    xmlHttp = new XMLHttpRequest();
  }
  catch(e)
  {
    //Internet Explorer
    try
    {
      xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    catch(e)
    {
      try
      {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
      }
      catch(e)
      {
        alert("Your browser does not support AJAX!")
        return false;
      }
    }
  }
  return xmlHttp;
}

function makeRequest(snd,recid,drp,mess)
{
        mobileLoader(mess);
		$.ajax(
			
				{
					type: "GET",
					
					url: "http://www.rlsworks.com/getMotifs/getMotifs.php?dropDb="+drp+"&file="+snd,
					success:function(result)
						{
						  
							$('#'+recid).html(result);
							
						},
					cache:false
				});
}
 
function makeRequest2(snd,recid,mess)
{
 
	mobileLoader(mess);
  	$.ajax(
				
				{
					type:	"GET",
					url: "http://www.rlsworks.com/getMotifs/getMotifs.php?motif="+snd,
					success:function(result)
						{
						  
							$('#'+recid).html(result);
							
						},
					cache:false
				});
   
}

function dropDb()
{
 
  makeRequest("none","wait","yes");
}


function HandleResponse(response,recid)
{
  
   document.getElementById(recid).innerHTML = response;
}


function clearInput()
{
  var inform = document.forms["filein"];
  inform.elements["fname"].value = "";
  document.getElementById("wait").innerHTML = "";
}

function doSearch()
{
var am1 = document.getElementById("am1").value;
var am2 = document.getElementById("am2").value;
var qu = document.getElementById("qu").value;
var recid = "wait";
//if(am1 && am2 && qu)
  //{
    var fnm = am1 +  am2 + qu;
    var mess = "Please Wait for Database Response!";
    makeRequest2(fnm,recid,mess);
    
 // }
}

</script>
		<div id="mmContainer">
			<h1>Input Form for Minimotif Search</h1>
			<div id="inputdiv" >  
				<div id="fileinput" style="position:relative;float:left;font-size:1.1em;border-style:solid;border-width:1px;height:20%;background-color:rgb(220,220,220)">
					<form id="filein">
						<div id="filecapt">
							<p>Input the file name (FASTA-TEST.txt) below.  If database or tables already exist you can Drop-the-Database 'rlsworks_proteins'
								to begin again.  Another file can be used but it must be in the FASTA format (.txt extension)
							</p>
						    <div>
							    <div class="inputC">File Name:&nbsp&nbsp<input class="fsiz" type="text"  onclick="clearInput()" name="fname" value=""/></div>
								<div class="aButton2" type="button"  onclick="valInput()" style="margin-right:5%">Verify File and Start Database Build</div>
								<div class="aButton2" type="button" onclick="dropDb()">Drop Database</div>
							</div>
					</form>
							
				</div>
						
				</div>
				<div id="motifsel" >
					<form id="aminocodes">
						<p>Select below the first and last letter codes for minimotif sequence you
							want to search.  (e.g. P and G for Px.....xG where x is any other amino acid code).
						</p>

						<select id="am1" name="am1" class="fsiz" >
						  <option value="G">G - Glycine</option>
						  <option value="A">A - Alanine</option>
						  <option value="V">V - Valine</option>
						  <option value="L">L - Leucine</option>
						  <option value="I">I - Isoleucine</option>
						  <option value="M">M - Methionine</option>
						  <option value="F">F - Phenylalanine</option>
						  <option value="W">W - Tryptophan</option>
						  <option value="P">P - Proline</option>
						  <option value="S">S - Serine</option>
						  <option value="T">T - Threonine</option>
						  <option value="C">C - Cysteine</option>
						  <option value="Y">Y - Tyrosine</option>
						  <option value="N">N - Asparagine</option>
						  <option value="Q">Q - Glutaminie</option>
						  <option value="D">D - Aspartic Acid</option>
						  <option value="E">E - Glutamic Acid</option>
						  <option value="K">K - Lysine</option>
						  <option value="R">R - Arginine</option>
						  <option value="H">H - Histidine</option>
						</select><div id="mobX"><span style="margin-left:5px">X....X</span></div>
						<select id="am2" name="am2" class="fsiz">
						  <option value="G">G - Glycine</option>
						  <option value="A">A - Alanine</option>
						  <option value="V">V - Valine</option>
						  <option value="L">L - Leucine</option>
						  <option value="I">I - Isoleucine</option>
						  <option value="M">M - Methionine</option>
						  <option value="F">F - Phenylalanine</option>
						  <option value="W">W - Tryptophan</option>
						  <option value="P">P - Proline</option>
						  <option value="S">S - Serine</option>
						  <option value="T">T - Threonine</option>
						  <option value="C">C - Cysteine</option>
						  <option value="Y">Y - Tyrosine</option>
						  <option value="N">N - Asparagine</option>
						  <option value="Q">Q - Glutaminie</option>
						  <option value="D">D - Aspartic Acid</option>
						  <option value="E">E - Glutamic Acid</option>
						  <option value="K">K - Lysine</option>
						  <option value="R">R - Arginine</option>
						  <option value="H">H - Histidine</option>
						</select>
							<select id="qu" name="qu">
							  <option value="X">Select which Search that you want to do.</option>
							  <option value="0">Get All Accession Numbers for chosen miniMotif</option>
							  <option value="1">Get All Motif Instances in All Proteins</option>
							  <option value="2">Get Start Positions of selected Motif in All Proteins</option>
							  <option value="3">Get Number of Motifs for Each Protein</option>
							  <option value="4">Get All Species Names in which selected Motif occurs</option>
							  <option value="5">Get Average Length of All Proteins for the selected Motif</option>
							</select>
						</br><input id="subButton" type="button" class="fsiz show-page-loading-msg" data-textonly="false" data-textvisible="true"  data-msgtext=""
						data-inline="true" onclick="doSearch()" value="Submit Search"/></br></br>
					</form>
				</div>
				
			</div>
			<div id="wait">
			</div>
		</div>
