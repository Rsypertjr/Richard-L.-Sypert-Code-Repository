<?php
<html>
<head>
</head>
<body onload="{window.location.assign("http://docs.google.com/gview?embedded=true&url=http://rlsworks.com/pdf/RichardSypertJrResumePDF.pdf");}">

</body>
</html>





?>