<script type="text/javascript">

//JavaScript in Body 

function JQFunctions()
	{;}
</script>

<div id="showPDFDiv">
	<object data="http://www.rlsworks.com/pdf/<?php echo $pdfFileName;?>" type="application/pdf" width="100%" height="70%">
		alt : <a href="http://www.rlsworks.com/pdf/<?php echo $pdfFileName;?>"><?php echo $pdfFileName;?></a>
	</object>
</div>