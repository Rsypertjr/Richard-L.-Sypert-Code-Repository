<?php

   header( 'Location: http://www.rlsworks.com/ci/mobile');

?>