<html>
<head>
	<!--  the following two lines load the jQuery library and JavaScript files -->
    <script src="<?php echo $jqueryloc; ?>" type="text/javascript"></script>
    <script src="<?php echo $jqfile; ?>" type="text/javascript"></script>
	
	<script type="text/javascript">
	
     function JQFunctions()
			{
				$('#from input[name="fromField"]').bind('click', function()
					{
					 $(this).val('');
					});
					
				$('#name input[name="nameField"]').bind('click', function()
					{
					 $(this).val('');
					});
					
				$('#Bcc input[name="bccField"]').bind('click', function()
					{
					 $(this).val('');
					});
					
				$('#Cc input[name="ccField"]').bind('click', function()
					{
					 $(this).val('');
					});
					
				$('#subject input[name="subject"]').bind('click', function()
					{
					 $(this).val('');
					});
					
				$('#message textarea[name="mess"]').bind('click', function()
					{
					 $(this).val('');
					});
			}
	</script>
	
	
	<style type="text/css">
		body {postion:relative;width:1000px;height:600px;border: 4px solid tan;background-color:tan}
		#topbar {position:relative;width:auto;height:5%;background-color:tan;font-size:1.5em; padding-left:25px;padding-bottom:15px;padding-right:20px}
		.submit {float:right;margin:2px;height:auto;width:150px;border:2px solid black;background-color:orange;font-size:0.9em}
		#emailContainer {position:relative;width:auto;height:85%;background-color:beige}
		#leftcol {position:relative;float:left;width:30%;height:auto;border:4px ridge tan}
		#rightcol {position:relative;float:right;width:60%;height:auto;border:4px ridge tan;margin-right:7%}
		#leftcol, #rightcol {margin:5px}
		.nameField, .fromField, .bccField,.ccField {position:relative;width:75%;color:grey}
		#from, #name, #Bcc, #Cc, #subject, #message {position:relative;width:95%;margin-left:30px}
		.subj  {position:relative;width:71%}
		.subj, .mess {color:grey;margin-left:40px}
	</style>
</head>

<body onload="JQFunctions()">
	<?php echo validation_errors(); ?>
		<?php 
				$attributes = array('id'=>'emailform');
				echo form_open('othello/processEmail',$attributes); 
		?>
			<div id="topbar">Send Email To Richard L. Sypert Jr.<input type="submit" name="submit" class="submit" value="SEND Email"/></div>
			<div id="emailContainer">
				
						<div id="leftcol">
						
							<p id="name">
								Name:&nbsp; <input name="nameField" class="nameField" type="text" value="Your Name"/>
							</p>
						
							<p id="from">
								From:&nbsp; <input name="fromField" class="fromField" type="text" value="yourEmail@example.com"/>
							</p>
														
							<p id="Bcc">
								Bcc:&nbsp; <input name="bccField" class="bccField" type="text" value="Enter Bcc"/>
							</p>
							
							<p id="Cc">
								Cc:&nbsp; <input name="ccField" class="ccField" type="text" value="Enter Cc"/>
							</p>
						</div>
						<div id="rightcol">
							<p id="subject">
								<input name="subject" class="subj" type="text" value="Enter Email Subject"/>
							</p>
							<p id="message">
								<textarea name ="mess" class="mess" rows="25" cols="60">Enter message here</textarea>
								
							</p>
						</div>
			</div>
			<input type="hidden" name="emailType" value='<?php echo $emailType ?>'/>
	</form>
</body>


</html>