<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">-->



        <script type="text/javascript">
            function JQFunctions()
                {              
         
		            // Hide Buttons from display
					  $('#clickdiv1').hide();
					  $('#clickdiv2').hide();
					  $('#clickdiv3').hide();
					  $('#clickdiv4').hide();
					  $('#clickdiv5').hide(); 
					  $('#clickdiv6').hide(); 
							 
						// Prepare Description to Show
					  $('#description').css('color','green');
					  $('#description').css('font-size','1.8em');
					  $('#description').css('padding','20px');
					  $('#description').show(); 

					// Animate fade on background
					$(document).mousemove(function()
						{
						  $('#oframebg')
								.animate({opacity:"0.20"},2000)
								.animate({opacity:"0.70"},2000);
						
						});
					
					
					
					// Set up Hover over Button Display  and Default Description
					   $('.docbuttons').bind('mouseover',function()
						{
							$(this).css('background-color','tan');
							
						});	
							
					   $('.docbuttons').bind('mouseleave',function()
						{
							$(this).css('background-color','white');
							$('#description').css('text-align','center');
							$('#description').html('Hover over Document Title for its Descripition. <p><span style="color:green;font-style:italic" id="clkmess">Then Click the Blinking Button That will Appear</span></p>');
							$('#description').css('color','green');
							$('#description').css('font-size','1.8em');
							$('#description').css('padding','20px');
							$('#description').show();
						});    

		 
		 
		            
		 
		             // Set up description displays for each document and button display
						$('#doc1').bind('mouseover',function()
							{
								$('#description').css('color','brown');
								$('#description').css('font-size','1.4em');
								$('#description').css('text-align','left');
								$('#description').show();
								$('#description').html('<span style="color:black">Grainger ABCDE SeriesB</span><p>This is a Maintenance and Product Information Manual tailored for a customers implementation of a ' +
								           ' Motor Efficiency Controller (MEC).  It is a new generation product manual.</p>'+
										   '<p>I wrote it in Adobe InDesign according to the customer\'s style rules</p><p style="color:green"><span style="color:green;font-style:italic" id="clkmess">Click Blinking Button Above</span></p>');
								$('#clickdiv1').show();
						  
								$('#clickdiv1').bind('click',function()
									{
									   $(this).css('background','linear-gradient(linen,tan)');
									   $('#description').html('Please Wait For Loading...');
									   window.location.assign('http://67.23.226.231/~rlsworks/pdf/showPDF1.php');
									}); 
									
									
								
								
								$(this).mouseleave(function()
									{
										
										$('#clickdiv1').hide();
									});
									
						
									
									
									
									
							});
		 
		 
						$('#doc2').bind('mouseover',function()
							{
								$('#description').css('color','brown');
								$('#description').css('font-size','1.4em');
								$('#description').css('text-align','left');
								$('#description').show();
								$('#description').html('<span style="color:black">Grainger CDE</span><p>This is a Maintenance and Product Information Manual tailored for a customers implementation of a ' +
								           ' Motor Efficiency Controller (MEC).  It is a new generation product manual.</p>'+
										   '<p>I wrote it in Adobe InDesign according to the customer\'s style rules</p><p style="color:green" ><span style="color:green;font-style:italic" id="clkmess">Click Blinking Button Above</span></p>');
								$('#clickdiv2').show();
						  
								$('#clickdiv2').bind('click',function()
									{
									   $(this).css('background','linear-gradient(linen,tan)');
									   $('#description').html('Please Wait For Loading...');
									   window.location.assign('http://67.23.226.231/~rlsworks/pdf/showPDF2.php');
									});

								
								$(this).mouseleave(function()
									{
										
										$('#clickdiv2').hide();
									});
									
									
									
							});
							
							
						$('#doc3').bind('mouseover',function()
							{
								$('#description').css('color','brown');
								$('#description').css('font-size','1.4em');
								$('#description').css('text-align','left');
								$('#description').show();
								$('#description').html('<span style="color:black">MEC Product Manual VT 1.6</span><p>This is a Product Manual for a ' +
								           ' Motor Efficiency Controller (MEC).  It is a new generation product manual.</p>'+
										   '<p>I wrote it in Adobe InDesign according to the customer\'s style rules</p><p style="color:green"><span style="color:green;font-style:italic" id="clkmess">Click Blinking Button Above</span></p>');
								$('#clickdiv3').show();
						  
								$('#clickdiv3').bind('click',function()
									{
									   $(this).css('background','linear-gradient(linen,tan)');
									   $('#description').html('Please Wait For Loading...');
									   window.location.assign('http://67.23.226.231/~rlsworks/pdf/showPDF3.php');
									});


								$(this).mouseleave(function()
									{
										
										$('#clickdiv3').hide();
									});
									
							
								
							});
							
							
							
						$('#doc4').bind('mouseover',function()
							{
								$('#description').css('color','brown');
								$('#description').css('font-size','1.4em');
								$('#description').css('text-align','left');
								$('#description').show();
								$('#description').html('<span style="color:black">MEC White Paper</span><p>This is a revision of the White Paper for the ' +
								           ' Motor Efficiency Controller (MEC).  It contained a fuller explanation of the electrical induction of power and torque' + 
										   ' in an electrical motor.<p>It was written in Microsoft Word.</p><p style="color:green"><span style="color:green;font-style:italic" id="clkmess">Click Blinking Button Above</span></p>');
								$('#clickdiv4').show();
						  
								$('#clickdiv4').bind('click',function()
									{
									   $(this).css('background','linear-gradient(linen,tan)');
									   $('#description').html('Please Wait For Loading...');
									   window.location.assign('http://67.23.226.231/~rlsworks/pdf/showPDF4.php');
									});


								$(this).mouseleave(function()
									{
										
										$('#clickdiv4').hide();
									});
									
							
							});	
							
							
							
						$('#doc5').bind('mouseover',function()
							{
								$('#description').css('color','brown');
								$('#description').css('font-size','1.4em');
								$('#description').css('text-align','left');
								$('#description').show();
								$('#description').html('Improvement Plan<br/>Requirements');
								$('#description').html('<span style="color:black">Improvement Plan Requirements</span><p>This is technical specification of the' + 
								           ' requirements of approval and methodology of granting approval for land improvement in Clark County, as it pertains to water' + 
										   ' and sewer utility construction.</p><p>It was written in Microsoft Word.</p><p style="color:green"><span style="color:green;font-style:italic" id="clkmess">Click Blinking Button Above</span></p>');
						        $('#clickdiv5').show();
						  
								$('#clickdiv5').bind('click',function()
									{
									   $(this).css('background','linear-gradient(linen,tan)');
									   $('#description').html('Please Wait For Loading...');
									   window.location.assign('http://67.23.226.231/~rlsworks/pdf/showPDF5.php');
									});

								
								$(this).mouseleave(function()
									{
										
										$('#clickdiv5').hide();
									});
									
							
							});	
						
		
		
						$('#doc6').bind('mouseover',function()
							{
								$('#description').css('color','brown');
								$('#description').css('font-size','1.4em');
								$('#description').css('text-align','left');
								$('#description').show();
								$('#description').html('Code Development<br/>Technical Writings');
								$('#description').html('<span style="color:black">Code Development Technical Writing</span><p>This is a technical specification for' + 
								      ' guidance in developing Object Oriented Code.' + '</p><p>It was written as a HTML document.</p><p style="color:green"><span style="color:green;font-style:italic" id="clkmess">Click Blinking Button Above</span></p>');
									  
										   
						        $('#clickdiv6').show();
						  
								$('#clickdiv6').bind('click',function()
									{
									   $(this).css('background','linear-gradient(linen,tan)');
									   $('#description').html('Please Wait For Loading...');
									   $("#itemform input[name='itemchoice']").val('codetech');
									   $("#itemform input[name='itemchoice2']").val('none');
									   $("#itemform input[name='appType']").val('desktop');
                                       $('#itemform').submit();	
									});

								
								$(this).mouseleave(function()
									{
										
										$('#clickdiv6').hide();
									});
									
							
							});	
		
		
		
		
							
								$('#oframebg').css('background-image','url("<?php echo $imgfile2; ?>")');
								//$('#oframebg').animate({opacity:'0.40'},"slow");
					 			
						/*		$('.docbuttons').bind('mouseleave', function()
									{
										//$('#oframebg').animate({opacity:'0.75'},"slow");
										$('#oframebg').animate({opacity:'0.40'},"slow");
										$('#oframebg').animate({opacity:'0.20'},"slow");
										$('#oframebg').animate({opacity:'0.10'},"slow");
										$('#oframebg').animate({opacity:'0.0'},"slow");
										$('#oframebg').animate({opacity:'0.10'},"slow");
										$('#oframebg').animate({opacity:'0.20'},"slow");
										$('#oframebg').animate({opacity:'0.40'},"slow");
										//$('#oframebg').animate({opacity:'0.75'},"slow");
										//$('#oframebg').animate({opacity:'1.0'},"slow");
									});
									
								
								$('.docbuttons').bind('mouseenter', function()
									{
									
										$('#oframebg').animate({opacity:'0.40'},"fast");
									
									});*/
								
								
								
								//Set up Blinking Button and span
											setInterval(function(){
											
																$('.clickdiv')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
																
																$('#clkmess')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
															},25);	
                  
               }    // end of JQFunction() function
                
       
        </script>

	 <div class="oframe" id="oframe">
		<div id="head">Technical Writing Documents</div>
		<div id="buttondiv">
			<div id="doc1" class="docbuttons">Grainger ABCDE<br/>SeriesB<div id="clickdiv1" class="clickdiv" >Click Here</div></div>
			<div id="doc2" class="docbuttons">Grainger<br/>CDE<div id="clickdiv2" class="clickdiv">Click Here</div></div>
			<div id="doc3" class="docbuttons">MEC Product<br/>Manual VT 1.6<div id="clickdiv3" class="clickdiv">Click Here</div></div>
			<div id="doc4" class="docbuttons">MEC<br/>White Paper<div id="clickdiv4" class="clickdiv">Click Here</div></div>
			<div id="doc5" class="docbuttons">Improvement Plan<br/>Requirements<div id="clickdiv5" class="clickdiv">Click Here</div></div>
			<div id="doc6" class="docbuttons">Code Development<br/>Technical Writing<div id="clickdiv6" class="clickdiv">Click Here</div></div>
		</div>
		<div id="description">Hover over Document Title for its Descripition.<p><p><span style="color:green;font-style:italic" id="clkmess">Then Click the Blinking Button That will Appear</span></p></div>
     </div>
	 <div id="oframebg"></div>
	
       
</div>
	
	