

  <script type="text/javascript">
		
		     function shuffle(array) {     //  Fisher-Yates (aka Knuth) Shuffle.
										  var currentIndex = array.length
											, temporaryValue
											, randomIndex
											;

										  // While there remain elements to shuffle...
										  while (0 !== currentIndex) {

											// Pick a remaining element...
											randomIndex = Math.floor(Math.random() * currentIndex);
											currentIndex -= 1;

											// And swap it with the current element.
											temporaryValue = array[currentIndex];
											array[currentIndex] = array[randomIndex];
											array[randomIndex] = temporaryValue;
										  }

										  return array;
									}
		
		
		
			function JQFunctions()
				{   
				
				
                                  $('#clickdiv1').hide();
                                  $('#clickdiv2').hide();
                                  $('#clickdiv3').hide();
                                  $('#clickdiv4').hide();
                                  $('#clickdiv5').hide(); 
                              //    $('#clickdiv6').hide();
                              //    $('#clickdiv7').hide(); 
								  $('#clickdiv8').hide();
								  $('#clickdiv9').hide(); 
								  
								  // Prepare Description to Show
								  $('#description').css('color','green');
								  $('#description').css('padding','20px');
								//  $('#description').css('height','auto').animate({fontSize:'1.3em'},50);
								  $('#description').show(); 
													
                                   $('.menuitem').bind('mouseover',function()
                                    {
                                        $(this).css('background-color','tan');
                                    });
                                        
								
									

									
										
                                   $('.menuitem').bind('mouseleave',function()
                                    {
                                        $(this).css('background-color','white');
										$('#description').css('height','30%')
										
										// Description Content after leaving menu
										$('#description').html('<div id="getHeight">Hover over Program or Work Item to the left for its Descripition.<p>Then \'Click\' Button'+
										' that will appear.</p><p><span style="color:green;font-style:italic" class="clkmess">View in Google Chrome browser to See A 3-D File Cabinet Below!</span></p></div>');                                       
										$('#description').css('text-align','center');
										
										// Set up height of Description Div
										var inheight = $('div#description div#getHeight').height();
										$('#description').css('height',inheight+'px');
										
										
                                    });    
									
								   
								   var dispHeight = $('#display').height();
								   var pos = 0;
								   var bot = 0;
									$('#orominer').bind('mouseover',function()
										{
									
											$('#description').show();
											
											// Reposition Description Display by transition to menu item
											pos = $(this).position();
											bot = pos.top-45;
											$('#description').css('bottom',(-bot));
										
											var oroMessage =  '<div id="fade1" style="opacity:0" >The Orominer program shows a hierarchical organization of the human body constitution.'+
												' Its top level is Organ Systems.<p>It uses JavaScript, JQuery for dynamic resizing of text during zooming ' +
												'and event synchronization between hierarchical display and graphic display.  DOM HTML elements ' +
												'are used to dynamically generate SVG graphical elements.</p>  <p>MySQL Database information is converted into XML format using PHP'+
												' for up front access by the code for generation of Hierachical Display.  Unfortunately ONLY THE First 3 NODES Of DATA was developed at Project Completion.</p>'+
												'<p><span class="clkmess" style="color:green;font-size:1.2em">\'Press Blinking Button\' to See Program</span></p></div>';
                                            $('#description').html(oroMessage);
										
											//Fade-In Description Content
											$("#fade1")
												.animate({fontSize:'0.8em'},50)
												.animate({opacity:'1.0'},1000);

                                            $('#clickdiv1').show();
											
											//Set up Blinking Button and span
											setInterval(function(){
																$('#clickdiv1')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
																$('.clkmess')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
															},25);

											
											//Set-up Description Content Div Height
											$('#description').css('height','auto');
											
											
												
											
                                            $(this).mouseleave(function()
												{
                                                    $('#clickdiv1').hide();
												});
									
									
										});
										
										
								   $('#oroHist').bind('mouseover',function()
										{
											$('#description').css('height','30%');
											$('#description').show();
											
											// Reposition Description Display by transition to menu item
											$('#description').css('bottom',(-bot));
											
											$('#description').html('<div id="fade2" style="opacity:0" >This orominer program contains Histological Data within the Hierarchical Organization of Human Body makeup.<p>Histological Data is .....</p>'+
											'<p><span style="color:green" class="clkmess">\'Press Blinking Button\' to See Program</span></p></div>');
										   
											$('#clickdiv2').show();
											
											//Fade-In Description Content
											$("#fade2")
												.animate({fontSize:'0.9em'},50)
												.animate({opacity:'1.0'},1000);
											
											
											//Set up Blinking Button and span
											setInterval(function(){
																$('#clickdiv2')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
																$('.clkmess')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
															},25);
											
											
											
											//Set-up Description Content Div Height
											$('#description').css('height','auto');
											
										  
											
                                            $(this).mouseleave(function()
												{
													
                                                    $('#clickdiv2').hide();
												});
										});
										
										
								   $('#othello').bind('mouseover',function()
										{
										
											$('#description').show();
											
										    // Reposition Description Display by transition to menu item
											$('#description').css('bottom',(-bot));
											
											
											$('#description').css('height','30%');
											
											$('#description').html('<div id="fade3" style="opacity:0" >This is an adaptation of the Classic Othello game where one player competes with the Computer.'+
											'<p>Two Player Play could be implemented, as well as, making levels of difficulty for game play.</p>'+
											'<p><span style="color:green" class="clkmess">\'Press Blinking Button\' to PLAY</span></p></div>');
										    $('#clickdiv3').show();
										
											//Fade-In Description Content
											$("#fade3")
												.animate({fontSize:'0.9em'},50)
												.animate({opacity:'1.0'},1000);

												
											//Set up Blinking Button and span
											setInterval(function(){
																$('#clickdiv3')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
																$('.clkmess')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
															},25);	
												
												
											//Set-up Description Content Div Height
											$('#description').css('height','auto');
											

											
                                            $(this).mouseleave(function()
												{
													
                                                    $('#clickdiv3').hide();

												});
										});
                                        
                                        
                                  $('#miniMotif').bind('mouseover',function()
										{
										
											$('#description').show();
											
											// Reposition Description Display by transition to menu item
											$('#description').css('bottom',(-bot));
											
											$('#description').css('height','40%');
											$('#description').html('<div id="fade4" style="opacity:0" >This program gives statistics for all combinations of amino acid sequences within a protein.  The protein sequence is parsed by regex techniques from a text file, into a MySQL database.'+
											'<p>The first and last amino acid is chosen in the GUI, as well as, the desired statistical output.</p>'+
											'<p>The database accessed from JavaScript AJAX to PHP on the server side which returns the statistics.</p>'+
											'<p><span style="color:green" class="clkmess">\'Press Blinking Button\' to See Program</span></p></div>');
                        
										    $('#clickdiv4').show();
											
											//Fade-In Description Content
											$("#fade4")
												.animate({fontSize:'0.9em'},50)
												.animate({opacity:'1.0'},1000);
											
											
											//Set up Blinking Button and span
											setInterval(function(){
																$('#clickdiv4')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
																$('.clkmess')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
															},25);
											
											//Set-up Description Content Div Height
											$('#description').css('height','auto');
											

											
                                            $(this).mouseleave(function()
												{
													
                                                    $('#clickdiv4').hide();

												});
										}); 
                                        
                           
                                  $('#technicalWriting').bind('mouseover',function()
										{
											$('#description').show();
											
											// Reposition Description Display by transition to menu item
											$('#description').css('bottom',(-bot));
											
											$('#description').css('height','15%');
											$('#description').html('<div id="fade5" style="opacity:0" >I am a Technical Writer too!'+
											'<p><span style="color:green" class="clkmess">\'Press Blinking Button\' to See Documents</span></p></div>');
                        
										    $('#clickdiv5').show();
											
											//Fade-In Description Content
											$("#fade5")
												.animate({fontSize:'0.9em'},50)
												.animate({opacity:'1.0'},1000);
											
											
											//Set up Blinking Button and span
											setInterval(function(){
																$('#clickdiv5')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
																$('.clkmess')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
															},25);
											
											//Set-up Description Content Div Height
											$('#description').css('height','auto');
											
										
											
                                            $(this).mouseleave(function()
												{
													
                                                    $('#clickdiv5').hide();

												});
										});       
                                        
                                      
								  $('#resume').bind('mouseover',function()
										{
											$('#description').show();
											
											// Reposition Description Display by transition to menu item
											$('#description').css('bottom',(-bot));
											
											$('#description').css('height','20%');
											$('#description').html('<div id="fade6" style="opacity:0" >Resume for Richard L. Sypert Jr. in Html and PDF formats.  The HTML Resume Format Only Uses CSS and no JavaScript!'+
											'<p><span style="color:green" class="clkmess">\'Press Blinking Button\' to See My Resume</span></p></div>');
                        
										    $('#clickdiv8').show();
											
											//Fade-In Description Content
											$("#fade6")
												.animate({fontSize:'0.9em'},50)
												.animate({opacity:'1.0'},1000);
											
											//Set up Blinking Button and span
											setInterval(function(){
																$('#clickdiv8')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
																$('.clkmess')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
															},25);
											
											//Set-up Description Content Div Height
											$('#description').css('height','auto');
											
										
											
                                            $(this).mouseleave(function()
												{
													
                                                    $('#clickdiv8').hide();
												});
										});            


								  $('#livingInVegas').bind('mouseover',function()
										{
											$('#description').show();
											
											// Reposition Description Display by transition to menu item
											$('#description').css('bottom',(-bot));
											
											$('#description').css('height','20%');
											$('#description').html('<div id="fade6" style="opacity:0" >Living in Las Vegas has been a Discovery.'+
											'<p><span style="color:green" class="clkmess">\'Press Blinking Button\' to See</span></p></div>');
                        
										    $('#clickdiv9').show();
											
											//Fade-In Description Content
											$("#fade6")
												.animate({fontSize:'0.9em'},50)
												.animate({opacity:'1.0'},1000);
											
											//Set up Blinking Button and span
											setInterval(function(){
																$('#clickdiv9')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
																$('.clkmess')	
																	.animate({opacity:'0.5'},500)
																	.animate({opacity:'1.0'},500);
															},25);
											
											//Set-up Description Content Div Height
											$('#description').css('height','auto');
											
										
                                            $(this).mouseleave(function()
												{
													
                                                    $('#clickdiv9').hide();
												});
										});            



								
                                 
                                // Pressing Button for Orominer Program 
                                $('#clickdiv1').bind('click', function()
                                    {
										$(this).css('background','linear-gradient(#CCCCCC,tan)');
								//		$('#description').html('Please Wait For Loading...');
										$("#itemform input[name='itemchoice']").val('orominer');
										$("#itemform input[name='itemchoice2']").val('none');
                                        $('#itemform').submit();	
                                        
                                        });
										
										
										
								// Pressing Button for Othello Game	
								$('#clickdiv3').bind('click', function()
                                    {	
										$(this).css('background','linear-gradient(#CCCCCC,tan)');
									//	$('#description').html('Please Wait For Loading...');
										$("#itemform input[name='itemchoice']").val('othello');
										$("#itemform input[name='itemchoice2']").val('none');
                                        $('#itemform').submit();	
                                        });		
										
										
											
								// Pressing Button for Orominer Histology	
								$('#clickdiv2').bind('click', function()
                                    {	
										$(this).css('background','linear-gradient(#CCCCCC,tan)');
									//	$('#description').html('Please Wait For Loading...');
										$("#itemform input[name='itemchoice']").val('oroHist');
										$("#itemform input[name='itemchoice2']").val('none');
                                        $('#itemform').submit();	
                                        });		
										
							
										
								// Pressing Button for MiniMotif Program
								$('#clickdiv4').bind('click', function()
                                    {	
										$(this).css('background','linear-gradient(#CCCCCC,tan)');
									//	$('#description').html('Please Wait For Loading...');
										$("#itemform input[name='itemchoice']").val('miniMotif');
										$("#itemform input[name='itemchoice2']").val('none');
                                        $('#itemform').submit();	
                                        });		
										
							
										
								// Pressing Button for Resume
								$('#clickdiv8').bind('click', function()
                                    {	
										$(this).css('background','linear-gradient(#CCCCCC,tan)');
									//	$('#description').html('Please Wait For Loading...');
										$("#itemform input[name='itemchoice']").val('resume');
										$("#itemform input[name='itemchoice2']").val('none');
                                        $('#itemform').submit();	
                                        });		
										
										
								// Pressing Button for Technical Writing	
								$('#clickdiv5').bind('click', function()
                                    {	
										$(this).css('background','linear-gradient(#CCCCCC,tan)');
										
										//$('#description').html('Please Wait For Loading...');
										$("#itemform input[name='itemchoice']").val('technicalWriting');
										$("#itemform input[name='itemchoice2']").val('none');
                                        $('#itemform').submit();	
                                        });	


								// Pressing Button for Living In Vegas	
								$('#clickdiv9').bind('click', function()
                                    {	
										$(this).css('background','linear-gradient(#CCCCCC,tan)');
										//$('#description').html('Please Wait For Loading...');
										$("#itemform input[name='itemchoice']").val('livingInVegas');
										$("#itemform input[name='itemchoice2']").val('none');
                                        $('#itemform').submit();	
                                        });		
										
							
							    $('[id^="clickdiv"]').bind('click', function()
									{
										$('#description').html('<div id="adjust">Please Wait For Loading...</div>');
										
							    		//Set-up Description Content Div Height
										var inheight = $('div#description div#adjust').height();
										$('#description').css('height',inheight+'px');
									});
							
							
							
							   
						        var position = $('#outframe').position();
								var left = position.left;
								var top = position.top;
								var width = $('#outframe').width();
								var height = $('#outframe').height();
								var width2 = $('#footContainer').width();
								
								
								$('#description').css('color','black');
						
								
								$('#outframebg').css('background-image','url("<?php echo $imgfile; ?>")');
								$('#outframebg').animate({opacity:'0.30'},"slow");
							
								$('body').css('background', 'linear-gradient(to right, #DCDCDC 0%,#C0C0C0 100%)');
												
											
										$('.menuitem').bind('mouseleave', function()
										{
										//$('#outframebg').animate({opacity:'0.75'},"slow");
										$('#outframebg').animate({opacity:'0.30'},"slow");
										$('#outframebg').animate({opacity:'0.20'},"slow");
										$('#outframebg').animate({opacity:'0.10'},"slow");
										$('#outframebg').animate({opacity:'0'},"slow");
										$('#outframebg').animate({opacity:'0.10'},"slow");
										$('#outframebg').animate({opacity:'0.20'},"slow");
										$('#outframebg').animate({opacity:'0.30'},"slow");
										//$('#outframebg').animate({opacity:'0.75'},"slow");
										//$('#outframebg').animate({opacity:'1.0'},"slow");
									
									});
									
								$('.menuitem').bind('mouseover', function()
									{
										$('#description').css({'border': '40 ridge brown'});
									});
								
						
						
								$('.menuitem').bind('mouseleave', function()
									{
										 $('#description').css({'border': '20 ridge gray'});
									});
															
								
				
								
								
								// Display of Menu Items with Arrows
								$('#upPointer').css('display','block');
								$('#orominer').css('display','block');
								$('#oroHist').css('display','block');
								$('#othello').css('display','block');
								$('#miniMotif').css('display','block');
								$('#technicalWriting').css('display','none');
								$('#resume').css('display','none');
								$('#livingInVegas').css('display','none');
								$('#downPointer').css('display','none');
								
								
								var menuItemList = new Array();
								menuItemList[0] = "#orominer";
								menuItemList[1] = "#oroHist";
								menuItemList[2] = "#othello";
								menuItemList[3] = "#miniMotif";
								menuItemList[4] = "#technicalWriting";
								menuItemList[5] = "#resume";
								menuItemList[6] = "#livingInVegas";
								
								var topIndex = 0;
								$('#downPointer').click(function()
									{
										topIndex--;
										if(topIndex <= 0)
											{
											  topIndex = 0;
											  $('#upPointer').css('display','block');
											  $('#downPointer').css('display','none');
											}
										else
											{
											  $('#upPointer').css('display','block');
											  $('#downPointer').css('display','block');
											}  
										$('#orominer').css('display','none');
										$('#oroHist').css('display','none');
										$('#othello').css('display','none');
										$('#miniMotif').css('display','none');
										$('#technicalWriting').css('display','none');
										$('#resume').css('display','none');
										$('#livingInVegas').css('display','none');	
										$(menuItemList[topIndex]).css('display','block');
										$(menuItemList[topIndex+1]).css('display','block');
										$(menuItemList[topIndex+2]).css('display','block');
										$(menuItemList[topIndex+3]).css('display','block');
									});
									
								$('#upPointer').click(function()
									{
										topIndex++;
										if(topIndex > 6)
											{
												topIndex = 6;
												$('#upPointer').css('display','none');
											    $('#downPointer').css('display','block');
											}
										else
											{
												$('#upPointer').css('display','block');
											    $('#downPointer').css('display','block');
											}
											
										$('#orominer').css('display','none');
										$('#oroHist').css('display','none');
										$('#othello').css('display','none');
										$('#miniMotif').css('display','none');
										$('#technicalWriting').css('display','none');
										$('#resume').css('display','none');
										$('#livingInVegas').css('display','none');	
										$(menuItemList[topIndex]).css('display','block');
										$(menuItemList[topIndex+1]).css('display','block');
										$(menuItemList[topIndex+2]).css('display','block');
										$(menuItemList[topIndex+3]).css('display','block');	
									});
						
								//$('div#cabinet').addClass("turn1",1000);
								//$('div#cabinet').addClass("turn2",1000);
							    $('div#cabinet').addClass("showCab2",1000);
								$('#cabinet figure.drawer1.front').bind('mouseenter',function()
									{
										// Animate File Cabinet Rotation
										$('div#cabinet').removeClass("showCab");
										$('div#cabinet').removeClass("showCab2");
									    $('div#cabinet').addClass("showCab3",1000);
									
										// Open Drawer #1 on mouseenter
										$(this).css('border','5px solid black');
										$(this).css('-webkit-transform','rotateX(0deg) translateZ(350px)');
										$('#cabinet figure.drawer1.left').css('border','5px solid black').css('-webkit-transform','rotateX(0deg) rotateY(0deg) translateZ(198px) rotateY(-90deg) translateZ(162px) translateX(0px)');
										$('#cabinet figure.drawer1.right').css('border','5px solid black').css('-webkit-transform','rotateX(0deg) rotateY(0deg) translateZ(198px) rotateY(90deg) translateZ(162px) translateX(0px)');
										$('#cabinet figure.drawer1.back').css('background-color','black');
										
										// Pop-Up File for Drawer #1
										$('#cabinet figure.drawer1.file1').css('background-color','brown').css('-webkit-transform','rotateY(0deg) translateZ(180px) scaleX(0.8) scaleY(1.3) translateY(-15px) rotateX(0deg) translateZ(150px)')
												.css('display','block')
												.css('border-top-color','peru')
												.css('border-top-style','solid')
												.css('border-top-left-radius','1em')
												.css('border-top-right-radius','1em')
												.css('border-top-width','3px')
												.html('Amino Acid Code Sequence Analyzer')
												.bind('click', function()
													{
														$(this).css('opacity','0.5');
														$(this).css('color','red');
														$("#itemform input[name='itemchoice']").val('miniMotif');
														$("#itemform input[name='itemchoice2']").val('none');
														$('#itemform').submit();	
													});												
												
										$('#cabinet figure.drawer1.file2').css('background-color','brown').css('-webkit-transform','rotateY(0deg) translateZ(180px) scaleX(0.8) scaleY(1.4) translateY(-35px) rotateX(0deg) translateZ(130px)')
												.css('display','block')
												.css('border-top-color','peru')
												.css('border-top-style','solid')
												.css('border-top-left-radius','1em')
												.css('border-top-right-radius','1em')
												.css('border-top-width','3px')
												.html('Play Othello Game')
												.bind('click', function()
												   {	
														$(this).css('opacity','0.5');
														$(this).css('color','red');
														$("#itemform input[name='itemchoice']").val('othello');
														$("#itemform input[name='itemchoice2']").val('none');
														$('#itemform').submit();	
													});		

										
										$('#cabinet figure.drawer1.file3').css('background-color','brown').css('-webkit-transform','rotateY(0deg) translateZ(180px) scaleX(0.8) scaleY(1.4) translateY(-60px) rotateX(0deg) translateZ(110px)')
												.css('display','block')
												.css('border-top-color','peru')
												.css('border-top-style','solid')
												.css('border-top-left-radius','1em')
												.css('border-top-right-radius','1em')
												.css('border-top-width','3px')
												.html('Human Organ System Analyzer 1')
												.bind('click', function()
													{
														$(this).css('opacity','0.5');
														$(this).css('color','red');
														$("#itemform input[name='itemchoice']").val('orominer');
														$("#itemform input[name='itemchoice2']").val('none');
														$('#itemform').submit();	
													
													});
												
												
										$('#cabinet figure.drawer1.file4').css('background-color','brown').css('-webkit-transform','rotateY(0deg) translateZ(180px) scaleX(0.8) scaleY(1.4) translateY(-88px) rotateX(0deg) translateZ(80px)')
												.css('display','block')
												.css('border-top-color','peru')
												.css('border-top-style','solid')
												.css('border-top-left-radius','1em')
												.css('border-top-right-radius','1em')
												.css('border-top-width','3px')
												.html('Human Organ System Analyzer 2')
												.bind('click', function()
													{
														$(this).css('opacity','0.5');
														$(this).css('color','red');
														$("#itemform input[name='itemchoice']").val('oroHist');
														$("#itemform input[name='itemchoice2']").val('none');
														$('#itemform').submit();	
													
													});		
												
										
												
										// Events on Drawer 1		
										$('#cabinet figure.drawer1.file1,#cabinet figure.drawer1.file2,#cabinet figure.drawer1.file3,#cabinet figure.drawer1.file4').mouseover(function()
											{
												$(this).css('background-color','brown').css('color','white').css('border-top-color','peru').css('border-top-width','8px');
												$(this).mouseleave(function()
													{
														$(this).css('background-color','brown').css('color','black').css('border-top-color','peru').css('border-top-width','1px');
													});
											});
										
								
											
										//Close Drawer # 2
										$('#cabinet figure.drawer2.front').css('-webkit-transform','rotateX(0deg) translateZ(198px) translateY(100px)').css('border','2px solid black');
										$('#cabinet figure.drawer2.left').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(100px) rotateY(-90deg) translateZ(162px) translateX(-162px)').css('border','2px solid black');
										$('#cabinet figure.drawer2.right').css('border','5px solid black').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(100px) rotateY(90deg) translateZ(162px) translateX(162px)');
										$('#cabinet figure.drawer2.back').css('background-color','black');
										$('#cabinet figure.drawer2.back').css('background-color','none');
										$('#cabinet figure.drawer2.file1').css('display','none');
										$('#cabinet figure.drawer2.file2').css('display','none');
										$('#cabinet figure.drawer2.file3').css('display','none');
										$('#cabinet figure.drawer2.file4').css('display','none');
										
										//Close Drawer # 3
										$('#cabinet figure.drawer3.front').css('-webkit-transform','rotateX(0deg) translateZ(198px) translateY(200px)').css('border','2px solid black');
										$('#cabinet figure.drawer3.left').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(200px) rotateY(-90deg) translateZ(162px) translateX(-162px)').css('border','2px solid black');
										$('#cabinet figure.drawer3.back').css('background-color','none');
										$('#cabinet figure.drawer3.right').css('border','5px solid black').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(200px) rotateY(90deg) translateZ(162px) translateX(162px)');
										$('#cabinet figure.drawer3.file1').css('display','none');
										$('#cabinet figure.drawer3.file2').css('display','none');
										
										
										//Close Drawer #1 on Click
									    $(this).bind('click',function()
											{
												// Close drawer and folders
												$(this).css('-webkit-transform','rotateX(0deg) translateZ(198px)').css('border','2px solid black');
												$('#cabinet figure.drawer1.left').css('-webkit-transform','rotateY(0deg) translateZ(198px) rotateY(-90deg) translateZ(162px) translateX(-162px)');
												$('#cabinet figure.drawer1.right').css('-webkit-transform','rotateY(0deg) translateZ(198px) rotateY(90deg) translateZ(162px) translateX(162px)');
												$('#cabinet figure.drawer1.file1').css('display','none');
											    $('#cabinet figure.drawer1.file2').css('display','none');
												$('#cabinet figure.drawer1.file3').css('display','none');
												$('#cabinet figure.drawer1.file4').css('display','none');
												
												// Keep other drawers visible
												$('#cabinet figure.drawer2.front').css('display','block');
												$('#cabinet figure.drawer3.front').css('display','block');
											});
									});			
								
									
							
								$('#cabinet figure.drawer2.front').bind('mouseenter',function()
									{
													$('div#cabinet').removeClass("showCab");
													$('div#cabinet').removeClass("showCab3");
													$('div#cabinet').addClass("showCab2",1000);
													
													
													//Open Drawer #2 on mouseenter
													$(this).css('border','5px solid black').css('-webkit-transform','translateY(100px) rotateX(0deg) translateZ(350px)');
													$('#cabinet figure.drawer2.left').css('border','5px solid black').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(100px) rotateY(-90deg) translateZ(162px) translateX(0px)');
												    $('#cabinet figure.drawer2.right').css('border','5px solid black').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(100px) rotateY(90deg) translateZ(162px) translateX(0px)');

													// Pop-Up File Folders for Drawer #2
													$('#cabinet figure.drawer2.file1').css('background-color','brown').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.4) translateY(-15px) rotateX(0deg) translateZ(150px)')
														.css('display','block')
														.css('border-top-color','peru')
														.css('border-top-style','solid')
														.css('border-top-left-radius','1em')
														.css('border-top-right-radius','1em')
														.css('border-top-width','3px')
														.html('Product and Maintenance Manuals')
														.on('mouseenter',function()
															{
													           
																		$(this).css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.4) translateY(-15px) rotateX(0deg) translateZ(150px)  rotateX(-40deg)')
																		.css('border-top-width','1px')
																		.css('border-top-color','black')
																		.css('display','block');	
																	    //use drawer back for file1 back
																		$('#cabinet figure.drawer2.back').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.4) translateY(-10px) rotateX(0deg) translateZ(132px)')
																		.css('display','block')
																		.css('background-color','peru')
																		.css('border-top-color','black')
																		.css('border-top-style','solid')
																		.css('border-top-left-radius','1em')
																		.css('border-top-right-radius','1em')
																		.css('border-top-width','1px')
																		.html('')
																		.on('mouseover',function()
																			{
																				$('#cabinet figure.drawer2.file1').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.4) translateY(-15px) rotateX(0deg) translateZ(150px)  rotateX(-40deg)')
																				.css('border-top-width','1px')
																				.css('display','block')
																				.css('border-top-color','white');	
																				
																				
																				//Pop-up folders for File#1 Drawer#2
																					$('#cabinet figure.drawer2.folder1').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.7) scaleY(1.2) translateY(-38px) rotateX(0deg) translateZ(150px)  rotateX(0deg)')
																					.css('display','block')
																					.css('border-top-color','#FFCC66')
																					.css('border-top-style','solid')
																					.css('border-top-left-radius','1em')
																					.css('border-top-right-radius','1em')
																					.css('background-color','yellow')
																					.css('border-top-width','3px')
																					.html('Grainger ABCDE Series B')
																					.on('mouseover', function()
																						{
																								$(this).css('color','green').css('border-top-width','8px');
																						})
																					.on('mouseleave',function()
																						{
																								$(this).css('color','black').css('border-top-width','1px');
																						})
																					.bind('click',function()
																						{
																							 $(this).css('opacity','0.5');
																							 $(this).css('color','red'); 
																							 $("#itemform input[name='itemchoice']").val('GraingerABCDE');
																							 $("#itemform input[name='itemchoice2']").val('none');
																							 $('#itemform').submit();
																						});
																			
																					$('#cabinet figure.drawer2.folder2').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.7) scaleY(1.2) translateY(-62px) rotateX(0deg) translateZ(147px)')
																					.css('display','block')
																					.css('border-top-color','#FFCC66')
																					.css('border-top-style','solid')
																					.css('border-top-left-radius','1em')
																					.css('border-top-right-radius','1em')
																					.css('background-color','yellow')
																					.css('border-top-width','3px')
																					.html('Grainger CDE')
																					.on('mouseover', function()
																						{
																								$(this).css('color','green').css('border-top-width','8px');
																						})
																					.on('mouseleave',function()
																						{
																								$(this).css('color','black').css('border-top-width','1px');
																						})
																					.bind('click',function()
																						{
																							  $(this).css('opacity','0.5');
																							  $(this).css('color','red');
																							  $("#itemform input[name='itemchoice']").val('GraingerCDE');
																							  $("#itemform input[name='itemchoice2']").val('none');
																							  $('#itemform').submit();
																						});
																					
																					$('#cabinet figure.drawer2.folder3').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.7) scaleY(1.2) translateY(-90px) rotateX(0deg) translateZ(144px)')
																					.css('display','block')
																					.css('border-top-color','#FFCC66')
																					.css('border-top-style','solid')
																					.css('border-top-left-radius','1em')
																					.css('border-top-right-radius','1em')
																					.css('background-color','yellow')
																					.css('border-top-width','3px')
																					.html('MEC Product Manual VT 1.6')
																					.on('mouseover', function()
																						{
																								$(this).css('color','green').css('border-top-width','8px');
																						})
																					.on('mouseleave',function()
																						{
																								$(this).css('color','black').css('border-top-width','1px');
																						})
																					.bind('click',function()
																						{
																							$(this).css('opacity','0.5');
																							$(this).css('color','red');
																							$("#itemform input[name='itemchoice']").val('mecProductManual');
																							$("#itemform input[name='itemchoice2']").val('none');
																							$('#itemform').submit();
																						}); 
																					
																					
																			
																															
																					
																					
																			});
																			
																// Close file#1 when other file hovered 			
															    $('#cabinet figure.drawer2.file2,#cabinet figure.drawer2.file3,#cabinet figure.drawer2.file4').mouseover(function()
																	{
																		$('#cabinet figure.drawer2.back').css('display','none');
																		$('#cabinet figure.drawer2.file1').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.4) translateY(-15px) rotateX(0deg) translateZ(150px)')
																			.css('background-color','brown')
																			.css('border-top-width','3px')
																			.css('display','block')
																			.css('border-top-color','peru');
																			
																		//Close file#1 folders	
																		$('#cabinet figure.drawer2.folder1').css('display','none');
																	    $('#cabinet figure.drawer2.folder2').css('display','none');
																	    $('#cabinet figure.drawer2.folder3').css('display','none');
																	
																	});		
																		
																// Close file#1 when other than Drawer#1 is hovered 
																 $('#cabinet figure.drawer1,#cabinet figure.drawer3').mouseover(function()
																	{
																		
																		$('#cabinet figure.drawer2.back').css('display','none');
																		$('#cabinet figure.drawer2.file1').css('display','none');
																			
																		//Close file#1 folders	
																		$('#cabinet figure.drawer2.folder1').css('display','none');
																	    $('#cabinet figure.drawer2.folder2').css('display','none');
																	    $('#cabinet figure.drawer2.folder3').css('display','none');
																	
																	});		



																
																 $('#cabinet figure.drawer1,#cabinet figure.drawer3').mouseover(function()
																	{
																		$('#cabinet figure.drawer2.back').css('display','none');
																		
																	});		
																				
																		
															})		
														.on('mouseover',function()    //Pop-up folders for File#1 Drawer#2
																{
																    $('#cabinet figure.drawer2.folder1').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.7) scaleY(1.2) translateY(-38px) rotateX(0deg) translateZ(150px)  rotateX(10deg)')
																	.css('display','block')
																	.css('border-top-color','#FFCC66')
																	.css('border-top-style','solid')
																	.css('border-top-left-radius','1em')
																	.css('border-top-right-radius','1em')
																	.css('background-color','yellow')
																	.css('border-top-width','3px')
																	.html('Grainger ABCDE Series B')
																	.on('mouseover', function()
																		{
																				$(this).css('color','green').css('border-top-width','8px');
																		})
																	.on('mouseleave',function()
																		{
																				$(this).css('color','black').css('border-top-width','1px');
																		})
																	.bind('click',function()
																		{
																			 $(this).css('opacity','0.5');
																			 $(this).css('color','red'); 
																			 $("#itemform input[name='itemchoice']").val('GraingerABCDE');
																			 $("#itemform input[name='itemchoice2']").val('none');
																			 $('#itemform').submit();
																		});
																		
																		
																	$('#cabinet figure.drawer2.folder2').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.7) scaleY(1.2) translateY(-62px) rotateX(0deg) translateZ(147px)  rotateX(0deg)')
																	.css('display','block')
																	.css('border-top-color','#FFCC66')
																	.css('border-top-style','solid')
																	.css('border-top-left-radius','1em')
																	.css('border-top-right-radius','1em')
																	.css('background-color','yellow')
																	.css('border-top-width','3px')
																	.html('Grainger CDE')
																	.on('mouseover', function()
																		{
																				$(this).css('color','green').css('border-top-width','8px');
																		})
																	.on('mouseleave',function()
																		{
																				$(this).css('color','black').css('border-top-width','1px');
																		})
																	.bind('click',function()
																		{
																			  $(this).css('opacity','0.5');
																			  $(this).css('color','red');
																			  $("#itemform input[name='itemchoice']").val('GraingerCDE');
																			  $("#itemform input[name='itemchoice2']").val('none');
																			  $('#itemform').submit();
																		});
																	
																	$('#cabinet figure.drawer2.folder3').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.7) scaleY(1.2) translateY(-90px) rotateX(0deg) translateZ(144px)  rotateX(0deg)')
																	.css('display','block')
																	.css('border-top-color','#FFCC66')
																	.css('border-top-style','solid')
																	.css('border-top-left-radius','1em')
																	.css('border-top-right-radius','1em')
																	.css('background-color','yellow')
																	.css('border-top-width','3px')
																	.html('MEC Product Manual VT 1.6')
																	.on('mouseover', function()
																		{
																				$(this).css('color','green').css('border-top-width','8px');
																		})
																	.on('mouseleave',function()
																		{
																				$(this).css('color','black').css('border-top-width','1px');
																		})
																	.bind('click',function()
																					{
																						$(this).css('opacity','0.5');
																						$(this).css('color','red');
																						$("#itemform input[name='itemchoice']").val('mecProductManual');
																						$("#itemform input[name='itemchoice2']").val('none');
																						$('#itemform').submit();
																						}); 
																	
																					
																	
																})
														.on('mouseleave',function()
																{
																    // Close File #1 on mouseleave
																	$('#cabinet figure.drawer2.back').css('display','none');
																	$('#cabinet figure.drawer2.file1').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.4) translateY(-15px) rotateX(0deg) translateZ(150px)  rotateX(0deg)')
																		.css('background-color','brown')
																		.css('border-top-width','3px')
																		.css('display','block')
																		.css('border-top-color','peru');
																
																	$('#cabinet figure.drawer2.folder1').css('display','none');
																	$('#cabinet figure.drawer2.folder2').css('display','none');
																	$('#cabinet figure.drawer2.folder3').css('display','none');
																
																});
																					


													
															
														
																								
														
												   $('#cabinet figure.drawer2.file2').css('background-color','brown').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.4) translateY(-40px) rotateX(0deg) translateZ(130px)')
														.css('display','block')
														.css('border-top-color','peru')
														.css('border-top-style','solid')
														.css('border-top-left-radius','1em')
														.css('border-top-right-radius','1em')
														.css('border-top-width','3px')
														.html('White Paper')
														.bind('click',function()
															{
																 $(this).css('opacity','0.5');
																 $(this).css('color','red'); 
																 $("#itemform input[name='itemchoice']").val('whitePaper');
																 $("#itemform input[name='itemchoice2']").val('none');
																 $('#itemform').submit();
															});
												
												
												   $('#cabinet figure.drawer2.file3').css('background-color','brown').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.4) translateY(-65px) rotateX(0deg) translateZ(110px)')
														.css('display','block')
														.css('border-top-color','peru')
														.css('border-top-style','solid')
														.css('border-top-left-radius','1em')
														.css('border-top-right-radius','1em')
														.css('border-top-width','3px')
														.html('Engineering Specification')
														.bind('click',function()
															{
															
																  $(this).css('opacity','0.5');
																  $(this).css('color','red');
																  $("#itemform input[name='itemchoice']").val('engSpec');
																  $("#itemform input[name='itemchoice2']").val('none');
																  $('#itemform').submit();
															});
														
														
												   $('#cabinet figure.drawer2.file4').css('background-color','brown').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.4) translateY(-90px) rotateX(0deg) translateZ(80px)')
														.css('display','block')
														.css('border-top-color','peru')
														.css('border-top-style','solid')
														.css('border-top-left-radius','1em')
														.css('border-top-right-radius','1em')
														.css('border-top-width','3px')
														.html('Code Development Specification')
														.bind('click',function()
															{
																   $(this).css('opacity','0.5');
																   $(this).css('color','red'); 
																   $("#itemform input[name='itemchoice']").val('codetech');
																   $("#itemform input[name='itemchoice2']").val('none');
																   $('#itemform').submit();	
															});		
													
													
										// Events on Drawer 2		
										$('#cabinet figure.drawer2.file2,#cabinet figure.drawer2.file3,#cabinet figure.drawer2.file4').mouseover(function()
											{
												$(this).css('color','white').css('border-top-color','peru').css('border-top-width','8px');
												$(this).mouseleave(function()
													{
														$(this).css('background-color','brown').css('border-top-color','white').css('color','black').css('border-top-color','peru').css('border-top-width','2px');
													});
											});
										

											
															//Close Drawer #1
															$('#cabinet figure.drawer1.front').css('-webkit-transform','rotateX(0deg) translateZ(198px)').css('border','2px solid black');
															$('#cabinet figure.drawer1.left').css('-webkit-transform','rotateY(0deg) translateZ(198px) rotateY(-90deg) translateZ(162px) translateX(-162px)').css('border','2px solid wh');
															$('#cabinet figure.drawer1.right').css('-webkit-transform','rotateY(0deg) translateZ(198px) rotateY(90deg) translateZ(162px) translateX(162px)').css('border','2px solid black');
															$('#cabinet figure.drawer1.back').css('background-color','none');
															$('#cabinet figure.drawer1.file1').css('display','none');
															$('#cabinet figure.drawer1.file2').css('display','none');
															$('#cabinet figure.drawer1.file3').css('display','none');
															$('#cabinet figure.drawer1.file4').css('display','none');
															
															//Close Drawer #3
															$('#cabinet figure.drawer3.front').css('-webkit-transform','rotateX(0deg) translateZ(198px) translateY(200px)').css('border','2px solid black');
															$('#cabinet figure.drawer3.left').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(200px) rotateY(-90deg) translateZ(162px) translateX(-162px)').css('border','2px solid black');
															$('#cabinet figure.drawer3.right').css('border','5px solid black').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(200px) rotateY(90deg) translateZ(162px) translateX(162px)');
															$('#cabinet figure.drawer3.back').css('background-color','none');
															$('#cabinet figure.drawer3.file1').css('display','none');
															$('#cabinet figure.drawer3.file2').css('display','none');
															
															
															//Close Drawer #2 On Click
															$(this).bind('click',function()
															{
															            // Close Files folders
																		$('#cabinet figure.drawer2.file1').css('display','none');
																		$('#cabinet figure.drawer2.file2').css('display','none');
																		$('#cabinet figure.drawer2.file3').css('display','none');
																		$('#cabinet figure.drawer2.file4').css('display','none');
																		
																		//Close Drawer #2
																		$(this).css('border','2px solid black').css('-webkit-transform','rotateX(0deg) translateZ(198px) translateY(100px)');
																		$('#cabinet figure.drawer2.left').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(100px) rotateY(-90deg) translateZ(162px) translateX(-250px)').css('border','2px solid black');
																		$('#cabinet figure.drawer2.right').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(100px) rotateY(90deg) translateZ(162px) translateX(250px)').css('border','2px solid black');
																			
																		// Keep other drawers visible by Redraw
																		$('#cabinet figure.drawer1.front').css('-webkit-transform','rotateX(0deg) translateZ(240px)').css('border','2px solid black');
																		$('#cabinet figure.drawer3.front').css('-webkit-transform','rotateX(0deg) translateZ(198px) translateY(200px)').css('border','2px solid black');
																	
																		
															});  
											
																
												
												
									});
							    //Keep file#1 icon open when hovering its folders
						        $('#cabinet figure.drawer2.folder1,#cabinet figure.drawer2.folder2,#cabinet figure.drawer2.folder3').mouseover(function()
									{
									
											$('#cabinet figure.drawer2.file1').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.3) translateY(-15px) rotateX(0deg) translateZ(150px)  rotateX(-40deg)')
												.css('background-color','brown')
												.css('border-top-width','1px')
												.css('border-top-color','white')
												.css('color','white')
												.css('display','block');	
											
										     $('#cabinet figure.drawer2.back').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(100px) scaleX(0.8) scaleY(1.4) translateY(-15px) rotateX(0deg) translateZ(132px)')
												.css('display','block')
												.css('background-color','peru')
												.css('border-top-color','white')
												.css('border-top-style','solid')
												.css('border-top-left-radius','1em')
												.css('border-top-right-radius','1em')
												.css('border-top-width','1px')
												.html('');
									
									
									});
								
								$('#cabinet figure.drawer3.front').bind('mouseenter',function()
									{
											
													$('div#cabinet').removeClass("showCab3");
													$('div#cabinet').removeClass("showCab2");
													$('div#cabinet').addClass("showCab",1000);
																
													
													//Open Drawer #3 on mouseenter
													$(this).css('border','5px solid black').css('-webkit-transform','rotateX(0deg) translateZ(350px) translateY(200px)');
													$('#cabinet figure.drawer3.left').css('border','5px solid black').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(200px) rotateY(-90deg) translateZ(162px) translateX(0px)');
													$('#cabinet figure.drawer3.right').css('border','5px solid black').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(200px) rotateY(90deg) translateZ(162px) translateX(0px)');
													$('#cabinet figure.drawer3.back').css('background-color','black');
													
													// Pop-Up File Folders for Drawer #3
													$('#cabinet figure.drawer3.file1').css('background-color','brown').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(200px) scaleX(0.8) scaleY(1.3) translateY(-15px) rotateX(0deg) translateZ(150px)')
														.css('display','block')
														.css('border-top-color','peru')
														.css('border-top-style','solid')
														.css('border-top-left-radius','1em')
														.css('border-top-right-radius','1em')
														.css('border-top-width','3px')
														.html('Education and Experience')
														.bind('click',function()
															{
																$(this).css('opacity','0.5');
																$(this).css('color','red');
																$("#itemform input[name='itemchoice']").val('EngExp');
																$("#itemform input[name='itemchoice2']").val('none');
																$('#itemform').submit();	
																
																
															}); 										
														
												   $('#cabinet figure.drawer3.file2').css('background-color','brown').css('-webkit-transform','rotateY(0deg) translateZ(175px) translateY(200px) scaleX(0.8) scaleY(1.4) translateY(-35px) rotateX(0deg) translateZ(130px)')
														.css('display','block')
														.css('border-top-color','peru')
														.css('border-top-style','solid')
														.css('border-top-left-radius','1em')
														.css('border-top-right-radius','1em')
														.css('border-top-width','3px')
														.html('Dynamic Resume')
														.bind('click',function()
															{
																	$(this).css('opacity','0.5');
																    $(this).css('color','red');
																	$("#itemform input[name='itemchoice']").val('resume');
																	$("#itemform input[name='itemchoice2']").val('none');
																	$('#itemform').submit();	
															 });		
												
													
													// Events on Drawer 2		
													$('#cabinet figure.drawer3.file1,#cabinet figure.drawer3.file2').mouseover(function()
														{
															$(this).css('background-color','brown').css('color','white').css('border-top-color','peru').css('border-top-width','8px');
															$(this).mouseleave(function()
																{
																	$(this).css('background-color','brown').css('color','black').css('border-top-width','1px');
																});
														});
																
													//Close Drawer #1
													$('#cabinet figure.drawer1.front').css('-webkit-transform','rotateX(0deg) translateZ(198px)').css('border','2px solid black');
													$('#cabinet figure.drawer1.left').css('-webkit-transform','rotateY(0deg) translateZ(198px) rotateY(-90deg) translateZ(162px) translateX(-162px)').css('border','2px solid black');
													$('#cabinet figure.drawer1.right').css('-webkit-transform','rotateY(0deg) translateZ(198px) rotateY(90deg) translateZ(162px) translateX(162px)').css('border','2px solid black');
													$('#cabinet figure.drawer1.file1').css('display','none');
													$('#cabinet figure.drawer1.file2').css('display','none');
												    $('#cabinet figure.drawer1.file3').css('display','none');
												    $('#cabinet figure.drawer1.file4').css('display','none');
													$('#cabinet figure.drawer1.back').css('background-color','none');
													
													
													//Close Drawer #2
													$('#cabinet figure.drawer2.front').css('-webkit-transform','rotateX(0deg) translateZ(198px) translateY(100px)').css('border','2px solid black');
													$('#cabinet figure.drawer2.left').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(100px) rotateY(-90deg) translateZ(162px) translateX(-162px)').css('border','2px solid black');
													$('#cabinet figure.drawer2.right').css('border','5px solid black').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(100px) rotateY(90deg) translateZ(162px) translateX(162px)');
													$('#cabinet figure.drawer2.back').css('background-color','none');
													// Close Drawer #2 files
													$('#cabinet figure.drawer2.file1').css('display','none');
													$('#cabinet figure.drawer2.file2').css('display','none');
												    $('#cabinet figure.drawer2.file3').css('display','none');
												    $('#cabinet figure.drawer2.file4').css('display','none');
													
													
													//Close Drawer #3 on Click
													$(this).bind('click',function()
													{
															    // Close Drawer and File folders
																$(this).css('-webkit-transform','rotateX(0deg) translateZ(198px) translateY(200px)').css('border','2px solid black');
																$('#cabinet figure.drawer3.left').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(200px) rotateY(-90deg) translateZ(162px) translateX(-162px)').css('border','2px solid black');
															  	$('#cabinet figure.drawer3.right').css('-webkit-transform','rotateY(0deg) translateZ(198px) translateY(200px) rotateY(90deg) translateZ(162px) translateX(162px)').css('border','2px solid black');
															  	
																$('#cabinet figure.drawer3.file1').css('display','none');
																$('#cabinet figure.drawer3.file2').css('display','none');
															
															    // Keep other drawers visible
															 	$('#cabinet figure.drawer1.front').css('display','block');
																$('#cabinet figure.drawer2.front').css('display','block');
															
													});
																
											
												
									});
								
                               // Browser Capatability for Cabinet
							   var  httpAgent = <?php echo json_encode($_SERVER['HTTP_USER_AGENT']); ?>;
                               var chrome = httpAgent.search("Chrome");
							   var firefox = httpAgent.search("Firefox");
							   
							    var lmwidth = $('#leftmenu').width()
								lmwidth = lmwidth + 8;
								
								var icwidth = $('#itemContainer').width()
								icwidth = icwidth + 8;
								
								var ofwidth = $('#outframe').width();
								var ofbgwidth = $('#outframebg').width();
								var tbwidth = $('#topbar').width();
								var leftmargin = (ofwidth-tbwidth)/2.0;
						   if((chrome < 0))  // For Other than Google Chrome
									{
										$('.container').css('display','none');
										$('#topbar').css('margin-left',leftmargin);
										
										$('#itemContainer').css('padding','auto');
										$('#leftmenu').css('width',lmwidth);
										$('#itemContainer').css('width',icwidth);
										
										$('#outframe').css('height','100%');
										//$('#outframebg').css('height','100%');
								
									}
								if((chrome < 0) && (firefox < 0)) // Exclusively For Internet Explorer
									{
										$('.container').css('display','none');
									//	$('#topbar').css('margin-left',(leftmargin/2.0));
									//	$('#outframe').css('width',ofwidth-85);
									//	$('#outframebg').css('width',ofbgwidth-85);
									}
							
						    /*		$('div#cabinet')							 
									.animate({addClass:"turn1"},1000)
									.animate({addClass:"turn2"},1000);  */
						
								// for Function within setInterval for dynamic header display						
								var i = 1;    // Slice counter for 1st dimension
								var ii = 1;   // used to create unique name for each slice
								var iii = 1;  // Used for unique slice identification
								var jj = 1;   // Slice counter for 2nd dimension
								var j = 0;
								var flip = 0;  // Flip count
								var noFlips = 0;
								var k = 0;    // used to switch images
								var sq = 0;  // Slice counter for square random display
								var t = 0;
								var rot = 1;
								var rotCycles = 20;
								var numClips = 20;
								 
								// Create square slices and put in an array.  Will be used for Random Clip Display
								function imageSlice(leftside, rightside, top, bottom)
									{
									this.leftside = leftside;
									this.rightside = rightside;
									this.top = top;
									this.bottom = bottom;
									}  
								var allSlices = new Array();  // hold array of square slices
                                var allSlices2 = new Array();  // 2nd to hold array of square slices
								var displayModes = new Array();  // array to hold display Mode numbers
								displayModes[0]= 2;
								displayModes[1]= 3;
								displayModes[2]= 4;
								displayModes[3]= 5;
								displayModes[4]= 6;
								displayModes[5]= 7;
								displayModes[6]= 8;
							    displayModes[7]= 9;
								displayModes[8]= 10;
								//var displayModes = new Array();
								var sliceCount = 0;  //Index for above array
								var xincs = 8;
								var yincs = 3;
								var xside = 590/xincs;
								var yside = 120/yincs;
								for(var x=1;x<=xincs;x++)   // Put Clips in Array
									{
										for(var y=1;y<=yincs;y++)
											{
											
											        ls = x*xside-xside;
												rs = ls+xside;
												tp = y*yside-yside;
												bt = tp+yside;
												thisSlice = new imageSlice(ls,rs,tp,bt);
												allSlices[sliceCount] = thisSlice;
                                                allSlices2[sliceCount] = thisSlice;
												sliceCount++;
											
											}
									
									}  
								//allSlices.sort(function() {return 0.5 - Math.random()});      // Randomly arrange clips in array
								allSlices = shuffle(allSlices);  // Randomly arrange clips in array
								var topImages = new Array();   // Array for Header Images
								topImages[0] = '<?php echo $topLabel; ?>';
								topImages[1] = '<?php echo $tbimgfile; ?>';
								topImages[2] = '<?php echo $csimagefile; ?>';
								topImages[3] = '<?php echo $mathhonorimg; ?>';
							    topImages[4] = '<?php echo $procprojengimg; ?>';
								topImages[5] = '<?php echo $techwritingimg; ?>';
							
								// Random display Mode selection
								//displayModes.sort(function() {return 0.5 - Math.random()});
								//j = displayModes[0];
								displayModes = shuffle(displayModes); 
								j = displayModes[0];
								//j = 10;  //For testing
								setInterval(function(){
												     
												if(i<=(numClips/2)  && i<=rotCycles)
													{
														var name = "intopbar" + i.toString();
														if(j==0 || j==1) j=2;  // Skip Horizontal and Vertical Slide Diplay Modes
														
														if(j==0)     //Horizontal Slide Parameters
															{
																	var leftside = i*59-59;
																	var rightside = leftside + 59;
																	var top = 0;
																	var bottom = 120;
															}
														else if(j==1)    // Vertical Slide Parametes
															{
																var leftside = 0;
																var rightside = 590;
																var top = i*12-12;
																var bottom = top + 12;
															}
													   
														var $tpImage = "";
														$tpImage = topImages[k];   
														
														if(j==0 || j==1)   // Horizontal and Vertical Slide Clipping Display Type
															{
																if(i==1) $('#topbar').html("");
																$('#topbar').append("<div id="+name+"  class='forrotate' style='position:absolute;z-index:-1'><img src='"+$tpImage+"'></div>");
																$('#'+name).css('display','none');
																$('#'+name).css('clip','rect('+top+'px, ' + rightside + 'px, ' + bottom + 'px, '+leftside+'px)');
															    $('#'+name).fadeOut(5).fadeIn(5);																
															}
														else if(j==2)    // Vertical SlICE Clipping Display Type
															{	
																	var inc = (120/(numClips/2));
																	var top = i*inc-inc;
																	var bottom = top + inc;
																	var leftside = 0;
																	var rightside = 590;
																	var name = "intopbar" + ii.toString();
																	$('#topbar').append("<div id="+name+" class='forrotate' style='position:absolute;z-index:-1;display:none'><img src='"+$tpImage+"'></div>");
																	$('#'+name).css('clip','rect('+top+'px, ' + rightside + 'px, ' + bottom + 'px, '+leftside+'px)');
																	//$('#'+name).show('slide', { direction: 'right' }, 100);	
																	$('#'+name).fadeIn();
																	ii++;
																	if(i == (numClips/2))
																		{
																			i = 0;  // will be incremented at end of loop
																			k++;  // Change Image
																			if(k==topImages.length) 
																				{
																					//j++;   // Change Display Mode
																					
																					// Random display Mode selection
																					//displayModes.sort(function() {return 0.5 - Math.random()});
																					displayModes = shuffle(displayModes); 
																					j = displayModes[0];
																					
																					k = 0;
																				}
																		}
															}
														
														
														else if(j==3)   // Horizontal SLICE Clipping Display Type
															{
																	var inc = 590/(numClips/2);
																	var top = 0;
																	var bottom = 120;
																	var leftside = i*inc-inc;
																	var rightside = leftside + inc;
																	var name = "intopbar" + ii.toString();
																	$('#topbar').append("<div id="+name+" class='forrotate' style='position:absolute;z-index:-1;display:none'><img src='"+$tpImage+"'></div>");
																	$('#'+name).css('clip','rect('+top+'px, ' + rightside + 'px, ' + bottom + 'px, '+leftside+'px)');
																	//$('#'+name).css('display','block');	
																	$('#'+name).fadeIn();
																	ii++;
																	
																	if(i == (numClips/2))
																		{
																			i = 0;  // will be incremented at end of loop
																			k++;  // Change Image
																			if(k==topImages.length) 
																				{
																					//j++;   // Change Display Mode
																					
																					// Random display Mode selection
																					//displayModes.sort(function() {return 0.5 - Math.random()});
																					displayModes = shuffle(displayModes); 
																					j = displayModes[0];
																					
																					k = 0;
																				}
																		}
															}
														
														else if((j==4))   // Random Image Fill
															{
															  if(sq < allSlices.length)
																{
																	  var top = allSlices[sq].top;
																	  var bottom = allSlices[sq].bottom;
																	  var leftside = allSlices[sq].leftside;
																	  var rightside = allSlices[sq].rightside;
																	 
																	  var name = "intopbar" + ii.toString();
																	  $('#topbar').append("<div id="+name+" class='forrotate' style='position:absolute;z-index:-1;display:none'><img src='"+$tpImage+"'></div>");
																	  //$('#'+name).css('display','none');
																	  $('#'+name).css('clip','rect('+top+'px, ' + rightside + 'px, ' + bottom + 'px, '+leftside+'px)');
																	  $('#'+name).fadeIn(5).fadeOut(5).fadeIn(5);
																	  sq++;
																	  ii++;
																}
																
																if(sq == allSlices.length)
																		{
																			i = 0;  // will be incremented at end of loop
																			sq = 0;
																			k++;  // Change Image
																			if(k==topImages.length) 
																				{
																					//j++;   // Change Display Mode
																					
																					// Random display Mode selection
																					//displayModes.sort(function() {return 0.5 - Math.random()});
																					displayModes = shuffle(displayModes); 
																					j = displayModes[0];
																					
																					k = 0;
																				}
																			
																		}	
														}
													
                                                    
                                                    
                                                    
                                                       else if((j==5))   // Checker Board
															{
															  l = allSlices2.length;
															  if(sq < allSlices2.length)
																{
																	  if(sq % 2 == 0)
																		{
																			  var top = allSlices2[sq].top;
																			  var bottom = allSlices2[sq].bottom;
																			  var leftside = allSlices2[sq].leftside;
																			  var rightside = allSlices2[sq].rightside;
																		}
																	  else
																		{
																			  var top = allSlices2[l-sq].top;
																			  var bottom = allSlices2[l-sq].bottom;
																			  var leftside = allSlices2[l-sq].leftside;
																			  var rightside = allSlices2[l-sq].rightside;
																		}
																	 
																	  var name = "intopbar" + ii.toString();
																	  $('#topbar').append("<div id="+name+" class='forrotate' style='position:absolute;z-index:-1;display:none'><img src='"+$tpImage+"'></div>");
																	  //$('#'+name).css('display','none');
																	  $('#'+name).css('clip','rect('+(top-2)+'px, ' + (rightside+2) + 'px, ' + (bottom +2)+ 'px, '+(leftside-2)+'px)');
																	  $('#'+name).fadeIn(100).fadeOut(100).fadeIn(100);
																	  sq++;
																	  ii++;
																}
															  
															  
															  if(sq == allSlices2.length)
																		{
																			i = 0;  // will be incremented at end of loop
																			sq = 0;
																			k++;    // Change Image
																			if(k==topImages.length) 
																				{
																					//j++;   // Change Display Mode
																					
																					// Random display Mode selection
																					//displayModes.sort(function() {return 0.5 - Math.random()});
																					displayModes = shuffle(displayModes); 
																					j = displayModes[0];
																					
																					k = 0;
																				}																			
																		}	
														}  
                                                    
                                                    else if(j == 6)   // 3d Rotation of Images around Y Axis
													{
														$('#topbar').html("");
														var name = "intopbar" + ii.toString();
														$('#topbar').append("<div id="+name+" class='forrotate' style='position:absolute;z-index:-1'><img src='"+$tpImage+"'></div>");
														$('#'+name).css('clip','rect(0px, 590px, 120px, 0px)');
														$('.forrotate').css('transform','rotate3d(0,1,0,' + (360/rotCycles)*rot + 'deg)');
														
														if(rot == rotCycles)
															{
																if(k==(topImages.length-1)) 
																	{
																	   //j++;  // Change Display Mode
																	  // k=0;
																	   // Random display Mode selection
																		//displayModes.sort(function() {return 0.5 - Math.random()});
																		displayModes = shuffle(displayModes); 
																		j = displayModes[0];
																	   
																	   i = rotCycles+1; // Switch to else if(i > rotCycles)
																	   rot = 0;
																	}
																else if(k<(topImages.length-1))  // Change Images
																	{ 
																		k++;
																		//sq = 0;
																		rot = 0;
																	}
															}
													   rot++;
													   ii++;
													
													}
                                                    
													
													
													
													else if(j==7)   // Horizontal Flip SLICE Clipping Display Type
															{
																	var inc = 590/(numClips/2);
																	var top = 0;
																	var bottom = 120;
																	
																	if(i % 2 == 0)
																		{
																		   flip = 1;
																		   noFlips++;
																		}
																	else 
																		flip = 0;
																			
																	if(flip == 0)
																		{
																			var leftside = (noFlips+1)*inc-inc;
																			var rightside = leftside + inc;
																		}
																	else 
																		{
																		 
																	        var leftside = 590 - noFlips*inc
																			var rightside = leftside + inc;
																		}
																	var name = "intopbar" + ii.toString();
																	$('#topbar').append("<div id="+name+" class='forrotate' style='position:absolute;z-index:-1;display:none'><img src='"+$tpImage+"'></div>");
																	$('#'+name).css('clip','rect('+top+'px, ' + rightside + 'px, ' + bottom + 'px, '+leftside+'px)');
																	//$('#'+name).css('display','block');	
																	$('#'+name).fadeIn();
																	ii++;
																	
																	if(i == (numClips/2))
																		{
																			i = 0;  // will be incremented at end of loop
																			noFlips = 0;
																			k++;  // Change Image
																			if(k==topImages.length) 
																				{
																					//j++;   // Change Display Mode
																					
																					// Random display Mode selection
																					//displayModes.sort(function() {return 0.5 - Math.random()});
																					displayModes = shuffle(displayModes); 
																					j = displayModes[0];
																					k = 0;
																				}
																		}
															}
													
													else if(j==8)    // Vertical Reverse SlICE Clipping Display Type
															{	
																	var inc = (120/(numClips/2));
																	//var top = i*inc-inc;
																	//var bottom = top + inc;
																	var bottom = 120-(i*inc-inc);
																	var top = bottom - inc;
																	var leftside = 0;
																	var rightside = 590;
																	var name = "intopbar" + ii.toString();
																	$('#topbar').append("<div id="+name+" class='forrotate' style='position:absolute;z-index:-1;display:none'><img src='"+$tpImage+"'></div>");
																	$('#'+name).css('clip','rect('+top+'px, ' + rightside + 'px, ' + bottom + 'px, '+leftside+'px)');
																	//$('#'+name).show('slide', { direction: 'right' }, 100);	
																	$('#'+name).fadeIn();
																	ii++;
																	if(i == (numClips/2))
																		{
																			i = 0;  // will be incremented at end of loop
																			k++;  // Change Image
																			if(k==topImages.length) 
																				{
																					//j++;   // Change Display Mode
																					
																					// Random display Mode selection
																					//displayModes.sort(function() {return 0.5 - Math.random()});
																					displayModes = shuffle(displayModes); 
																					j = displayModes[0];
																					
																					k = 0;
																				}
																		}
															}
													else if(j==9)    // Vertical Flip SlICE Clipping Display Type
															{	
																	var inc = (120/(numClips/2));
																	
																	if(i % 2 == 0)
																		{
																		   flip = 1;
																		   noFlips++;
																		}
																	else 
																		flip = 0;
																			
																	if(flip == 0)
																		{
																			var top = (noFlips+1)*inc-inc;
																			var bottom = top + inc;
																		}
																	else 
																		{
																		 
																	       var bottom = 120-(noFlips*inc-inc);
																		   var top = bottom - inc;
																		}
																
																	
																	var leftside = 0;
																	var rightside = 590;
																	var name = "intopbar" + ii.toString();
																	$('#topbar').append("<div id="+name+" class='forrotate' style='position:absolute;z-index:-1;display:none'><img src='"+$tpImage+"'></div>");
																	$('#'+name).css('clip','rect('+top+'px, ' + rightside + 'px, ' + bottom + 'px, '+leftside+'px)');
																	//$('#'+name).show('slide', { direction: 'right' }, 100);	
																	$('#'+name).fadeIn();
																	ii++;
																	if(i == (numClips/2))
																		{
																			i = 0;  // will be incremented at end of loop
																			k++;  // Change Image
																			noFlips = 0;
																			if(k==topImages.length) 
																				{
																					//j++;   // Change Display Mode
																					
																					// Random display Mode selection
																					//displayModes.sort(function() {return 0.5 - Math.random()});
																					displayModes = shuffle(displayModes); 
																					j = displayModes[0];
																					
																					k = 0;
																				}
																		}
															}		
															
													
												 else if(j == 10)   // 3d Rotation of Images around X Axis
													{
														$('#topbar').html("");
														var name = "intopbar" + ii.toString();
														$('#topbar').append("<div id="+name+" class='forrotate' style='position:absolute;z-index:-1'><img src='"+$tpImage+"'></div>");
														$('#'+name).css('clip','rect(0px, 590px, 120px, 0px)');
														$('.forrotate').css('transform','rotate3d(1,0,0,' + (360/rotCycles)*rot + 'deg)');
														
														if(rot == rotCycles)
															{
																if(k==(topImages.length-1)) 
																	{
																	   //j++;  // Change Display Mode
																	  // k=0;
																	   // Random display Mode selection
																		//displayModes.sort(function() {return 0.5 - Math.random()});
																		displayModes = shuffle(displayModes); 
																		j = displayModes[0];
																	   
																	   i = rotCycles+1; // Switch to else if(i > rotCycles)
																	   rot = 0;
																	}
																else if(k<(topImages.length-1))  // Change Images
																	{ 
																		k++;
																		//sq = 0;
																		rot = 0;
																	}
															}
													   rot++;
													   ii++;
													
													}



													
															
												
                                                    if(j!=4 && j!=5 && j!=6 && j!=10) i++;
														
											   }   
												
												else if(i > rotCycles)  // Switching section for images and display type
													{
														i = 1;
														//if(j!=2 && j!=3  && j!=4 && j!=5 && j!=6) $('#topbar').html("");
														
														k++;  // Advance to next image
														
														sq = 0;
														
														if(k>=topImages.length) // Reset to first image
															{
															    k = 0;
																//if (j==0 || j==1) j++;   // Change Display Mode
															}
														//if(j == 7) j = 0;
													}
													
									
									},200 );  
																
					
			}
		
		
		
		</script>



<div id="outframe">
	
	<div id="topbar">
	 <!--<div id="intopbar"><img></div>  -->
	</div>
	<div id="display">
			 <div id="leftmenu">
				<div id="itemContainer">
					<div id="upPointer" class="downPoint" ></div>
					<div id="orominer" class="menuitem" >Orominer<br/> Program<div id="clickdiv1" >Please Click</br>Here</div></div>
					<div id="oroHist"class="menuitem" >Orominer with<br/>Histological Data<div id="clickdiv2" >Please Click</br>Here</div></div>
					<div id="othello" class="menuitem" >Othello<br/> Game<div id="clickdiv3" >Please Click</br>Here</div></div>
					<div id="miniMotif"class="menuitem" >Mini-Motif<br/>Program<div id="clickdiv4" >Please Click</br>Here</div></div>
					<div id="technicalWriting"class="menuitem" >Technical<br/>Writing<div id="clickdiv5" >Please Click</br>Here</div></div>
					<div id="resume"class="menuitem" >Resume for<br/>Richard<div id="clickdiv8" >Please Click</br>Here</div></div>
					<div id="livingInVegas"class="menuitem" >Living in<br/>Vegas<div id="clickdiv9" >Please Click</br>Here</div></div>
					<div id="downPointer" class="downPoint" ></div>
					
				</div>
			 </div>
			 
			 
			 
			 <div id="description">
				<div id="getHeight">
					Hover over Program or Work Item to the left for its Descripition.<p>Then Click the 'Blinking Button' that will appear.</p>
					<p><span style="color:green;font-style:italic" id="clkmess">View in Google Chrome browser to See A 3-D File Cabinet Below!</span></p>
				</div>
			</div>
			
			
				<div class='container'>
					<div id='cabinet'>
						<figure class='cab front'></figure>
					    <figure class='cab back'></figure>
					    <figure class='cab right'></figure>
						<figure class='cab left'></figure>
						<figure class='cab top'></figure>
						<figure class='cab bottom'></figure>
					
						<figure class='drawer1 front'><div class='dtitle'>Software Development</div><div class='handle'><img src='<?php echo $doorHandle?>' ></div></figure>
						<figure class='drawer1 back'></figure>
						<figure class='drawer1 right'></figure>
						<figure class='drawer1 left'></figure>
						<figure class='drawer1 top'></figure>
						<figure class='drawer1 bottom'></figure>
					 
						<figure class='drawer2 front'><div class='dtitle'>Technical Writing</div><div class='handle'><img src='<?php echo $doorHandle?>'></div></figure>
						<figure class='drawer2 back'></figure>
						<figure class='drawer2 right'></figure>
						<figure class='drawer2 left'></figure>
						<figure class='drawer2 top'></figure>
						<figure class='drawer2 bottom'></figure>
					
						<figure class='drawer3 front'><div class='dtitle'>Engineering</div><div class='handle'><img <img src='<?php echo $doorHandle?>'></div></figure>
						<figure class='drawer3 back'></figure>
						<figure class='drawer3 right'></figure>
						<figure class='drawer3 left'></figure>
						<figure class='drawer3 top'></figure>
						<figure class='drawer3 bottom'></figure>
					
						<figure class='drawer1 file1'></figure>
						<figure class='drawer1 file2'></figure>
						<figure class='drawer1 file3'></figure>
						<figure class='drawer1 file4'></figure>
					
					
					<figure class='drawer2 file1'></figure>
					<figure class='drawer2 file2'></figure>
					<figure class='drawer2 file3'></figure>
					<figure class='drawer2 file4'></figure>
					<figure class='drawer2 back'></figure>
					<figure class='drawer2 folder1'></figure>
					<figure class='drawer2 folder2'></figure>
					<figure class='drawer2 folder3'></figure>
					<figure class='drawer3 file1'></figure>
					<figure class='drawer3 file2'></figure>
					
				</div>
			  </div>
				      
			
			
	</div>
</div>
<div id="outframebg">
</div>
 
       



		 
