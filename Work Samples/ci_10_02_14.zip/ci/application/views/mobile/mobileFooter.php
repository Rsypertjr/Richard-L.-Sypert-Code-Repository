<div id="formcontainer" style="visibility:hidden">
				<?php echo validation_errors(); ?>
				<?php 
				$attributes = array('id'=>'itemform');
				echo form_open('http://www.rlsworks.com/ci/index2',$attributes); 
				?>
						  <input type="hidden" name="itemchoice" value='none'/>
						  <input type="hidden" name="itemchoice2" value='none'/>
						  <input type="hidden" name="appType" value='<?php echo $appType; ?>'/>
				</form>

	</div>
	 
	 


</body>

</html>