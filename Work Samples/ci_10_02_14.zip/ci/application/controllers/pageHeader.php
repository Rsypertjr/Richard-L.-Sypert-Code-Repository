<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">-->

<html>
    <head>
       <meta http-equiv="content-type" content="text/html;charset=UTF-8">
		<!--  the following two lines load the jQuery library and JavaScript files -->
		<!--<script src="<?php echo $jqueryloc; ?>" type="text/javascript"></script> -->
		<!-- <script src="<?php echo $jqfile; ?>" type="text/javascript"></script> -->
		<!-- include JQuery and JQuery UI -->
		<!-- <script src="//code.jquery.com/jquery-1.10.2.js"></script> -->
		<!-- <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script> -->
		<link href = "<?php echo $headerCSS; ?>" rel="stylesheet" type="text/css" />
		<link href = "<?php echo $footerCSS; ?>" rel="stylesheet" type="text/css" />
		<!-- Custom ThemeRoller files -- excite bike  -->
		<link href="http://67.23.226.231/~rlsworks/ci/css/excite-bike/jquery-ui-1.10.4.custom.css" rel="stylesheet">
		<script src="http://67.23.226.231/~rlsworks/ci/js/jquery-1.10.2.js"></script>
		<script src="http://67.23.226.231/~rlsworks/ci/js/jquery-ui-1.10.4.custom.js"></script>
		
		<?php $page = $whichPage; ?>
		
		<?php if($page == "livingInLV"){ ?>
			<link href = "<?php echo $livingInLVCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Living in Vegas</title>
		<?php } ?>
		<?php if($page == "front"){?>
			<link href = "<?php echo $frontCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Portfolio Front</title>
		<?php } ?>	
		<?php if($page == "miniMotif"){?>
			<link href = "<?php echo $miniMotifCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Input Form for Minimotif Search</title>
		<?php } ?>		
		<?php if($page == "newOrominer"){?>
			<link href = "<?php echo $newOrominerCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Orominer Program</title>
		<?php } ?>	
		<?php if($page == "orominerHisto"){?>
			<link href = "<?php echo $orominerHistoCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Orominer with Histology</title>	
		<?php } ?>
		<?php if($page == "othello"){?>
			<link href = "<?php echo $othelloCSS; ?>" rel="stylesheet" type="text/css" />
			<link href = "<?php echo $css; ?>" rel="stylesheet" type="text/css" />
			<title>Othello Game</title>	
		<?php } ?>
		<?php if($page == "techWriter"){?>
			<link href = "<?php echo $techWriterCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Technical Writing</title>	
		<?php } ?>
		<?php if($page == "resumes"){?>
			<link href = "<?php echo $resumesCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Resume Viewing</title>	
		<?php } ?>
		<?php if($page == "whitePaper"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>White Paper</title>	
		<?php } ?>
		<?php if($page == "engSpec"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Engineering Specification</title>	
		<?php } ?>
		<?php if($page == "GraingerABCDE"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Grainger ABCDE Series B</title>	
		<?php } ?>
		<?php if($page == "GraingerCDE"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Grainger CDE</title>	
		<?php } ?>
		<?php if($page == "mecProductManual"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>MEC Product Manual VT 1.6</title>	
		<?php } ?>
		<?php if($page == "codeDev"){?>
			<link href = "<?php echo $codeDevCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Code Development Specification</title>	
		<?php } ?>
			<?php if($page == "emailForm"){?>
			<link href = "<?php echo $emailFormCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Making Contact</title>	
		<?php } ?>
			<?php if($page == "webTech"){?>
			<link href = "<?php echo $webTechCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Web Page Technologies Used</title>	
		<?php } ?>
			<?php if($page == "viewPDFResume"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Show PDF Resume</title>	
		<?php } ?>
			<?php if($hfSwitch == "on"){?>
			<link href = "<?php echo $mobileSwitchCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Mobile Portfolio</title>
		<?php } ?>
		
		<style>	
		   #pGraphic {
					position:relative;
					height:18em;
					width:100%;
					padding:2em 0em 2em 25%;
					background-color: #F0F0F0;
					
			}
			#positDiv{
					position:relative;
					height:100%;
					width:40em;
					zoom:100%;
			}
			#positDiv img{
					position:relative;
					width:100%;
					float:left;
					
			
			}
				
			#positDiv h2 {
					position:relative;
					width:100%;
					float:left;
					text-align:center;
					font-size:2.5em;
					margin-bottom:0.5em;
					
					}
		</style>
		</head>
		<body onload="{JQFunctions();JQFunctions2();}">
		
		<script type="text/javascript">
		 $( document ).ready(function() {
		 
						var hfSwitch = '<?php echo $hfSwitch; ?>';
						
						if(hfSwitch == 'on')
							{
								$('#headbar').css('opacity','0.0').css('zoom','1%');
								$('#footContainer').css('opacity','0.0').css('zoom','1%');
								$('#llvOutFrame').add('#outDiv').add('#resumeContainer')
									.css('border','none').css('background','none').css('zoom','85%');
								$('#llvOutFrame').css('top','-28%').css('left','10em');
								$('#outframe').css('left','-15em').css('top','-35em');
								$('#oframe').css('left','-6%').css('top','-25em');
								$('#otrframe').css('zoom','65%');
								$('#mobX').css('margin','0em 1em');
								$('#mmContainer').css('zoom','70%').css('top','-25%').css('left','10%');
								$('#am1,#am2').css('width','15em').css('margin-bottom','4em');
								$('#qu').css('margin-bottom','4em');
								$('#motifsel').css('height','35em');
								$('#loaderMessage').css('left','-25em');
								
								
								$('body').prepend('<div id="pGraphic"><div id="positDiv"><h2>RLS Career Porfolio</h2><img src="<?php echo $mhImage3; ?>"/></div></div>');
								
							}
						else if(hfSwitch == 'off')
							{
								$('#headbar').css('opacity','1.0').css('zoom','100%');
								$('#footContainer').css('opacity','1.0').css('zoom','100%');;
								
							}
							
							var mhImages = new Array();
							  mhImages[0] = '<?php echo $mhImage2; ?>';
							  mhImages[1] = '<?php echo $mhImage3; ?>';
							  mhImages[2] = '<?php echo $mhImage5; ?>';
							  mhImages[3] = '<?php echo $mhImage6; ?>';
							  mhImages[4] = '<?php echo $mhImage7; ?>';
							  mhImages[5] = '<?php echo $mhImage8; ?>';
						   
							var i = 0;
							var mhImg = '';
							setInterval(function(){
									mhImg = mhImages[i];
									$('#pGraphic #positDiv').html('');	
									$('#pGraphic #positDiv').append('<h2>RLS Career Porfolio</h2><img src="'+mhImg+'"/>').fadeIn(1000);	
									i++;
									if(i>(mhImages.length-1)) i = 0;	
								},3000);	
									
							
							

           });		 
		   
		
		
			function JQFunctions2()
				{   
				        // Remove headers for mobile app
						
						
								$('div#softwareDevWork,div#technicalWritingWork,div#engineeringWork,div#contacts,div#techManuals').mouseenter(
									function()
										{
										
										 // find top-level menu children
										  var len = 0;
										  len = $(this).find('.lev3, .lev4').length;
										  if(len > 0)// change arrow icon if children
											{
												$(this).children('.lev1 >.ui-icon')
													.removeClass('ui-icon-triangle-1-s')
													.addClass('ui-icon-triangle-1-e');
												
											
												$(this).mouseleave(function()
													{
														$(this).children('.lev1 >.ui-icon')
															.removeClass('ui-icon-triangle-1-e')
															.addClass('ui-icon-triangle-1-s');
														
													});
													
												$(this).children('.lev3 >.ui-icon')
													.removeClass('ui-icon-triangle-1-s')
													.addClass('ui-icon-triangle-1-e');
											
												$(this).mouseleave(function()
													{
														$(this).children('.lev3 >.ui-icon')
															.removeClass('ui-icon-triangle-1-e')
															.addClass('ui-icon-triangle-1-s');
													});
											}
									
										});
										
										
								$('button:first').button({
									icons: {
												primary: 'ui-icon-home'
										   }
									 }).next().button({
													  icons: {
																secondary: 'ui-icon-locked'
															 }
													  })
									   .next().button({
													  icons: {
																secondary: 'ui-icon-locked'
															 }
													  })
									   .next().button({
													  icons: {
																secondary: 'ui-icon-locked'
															 }
													  })
									   .next().button({
													  icons: {
																secondary: 'ui-icon-locked'
															 }
													  })
									   .next().button({
													  icons: {
																secondary: 'ui-icon-locked'
															 }
													  });
								
								$('button').css('display','block').css('display','inline').css('margin-bottom','1em');	
								$('button .aUl').css('display','none'); 
								$('button .aUl .aLi .aUl').css('display','none'); 
							
								$('#sdLi3').click(function()
										{
										
											alert("gets here");
										
										});
							
							
								
								$('button').on('mouseenter',function()
									{
										$(this).siblings()
											   .find('.aUl').css('display','none');
										$(this).siblings()	   
											   .find('span.ui-icon-unlocked')
												   .removeClass('ui-icon-unlocked')
												   .addClass('ui-icon-locked');
									
										$(this).find('.aUl')
											.css('display','block')
											.fadeIn(1000)
											.css('opacity','1.0')
											.find('.aLi')
												.css('color','white')
												.on('mouseenter',function()
													{
														$(this).find('.aUl').css('display','block'); 
														$(this).addClass('ui-state-active')
															   .css('color','blue'); 
															   
														
														$(this,':contains("Analyzer 1")')
															.on('mousedown',function()
																{
																	
																	$(this).css('color','yellow');
																	$("#itemform input[name='itemchoice']").val('orominer');
																	$('#itemform').submit();
																});  
			
														$(this).filter(function() {
																  return $(this).text() == 'Human Organ System Analyzer 2';
																})
																.on('mousedown',function()
																	{
																		$(this).css('color','yellow');
																		$("#itemform input[name='itemchoice']").val('oroHist');
																		$('#itemform').submit();
																	});	
															
														$(this).filter(function() {
																  return $(this).text() == 'Play Othello Game';
																})
																.on('mousedown',function()
																	{
																		$(this).css('color','yellow');
																		$("#itemform input[name='itemchoice']").val('othello');
																		$('#itemform').submit();
																	});		
															
														$(this).filter(function() {
																  return $(this).text() == 'Amino Acid Code Sequence Analyzer';
																})
																.on('mousedown',function()
																	{
																		$(this).css('color','yellow');
																		$("#itemform input[name='itemchoice']").val('miniMotif');
																		$('#itemform').submit();
																	});		
														

														$(this).filter(function() {
																  return $(this).text() == 'Code Development Specification';
																})
																.on('mousedown',function()
																	{
																		$(this).css('color','yellow');
																		$("#itemform input[name='itemchoice']").val('codetech');
																		$('#itemform').submit();
																	});		
																	
														$(this).filter(function() {
																  return $(this).text() == 'Web Page Technologies Used';
																})
																.on('mousedown',function()
																	{
																		$(this).css('color','yellow');
																		$("#itemform input[name='itemchoice']").val('webTech');
																		$('#itemform').submit();
																	});	
																	
																	
																	
																	
														$(this).filter(function() {
																  return $(this).text() == 'Dynamic HTML Resume w/Downloads';
																})
																.on('mousedown',function()
																	{
																		$(this).css('color','yellow');
																		$("#itemform input[name='itemchoice']").val('resume');
																		$('#itemform').submit();
																	});	

																	
														$(this).filter(function() {
																  return $(this).text() == 'Having Vegas Family Fun';
																})
																.on('mousedown',function()
																	{
																		$(this).css('color','yellow');
																		$("#itemform input[name='itemchoice']").val('livingInVegas');
																		$('#itemform').submit();
																	});				
														
														$(this).filter(function() {
																  return $(this).text() == 'White Paper';
																})
																.on('mousedown',function()
																	{
																		$(this).css('color','yellow');	
																		$("#itemform input[name='itemchoice']").val('whitePaper');
																		$('#itemform').submit();
																	
																	});				
														
														$(this).filter(function() {
																  return $(this).text() == 'Engineering Specification';
																})
																.on('mousedown',function()
																	{
																		 $(this).css('color','yellow');	
																		 $("#itemform input[name='itemchoice']").val('engSpec');
																		 $('#itemform').submit();
																	});			
														
														$(this).filter(function() {
																  return $(this).text() == 'Making Contact';
																})
																.on('mousedown',function()
																	{
																		 $(this).css('color','yellow');	
																		 $("#itemform input[name='itemchoice']").val('email1');
																		 $('#itemform').submit();
																	});	
														 $(this).filter(function() {
																  return $(this).text() == 'Web Page Technologies Used';
																})
																.on('mousedown',function()
																	{
																		 $(this).css('color','yellow');	
																		 $("#itemform input[name='itemchoice']").val('webTech');
																		 $('#itemform').submit();
																	});			
																	
														/* .filter(function() {
														  return $(this).text() == 'Some text';
														});  */
														
												
														
													})
												  .on('mouseleave',function()
													 {
														$(this).find('ul').css('display','none');
														$(this).removeClass('ui-state-active')
															   .css('color','white');
															   
													 })
												   .find('.aUl')
												   .on('mouseenter',function()
													  {
															$(this).addClass('ui-state-active')
														   .css('color','blue')
														   .css('display','block'); 
														   
														   $(this).filter(function() {
															  return $(this).text() == 'Grainger ABCDE Series B';
															})
															.on('mousedown',function()
																{
																	$(this).css('color','yellow');	
																	$("#itemform input[name='itemchoice']").val('GraingerABCDE');
																	$('#itemform').submit();
																});
																
															$(this).filter(function() {
															  return $(this).text() == 'Grainger CDE';
															})
															.on('mousedown',function()
																{
																	$(this).css('color','yellow');	
																	$("#itemform input[name='itemchoice']").val('GraingerCDE');
																	$('#itemform').submit();
																});	
																
															$(this).filter(function() {
															  return $(this).text() == 'MEC Product Manual VT 1.6';
															})
															.on('mousedown',function()
																{
																	$(this).css('color','yellow');	
																	$("#itemform input[name='itemchoice']").val('mecProductManual');
																	$('#itemform').submit();
																});	
																	
																
													  })	
													.on('mouseleave',function()
													  {
														  
															$(this).removeClass('ui-state-active')
														   .css('color','white'); 
													
													  });
										
										$('button .aUl .aLi .aUl').css('display','none'); 
										// button state, color and list color
										$(this).addClass('ui-state-active')
											   .addClass('ui-state-focus')
											   .css('color','blue')
											   .find('.aUl').css('color','white');
											   
										
										var x = 0
										$(this).click(function(e)
										{
										
											
										
											if(x == 1)
												{
													$(this)
													   .find('span.ui-icon-locked')
													   .removeClass('ui-icon-locked')
													   .addClass('ui-icon-unlocked'); 
													$(this)
														.find('.aUl')
														.css('display','block')
														.css('color','white')
														.fadeIn(1000).css('opacity','1.0');
													
													
											
											
													$('button .aUl .aLi .aUl').css('display','none'); 
													$(this).addClass('ui-state-active')
														   .addClass('ui-state-focus');
													x = 0;
												}else{
													$(this).find('.aUl')
														   .css('display','none').fadeOut(2000)
														   .css('opacity','0.0');
													$(this).removeClass('ui-state-active')
														   .removeClass('ui-state-focus')
														   .find('span.ui-icon-unlocked')
															   .removeClass('ui-icon-unlocked')
															   .addClass('ui-icon-locked');
															   
													x = 1;
													}
													e.preventDefault();
										});
										
										
											   
										//unlock icon on mouse enter	   
										$(this).find('span.ui-icon-locked')
											   .removeClass('ui-icon-locked')
											   .addClass('ui-icon-unlocked');
											   
										
									
									});
								$('button').mouseleave(function()
									{
										$(this).css('color','white');
									
									});
									
								$('button:contains("Home")').on('mousedown',function()
												{
													$(this).css('color','yellow');
													$("#itemform input[name='itemchoice']").val('frontPage');
													$('#itemform').submit();
												});
												
										
					
		/*	$('#footContainer').css('zoom','1.3');
			var hbarHeight = $('#headbar').height();	
           		 var bConHeight = $('#hmenuContainer').height();
			var scaler = (hbarHeight/bConHeight)*0.17;
			$('#hmenuContainer').css('zoom',scaler);  */
		}
	</script>
		
		
	</head>
	
	
	<div id="headbar" class="ui-widget ui-state-default">
		<div id="hmenuContainer">
			<button>Home
			</button>
			<button>About&nbsp;&nbsp;&nbsp;&nbsp;
				<div id="abUl1" class="aUl">
					<div id="abLi1" class="aLi">Web Page Technologies Used</div>
					<div id="abLi2" class="aLi" >Making Contact</div>
				</div>
			</button>
			<button name='softDev'>Software Development
				<div id="sdUl1" class="aUl">
					<div id="sdLi1" class="aLi">Amino Acid Code Sequence Analyzer</div>
					<div id="sdLi2" class="aLi">Play Othello Game</div>
					<div id="sdLi3" class="aLi">Human Organ System Analyzer 1</div>
					<div id="sdLi4" class="aLi">Human Organ System Analyzer 2</div>
				</div>
			</button>
			<button>Technical Writing
				<div id="twUl1" class="aUl">
					<div id="twLi1" class="aLi">Product and Maintenance Manuals
						<div id="twUl2" class="aUl">Grainger ABCDE Series B</div>
						<div id="twUl3" class="aUl">Grainger CDE</div>
						<div id="twUl1" class="aUl">MEC Product Manual VT 1.6</div>
					</div>
					<div id="twLi2" class="aLi">White Paper</div>
					<div id="twLi3" class="aLi">Engineering Specification</div>
					<div id="twLi4" class="aLi">Code Development Specification</div>
				</div>
			</button>
			<button>My Resume
				<div id="mrUl1" class="aUl">
					<div id="mrLi1" class="aLi">Dynamic HTML Resume w/Downloads</div>
				</div>
			</button>
			<button>Living In Vegas
				<div id="lvUl1" class="aUl">
					<div id="lvLi1" class="aLi">Having Vegas Family Fun</div>
				</div>
			</button>
		</div>
	</div>
	
