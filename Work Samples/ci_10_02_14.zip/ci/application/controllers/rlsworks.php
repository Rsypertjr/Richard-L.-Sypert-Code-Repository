<?php
class rlsworks extends CI_Controller {
    
public function __construct()
{
              parent::__construct();  
            
            
            $this->load->helper('url'); 
            $this->load->helper('html');
            $this->load->helper('file');
            $this->load->helper('form');
            $this->load->library('form_validation');
            $this->load->helper('cookie');
    
    
    
            $this->data['css'] = base_url('css/othello2.css');
            $this->data['jqueryloc']= base_url('assets/js/jquery-1.10.2.js');
            $this->data['jqfile']= base_url('assets/js/global.js');
            $this->data['cellpost']= site_url('othello/index'); 
            

}


function index()
{
        $this->load->view('rlsworks/front',$this->data);
}



function chooseItem()
  {
    
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('itemchoice', 'Item Choice', 'required');
     
        $item = $this->input->post('itemchoice');
        if($item == 'othello')
			$this->load->view('rlsworks/othello');
    
    
    
    
    }

}
