<!DOCTYPE html>
<html>
<head>
	<title>RLS Career Portfolio</title>

	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link href = "<?php echo $mobileCSS; ?>" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.3/jquery.mobile-1.4.3.min.css" />
	<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.4.3/jquery.mobile-1.4.3.min.js"></script>
</head>
<body>
<div data-role="page" id="mobileFront">
<script type="text/javascript">

  var mhImages = new Array();
  mhImages[0] = '<?php echo $mhImage2; ?>';
  mhImages[1] = '<?php echo $mhImage3; ?>';
  mhImages[2] = '<?php echo $mhImage5; ?>';
  mhImages[3] = '<?php echo $mhImage6; ?>';
  mhImages[4] = '<?php echo $mhImage7; ?>';
  mhImages[5] = '<?php echo $mhImage8; ?>';
  
  $('#mobileFront').on('pageinit',function() {
  
                var i = 0;
				var mhImg = '';
				setInterval(function(){
				        mhImg = mhImages[i];
						$('#mobfHeader').html('');	
						$('#mobfHeader').append('<h2>RLS Career Porfolio</h2><img src="'+mhImg+'" data-role="button" class="ui-btn-down"/>').fadeIn(1000);	
						i++;
						if(i>(mhImages.length-1)) i = 0;	
					},3000);
	});
	
	$('#mobileFront').on('pageinit',function() {
				$(this).css('zoom','30%');
				$('#aminocodes .fsiz').add('#subButton')
					.css('font-size','2.0em');
				$('#subButton').css('font-size','2.9em');
				$('.aButton2').css('font-size','1.6em');
				$('#qu-button span').css('height','150%');
			 });
	
</script>



	<div id="mobfHeader" data-role="header" class="ui-btn ui-corner-all">
	    <h2>RLS Career Porfolio</h2>
		<img src="<?php echo $mhImage3; ?>" data-role="button" class="ui-btn-down"/>
	</div><!-- /header -->