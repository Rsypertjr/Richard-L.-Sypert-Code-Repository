<!DOCTYPE html>
<html>
<head>
	<title>RLS Career Portfolio</title>

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.3/jquery.mobile-1.4.3.min.css" />
	
	<link href = "<?php echo $showMobilePDFCSS; ?>" rel="stylesheet" type="text/css" />
	<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.4.3/jquery.mobile-1.4.3.min.js"></script>
</head>
<body>

<div data-role="page">

	<div data-role="header" class="ui-btn ui-corner-all">
	    <p>RLS Career Porfolio</p>
		<img src="<?php echo $mhImage3; ?>" data-role="button" class="ui-btn-down" style="zoom:50%"/>
	</div><!-- /header -->

	<div role="main" class="ui-content">
		<div data-role="collapsibleset" data-theme="a" data-content-theme="b" data-collapsed-icon="arrow-r" data-expanded-icon="arrow-d">
			<div data-role="collapsible">
				<h3>Orominer Program</h3>
				<p>The Orominer program shows a hierarchical organization of the human body constitution. Its top level is Organ Systems. It uses JavaScript, JQuery for dynamic resizing of text during zooming
				   and event synchronization between hierarchical display and graphic display.
				</p>
				<p>
				   DOM HTML elements are used to dynamically generate SVG graphical elements. MySQL Database information is converted into XML format using PHP
				   for up front access by the code for generation of Hierachical Display.  
				</p>
				<p>
				   Unfortunately ONLY THE First 3 NODES Of DATA was developed at Project Completion.
				</p>
				<ul data-role="listview" data-inset="true">	
					<li><a href="#">Open Orominer 1 Program</a></li>
				</ul>
			</div>
			<div data-role="collapsible">
				<h3>Orominer with Histological Data</h3>
				<p>This orominer program contains Histological Data within the Hierarchical Organization of Human Body makeup.  Histological Data is ......</p>
				<ul data-role="listview" data-inset="true">	
					<li><a href="#">Open Orominer 2 Program</a></li>
				</ul>
			</div>
			<div data-role="collapsible">
				<h3>Othello Game</h3>
				<p>This is an adaptation of the Classic Othello game where one player competes with the Computer.  
				</p>
				<p>Two Player Play could be implemented, 
				   as well as, making levels of difficulty for game play.
				</p>
				<ul data-role="listview" data-inset="true">	
					<li><a href="#">Open Othello Game</a></li>
				</ul>
			</div>
			<div data-role="collapsible">
				<h3>Mini-Motif Program</h3>
				<p>This program gives statistics for all combinations of amino acid sequences within a protein. 
				</p>
				<p>The protein sequence is parsed by regex techniques from a text file, into a MySQL database.  
				</p>
				<p>The first and last amino acid is chosen in the GUI, as well as, 
				   the desired statistical output.  
				</p>
				<p>The database accessed from JavaScript AJAX to PHP on the server side which returns the statistics.
				</p>
				<ul data-role="listview" data-inset="true">	
					<li><a href="#">Open Mini-Motif Program</a></li>
				</ul>
			</div>
			<div data-role="collapsible">
				<h3>Technical Writing</h3>
				
				<p>I am a Technical Writer too!
						<div data-role="collapsible" data-inset="true" data-theme="b" data-content-theme="c">
								<h2>See Documents...</h2>
								<ul data-role="listview" data-inset="true">
									<div data-role="collapsible" data-inset="true" data-theme="c" +
									ata-content-theme="d">
											<h2>Product Manuals...</h2>
											<ul data-role="listview" data-inset="true">
												<li><a href="#">Grainger ABCDE Series B</a></li>
												<li><a href="#">Grainger CDE</a></li>
												<li><a href="#">MEC Product Manual VT 1.6</a></li>
											</ul>
									</div>
									
									<li><a href="<?php echo $whitePaper_mobile ?>">White Paper</a></li>
									<li><a href="#">Engineering Specification</a></li>
									<li><a href="#">Code Development Specification</a></li>
								</ul>
						</div>
				</p>
			</div>
			<div data-role="collapsible">
				<h3>Resume for Richard</h3>
				<p>Resume for Richard L. Sypert Jr. in Html and PDF formats.  The HTML Resume Format Only Uses CSS and no JavaScript!</p>
				<ul data-role="listview" data-inset="true">	
					<li><a href="#">Open Dynamic Resume</a></li>
				</ul>
			</div>
			<div data-role="collapsible">
				<h3>Living In Vegas</h3>
				<p>Living in Las Vegas has been a Discovery.</p>
				<ul data-role="listview" data-inset="true">	
					<li><a href="#">Open Vegas Living</a></li>
				</ul>
			</div>
		</div>
	</div><!-- /content -->

	<div data-role="footer">
	
	
	
	
	</div> 
</div><!-- /page -->

</body>
</html>