<!--<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"> -->
<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">-->



 <script type="text/javascript">

        </script>
<div id="outDiv">
 <div class="oframe" id="oframe">
    <div id="headr"><span id="gameTitle">Othello Game</span>
		<div id="resetGame" class="setCursor">Reset Game</div>
		<div id="frontPage" class="setCursor">Front Page</div>
	</div>
    <div id="status">
        <div id="formcontainer">
            
			<form id="moveinputform" method="post" action="http://www.rlsworks.com/ci/othello/index2">
                <div id="xval" style="display:<?php echo $display1; ?>">
                    <label style="margin-left:5%">Enter X value of Move</label>
                    <input name="xvalue" type="text"  value="Enter X Value Here"  onclick="clearInput()" style="margin-left:5%"/>
                </div>
                <div id="yval"  style="display:<?php echo $display1; ?>">
                    <label style="margin-left:5%">Enter Y value of Move</label>
                    <input name="yvalue" type="text"  value="Enter Y Value Here"  onclick="clearInput()" style="margin-left:5%"/>
                </div>
			
			
			
                <div id="botcontainer">
					<div id="message" ><?php echo $message; ?></div>
					<div id="mask" style="display:<?php echo $display3; ?>">
							<div id="subbutton"   style="display:<?php echo $display1; ?>">
									<div id="cross">
									   <input type="hidden"  name="hid" value="<?php echo $flag; ?>"/>
									    <input type="submit" name="submit1" class="setCursor" style="width:225px;font-size:1.2em" value="Submit This Move"/>
									</div>
							</div>
							
							<div id="playbutton" style="display:<?php echo $display2; ?>" >
								  <input type="submit" name="submit2" class="setCursor" style="width:225px;font-size:1.2em" value="Press to Play" />
							</div>
					</div>
				
					<div id="nextbutton" style="display:<?php echo $display4; ?>" >
							<input type="submit" name="submit3" class="setCursor" style="width:225px;font-size:1.2em"  value="Press to Continue" />
					</div>
				</div>
                <input type="hidden"  name="applicationType" value="<?php echo $appType; ?>"/>
				<input type="hidden" name="othelloChoice" value='none'/>
				<input type="hidden" name="applType" value='none'/>					  
			</form>
			
			
			</div> <!-- #formcontainer -->
	    </div>  <!-- /#status -->
			
   