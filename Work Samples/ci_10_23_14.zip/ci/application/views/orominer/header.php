<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">-->

<html>
    <head>
        <meta http-equiv="content-type" content="text/html;charset=UTF-8">
        
        
        <!--  the following two lines load the jQuery library and JavaScript files -->
        <script src="<?php echo $jqueryloc; ?>" type="text/javascript"></script>
        <script src="<?php echo $jqfile; ?>" type="text/javascript"></script>
	<!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>-->
         <link href = "<?php echo $css; ?>" rel="stylesheet" type="text/css" />
        <title>Othello Game</title>
        
        
        <script type="text/javascript">
            function JQFunctions()
                {              
           /*         $('.cell').bind('mouseup',function()
                            {
                                        var y = $(this).parent().attr('id').substring(3);
                                        y = y - 1;
                                        var x = $(this).attr('title');
                                        
                                    $("#xval input[name='xvalue']").val(x);
                                    $("#yval input[name='yvalue']").val(y); 
                              
                            });   
                            */
                      
                      $(document).bind('mouseover mousemove',function()
                        {
                             
                                   //$('#clkspace').slideDown('medium');
                                   //$('#clkspace').slideUp('medium');
                                    $('#clkspace').animate({opacity:'0.0'},"medium");
									$('#clkspace').animate({fontSize:'1.0em',opacity:'1.0'},"medium");  
									  
                                    //$('#prbutton').slideDown('medium');
                                    //$('#prbutton').slideUp('medium');
                                            
							/*				
									  $("#prbutton").animate(
											{height:'100px'},
											"medium"}
										  );		*/
									 $("#prbutton").animate({opacity:'0.0'},"medium");
									 $("#prbutton").animate({fontSize:'1.0em',opacity:'1.0'},"medium"); 
											
					/*				 $('#prbutton').stop().animate(
											{height:12px
											//opacity:'0.5'},
											{
												duration: 500,
											//	step: function(now,fx){
												//	$(this).css({"transform": "rotate("+now+"deg)"});
												  }
										    }
										);  */
									 $("#prbutton2").animate({opacity:'0.0'},"medium");
									 $("#prbutton2").animate({fontSize:'1.0em',opacity:'1.0'},"medium"); 		
                                   // $('#prbutton2').slideDown('medium');
                                   // $('#prbutton2').slideUp('medium');
                                        
									 $("#prbutton3").animate({opacity:'0.0'},"medium",function()
										{
											$("#subbutton input[name='submit']").hide();
										});
                                    $("#prbutton3").animate({fontSize:'1.0em',opacity:'1.0'},"medium"); 
									
									
									
									if(	$('#message').text().search('Submit') > 0)
										 $("#subbutton input[name='submit']").show();	

									if(	$('#message').text().search('Highest Score') > 0)
										{
											$("#botcontainer").css("height","90%");
											$ht = $("#botcontainer").height();
											$("#message").css("height",$ht);
										}
									
									
									if(	$('#message').text().search('to Play') > 0)
										{
											$("#botcontainer").css("height","90%");
											$ht = $("#botcontainer").height();
											$("#message").css("height",($ht*0.75));
											$("#message").css("font-size","1.8em");
										}
										
										
									if(	$('#message').text().search('Your move') > 0)
										{
											$("#botcontainer").css("height","90%");
											$ht = $("#botcontainer").height();
											$("#message").css("height",($ht*0.75));
											$("#message").css("font-size","1.8em");
										}
										
									if(	$('#message').text().search('Submit Move') >= 0)
										{
											$("#message").css("font-size","1.65em");
										}	
										
									
									if(	$('#message').text().search('Input Coordinates') >= 0)
										{
											$("#message").css("font-size","1.15em");
										}	
										
										
									
									if(	$('#message').text().search('No Moves') >= 0)
										{
											$("#message").css("font-size","1.15em");
										}		
										
								
										
										
									if(	$('#message').text().search('NOT A') >= 0)
										{
											$("#botcontainer").css("height","90%");
											$ht = $("#botcontainer").height();
											$("#message").css("height",($ht*0.55));
											$("#message").css("font-size","1.75em");
										}	
										
									
									if(	$('#message').text().search('MOVE AGAIN') >= 0)
										{
											$("#botcontainer").css("height","90%");
											$ht = $("#botcontainer").height();
											$("#message").css("height",($ht*0.70));
											$("#message").css("font-size","1.1em");
										}	
										
										
									
                         });      
						 
                
                         $("#cross").mousedown(function()
                         {
                             
                                          
                                           var x = $("#xval input[name='xvalue']").val(); 
                                           var y =  $("#yval input[name='yvalue']").val();
										   $("#subbutton input[name='submit']").show();
                                          if(   ( x < 0  ||  x > 7)  || ( y < 0  ||  y > 7)  )
                                            {
                                                    $('#message').css('font-size','1.2em');
                                                    $('#message').text("Your Selection is Not between 0 and 7.  \nPlease Select Again");
                                                    $("#xval input[name='xvalue']").val('');
                                                    $("#yval input[name='yvalue']").val('');
                                                    $("#subbutton input[name='submit']").hide();
                                            }
											
											
											
										  if( (x.toString().search('Enter') >= 0) || ( x.toString().search('Enter') >= 0) )
										  {
												
												  $("#subbutton input[name='submit']").hide();
												  $("#message").text("YOU FORGOT TO INPUT A MOVE!!!");
										  
											}
									
                        });
                              
							  
							  
							  
							  
							  
                         $("#xval input[name='xvalue']").keydown(function()
                             {
                                      $('#message').css('font-size','50%');
                                      $("#subbutton input[name='submit']").show();
                             
                             });
							 

						  
		
                            
                       $('.cell').bind('mousedown',function()
                          {
									
								$(this).css('background-color','tan').css('color','black');
								$(this).css('box-shadow','inset 0px 0px 10px 6px rgba(0,0,0,0.2)');	
								
								$(this).mouseup(function()
									{
										  // $('#message').css('font-size','170%');
										  $(this).css('box-shadow','inset 0px 0px 0px 0px rgba(0,0,0,0.0)');	
										   $('#message').css('color','purple');
										   $('#botcontainer').css('height','95%');
										   $('#message').text('');
										   $('#message').append($("<div id='prbutton' style='display:inline'>**Press Button**</div><div style='display:inline'>to Submit Move</div>"));
										   $("#subbutton input[name='submit']").show();
												var y = $(this).parent().attr('id').substring(3);
												y = y - 1;
												var x = $(this).attr('title');
										 
											$("#xval input[name='xvalue']").val(x)
											$("#yval input[name='yvalue']").val(y); 

									});
								
		                   
                          });
						  
				
						$('.cell').bind('click',function()
                          {
						    
						       	var $el = $(this).filter(function()
									{
										return $(this).text() == '.';
									});
								
							    if($el.length > 0)
									$el.html("<div class='oimage' style='position:relative;left:0px;top:0px'><img style='position:relative;height:96%;width:96%' src='<?php echo $oimg; ?>'></div>");
							   
						  });
						  
						  
						  $('.cell').bind('mousedown',function()
                          {
						       	var $el = $(this).filter(function()
									{
										return $(this).text() == '.';
									});
								
							    if($el.length == 0)
									$(this).html('<div>.</div>');
						  });



				
				$('.cell').bind('mouseenter',function()
                    {
                           $(this).css('color','tan').css('border-color','black');
                             
                    });
					
					
					
				
				$('.cell').bind('mouseover',function()
                    {
                           $(this).css('background-color','beige').css('border-color','black');
                             
                    });


                $('.cell').bind('mouseleave',function()
                    {
                            $(this).css('color','black').css('background-color','yellow');
                             
                    });
					
					
				
				
			    $('#message').bind('mousedown',function()
					{
					
						if(	$(this).text().search('NEW GAME') >= 0)
						{
							window.open('http://67.23.226.231/~rlsworks/ci/', '_blank');
						}			
					
					});
			
				$('#resetGame').bind('click',function()
					{
						$(this).css('background','linear-gradient(#D8D8D8, grey)');	
						$("#itemform input[name='itemchoice']").val('resetGame');
						$('#itemform').submit();
						
					});

				$('#frontPage').bind('click',function()
					{
					
						$(this).css('background','linear-gradient(#D8D8D8, grey)');
						$("#itemform input[name='itemchoice']").val('frontPage');
						$('#itemform').submit();
					});	
					      
				$('#frontPage').bind('mousedown',function()
					{
						$(this).css('color','grey');
						$(this).css('box-shadow','inset 0px 0px 5px 3px rgba(0,0,0,0.2)');	
					});
					
					
                 $('#resetGame').bind('mousedown',function()
					{
						$(this).css('color','grey');
						$(this).css('box-shadow','inset 0px 0px 5px 3px rgba(0,0,0,0.2)');	
					});
                   
				   
				// When document is ready   
					$(document).ready(function()
						{
							$(".cell:contains('X')").filter(function(index)
									{
									    var cellname = "cellrotate" + index;
										$(this).html("<div class='" + cellname + "' style='position:relative;left:0px;top:0px;z-index:2;opacity:1.0'><img style='position:relative;height:96%;width:96%' src='<?php echo $ximg; ?>'></div>");
									     //   $("."+cellname).css('animation','xorotation 2s');
										 
										 $("."+cellname).stop().animate(
											{rotation: 360},
											{
												duration: 500,
												step: function(now,fx){
													$(this).css({"transform": "rotate("+now+"deg)"});
												  }
										    }
										);
											
									});		
									
							$(".cell:contains('O')").filter(function(index)
									{
											var cellname2 = "cellrotate2" + index;
										    $(this).html("<div class='" + cellname2 + "' style='position:relative;left:0px;top:0px;z-index:2;opacity:1.0'><img style='position:relative;height:96%;width:96%' src='<?php echo $oimg; ?>'></div>");
											//$("."+cellname2).css('animation','xorotation 2s');
											$("."+cellname2).stop().animate(
											{rotation: 360},
											{
												duration: 500,
												step: function(now,fx){
													$(this).css({"transform": "rotate("+now+"deg)"});
												  }
										    }
										);
									});
									
					
						});
               }    // end of JQFunction() function
                
         
              function clearInput()
                  {
               
                     $("#xval input[name='xvalue']").attr('value','');
				     $("#yval input[name='yvalue']").attr('value',''); 
                   }
         
          
					
					
				
			
                
                            
        </script>
	  
</head>

<body onload="JQFunctions()" style="font-family:'Impact', fantasy">
 <div class="oframe" id="oframe">
    <div id="headr">Othello Game
		<div id="resetGame" class="setCursor">Reset Game</div>
		<div id="frontPage" class="setCursor">Front Page</div>
	</div>
    <div id="status">
        <div id="formcontainer">
             <?php echo validation_errors(); ?>
                        <?php 
                                $attributes = array('id'=>'moveinputform');
                                echo form_open('othello/playbegin',$attributes); 
                        ?>
                <div id="xval" style="display:<?php echo $display1; ?>">
                    <label style="margin-left:5%">Enter X value of Move</label>
                    <input name="xvalue" type="text"  value="Enter X Value Here"  onclick="clearInput()" style="margin-left:5%"/>
                </div>
                <div id="yval"  style="display:<?php echo $display1; ?>">
                    <label style="margin-left:5%">Enter Y value of Move</label>
                    <input name="yvalue" type="text"  value="Enter Y Value Here"  onclick="clearInput()" style="margin-left:5%"/>
                </div>
				
				
                <div id="botcontainer">
                            <div id="message" ><?php echo $message; ?>
                            </div>
                            <div id="mask" style="display:<?php echo $display3; ?>">
                                    <div id="subbutton"   style="display:<?php echo $display1; ?>">
                                            <div id="cross">
                                            <input type="submit" class="setCursor" name="submit"  style="width:225px;font-size:1.2em" value="Submit This Move" />
                                            </div>
                                            <input type="hidden" class="setCursor" name="hid" value="<?php echo $flag; ?>"/>
											
										
                                    </div>
                                    <div id="playbutton" style="display:<?php echo $display2; ?>" >
                                            <input type="submit" class="setCursor"  name="submit" style="width:225px;font-size:1.2em" value="Press to Play" />
                                          
                                    </div>
                            </div>
                            <div id="nextbutton" style="display:<?php echo $display4; ?>" >
                                    <input type="submit" class="setCursor"  name="submit"  style="width:225px;font-size:1.2em"  value="Press to Continue" />
                            </div>
                </div>
				<input type="hidden" name="itemchoice" value='none'/>
				
            </form>
				<div id="formcontainer2">
				<?php echo validation_errors(); ?>
				<?php 
						$attributes = array('id'=>'itemform');
						echo form_open('othello/index2',$attributes); 
				?>
						  <input type="hidden" name="itemchoice" value='none'/>
            </form>
       
</div>
			
        </div>
    </div>