<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!DOCTYPE html>

<html>
    <head>
	   <meta charset="UTF-8">
       <meta http-equiv="content-type" content="text/html;charset=UTF-8">
		<!--  the following two lines load the jQuery library and JavaScript files -->
		<!--<script src="<?php echo $jqueryloc; ?>" type="text/javascript"></script> -->
		<!-- <script src="<?php echo $jqfile; ?>" type="text/javascript"></script> -->
		<!-- include JQuery and JQuery UI -->
		<!-- <script src="//code.jquery.com/jquery-1.10.2.js"></script> -->
		<!-- <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script> -->
		<link href = "<?php echo $headerCSS; ?>" rel="stylesheet" type="text/css" />
		<link href = "<?php echo $footerCSS; ?>" rel="stylesheet" type="text/css" />
		<!-- Custom ThemeRoller files -- excite bike  -->
		<link href="http://67.23.226.231/~rlsworks/ci/css/excite-bike/jquery-ui-1.10.4.custom.css" rel="stylesheet">
		<script src="http://67.23.226.231/~rlsworks/ci/js/jquery-1.10.2.js"></script>
		<script src="http://67.23.226.231/~rlsworks/ci/js/jquery-ui-1.10.4.custom.js"></script>
		
		<?php $page = $whichPage; ?>
		
		<?php if($page == "livingInLV"){ ?>
			<link href = "<?php echo $livingInLVCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Living in Vegas</title>
		<?php } ?>
		<?php if($page == "front"){?>
			<link href = "<?php echo $frontCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Portfolio Front</title>
		<?php } ?>	
		<?php if($page == "miniMotif"){?>
			<link href = "<?php echo $miniMotifCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Input Form for Minimotif Search</title>
		<?php } ?>		
		<?php if($page == "newOrominer"){?>
			<link href = "<?php echo $newOrominerCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Orominer Program</title>
		<?php } ?>	
		<?php if($page == "orominerHisto"){?>
			<link href = "<?php echo $orominerHistoCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Orominer with Histology</title>	
		<?php } ?>
		<?php if($page == "othello"){?>
			<link href = "<?php echo $othelloCSS; ?>" rel="stylesheet" type="text/css" />
			<link href = "<?php echo $css; ?>" rel="stylesheet" type="text/css" />
			<title>Othello Game</title>	
		<?php } ?>
		<?php if($page == "techWriter"){?>
			<link href = "<?php echo $techWriterCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Technical Writing</title>	
		<?php } ?>
		<?php if($page == "resumes"){?>
			<link href = "<?php echo $resumesCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Resume Viewing</title>	
		<?php } ?>
		<?php if($page == "whitePaper"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>White Paper</title>	
		<?php } ?>
		<?php if($page == "engSpec"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Engineering Specification</title>	
		<?php } ?>
		<?php if($page == "GraingerABCDE"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Grainger ABCDE Series B</title>	
		<?php } ?>
		<?php if($page == "GraingerCDE"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Grainger CDE</title>	
		<?php } ?>
		<?php if($page == "mecProductManual"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>MEC Product Manual VT 1.6</title>	
		<?php } ?>
		<?php if($page == "codeDev"){?>
			<link href = "<?php echo $codeDevCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Code Development Specification</title>	
		<?php } ?>
			<?php if($page == "emailForm"){?>
			<link href = "<?php echo $emailFormCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Making Contact</title>	
		<?php } ?>
			<?php if($page == "webTech"){?>
			<link href = "<?php echo $webTechCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Web Page Technologies Used</title>	
		<?php } ?>
			<?php if($page == "viewPDFResume"){?>
			<link href = "<?php echo $showPDFCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Show PDF Resume</title>	
		<?php } ?>
			<?php if($hfSwitch == "on"){?>
			<link href = "<?php echo $mobileSwitchCSS; ?>" rel="stylesheet" type="text/css" />
			<title>Mobile Portfolio</title>
		<?php } ?>
		
		<style>	
		   #pGraphic {
					position:relative;
					height:18em;
					width:100%;
					padding:2em 0em 2em 20%;
					background-color: #F0F0F0;
			}
			#positDiv{
					position:relative;
					height:100%;
					width:55%;
					zoom:100%;
			}
			#positDiv img{
					position:relative;
					width:100%;
					float:left;
			}
				
			#positDiv h2 {
					position:relative;
					width:100%;
					float:left;
					text-align:center;
					font-size:1.7em;
					margin-bottom:0.5em;
					}
					
			.bCon{
			       position:relative;
				   display:inline;
				   float:left;
				   height:8em;
				   width:11em;
				   padding:0.25em;
				   margin:0.5em;
				   }
			#hmenuContainer .ui-widget {width:10em}
			#hmenuContainer {font-size:0.95em}
			
			.descHdr {margin-bottom:0.5em;color:#780000;font-style:italic}
			.aUl, .aLi {
						position:relative;
						float:left;
						width:105%;
                                                font-size:1.0em;
						}
		</style>
		
		<script type="text/javascript">
		
		$(document).ready(function()
			{
					$('.bCon .aUl').css('display','none'); 					
					$('.bCon .aUl .aLi .aUl').css('display','none'); 
					
                   // Browser Capatability for background images
				   var  httpAgent = <?php echo json_encode($_SERVER['HTTP_USER_AGENT']); ?>;
				   var chrome = httpAgent.search("Chrome");
				   var firefox = httpAgent.search("Firefox");
				   
				  if((chrome < 0))  // For Other than Google Chrome
						{
								$('#outframebg').css('height','101.5%');
						
						}
				  if((chrome < 0) && (firefox < 0)) // Exclusively For Internet Explorer
						{
								$('#outframebg').css('height','101.5%');
						
						}
				  if(firefox >= 0)  // For Firefox
						{
							    $('#footContainer').css('font-size','1.5em');
						
						}
			
					
			
			});
		
			function JQFunctions2()
				{   
				        // Remove headers and other adjustments for mobile app
						var hfSwitch = '<?php echo $hfSwitch; ?>';
						var mhImages = new Array();
						  mhImages[0] = '<?php echo $mhImage2; ?>';
						  mhImages[1] = '<?php echo $mhImage3; ?>';
						  mhImages[2] = '<?php echo $mhImage5; ?>';
						  mhImages[3] = '<?php echo $mhImage6; ?>';
						  mhImages[4] = '<?php echo $mhImage7; ?>';
						  mhImages[5] = '<?php echo $mhImage8; ?>';
						//alert(hfSwitch);
						if(hfSwitch == 'on')
							{
								$('#headbar').css('opacity','0.0').css('zoom','1%').css('display','none');
								$('#footContainer').css('opacity','0.0').css('zoom','1%').css('display','none');
								$('.sys_id2').css('font-size','1em');
								//$('#llvOutFrame').add('#outDiv').add('#resumeContainer').css('border','none').css('background','none').css('zoom','85%');
								//$('#llvOutFrame').css('top','-28%').css('left','0em');
								//$('#resumeContainer').css('top','-30em')
								//$('#outframe').css('zoom','45%').css('top','-45em').css('left','-1%');
								//$('#oframe').css('left','-12%').css('top','-35em');
								//$('#otrframe').css('zoom','65%').css('top','-60em').css('left','0%');
								//$('#mobX').css('margin','0em 1em');
								//$('#mmContainer').css('zoom','70%').css('top','-25%').css('left','0%');
								//$('#am1,#am2').css('width','15em').css('margin-bottom','4em');
								//$('#qu').css('margin-bottom','4em');
								//$('#motifsel').css('height','35em');
								//$('#loaderMessage').css('left','-25em');
								$('#llvOutFrame').add('#mmContainer').css('zoom','75%');
								
								$('body').prepend('<div id="pGraphic"><div id="positDiv"><h2>RLS Career Porfolio</h2><img src="<?php echo $mhImage3;?>"/></div></div>');
								
							}
						else if(hfSwitch == 'off')
							{
								$('#headbar').css('opacity','1.0');
								$('#footContainer').css('opacity','1.0');
								
							}
							
						
						   
							var i = 0;
							var mhImg = '';
							setInterval(function(){
									mhImg = mhImages[i];
									$('#pGraphic #positDiv').html('');	
									$('#pGraphic #positDiv').append('<h2>RLS Career Porfolio</h2><img src="'+mhImg+'"/>').fadeIn(1000);	
									i++;
									if(i>(mhImages.length-1)) i = 0;	
								},3000);	
									
		
						
								$('div#softwareDevWork,div#technicalWritingWork,div#engineeringWork,div#contacts,div#techManuals').mouseenter(
									function()
										{
										
										 // find top-level menu children
										  var len = 0;
										  len = $(this).find('.lev3, .lev4').length;
										  if(len > 0)// change arrow icon if children
											{
												$(this).children('.lev1 >.ui-icon')
													.removeClass('ui-icon-triangle-1-s')
													.addClass('ui-icon-triangle-1-e');
												
											
												$(this).mouseleave(function()
													{
														$(this).children('.lev1 >.ui-icon')
															.removeClass('ui-icon-triangle-1-e')
															.addClass('ui-icon-triangle-1-s');
														
													});
													
												$(this).children('.lev3 >.ui-icon')
													.removeClass('ui-icon-triangle-1-s')
													.addClass('ui-icon-triangle-1-e');
											
												$(this).mouseleave(function()
													{
														$(this).children('.lev3 >.ui-icon')
															.removeClass('ui-icon-triangle-1-e')
															.addClass('ui-icon-triangle-1-s');
													});
											}
									
										});
										
										
								$('#btn1 button').button({
									icons: {
												primary: 'ui-icon-home'
										   }
									 });
									 
								$('#btn2 button,#btn3 button,#btn4 button,#btn5 button,#btn6 button').button({
									icons: {
												primary: 'ui-icon-locked'
										   }
									 });
								
							
							
							/*	$('#sdLi3').click(function()
										{
										
											alert("gets here");
										
										});  */
							
							
								
								$('button').on('mouseenter',function()
									{
										var $thisButton = $(this);
										$thisButton.css('border-style','none')
										           .parent()
											       .siblings()
												   .find('.aUl').css('display','none');
										$thisButton.parent()
													.siblings()	
												    .find('span.ui-icon-unlocked')
													   .removeClass('ui-icon-unlocked')
													   .addClass('ui-icon-locked');
										$thisButton.siblings('.aUl:first')
												   .css('border','none')
												   .css('display','block')
										           .each(function(){
														var $thisUl1 = $(this);
														$thisUl1.css('display','block')
															.fadeIn(1000)
															.css('opacity','1.0')
															.find('.aLi')
															.each(function()
																{
																var $thisLi = $(this);
																$thisLi
																//.css('color','white')
																.on('mouseenter',function()
																	{
																		$(this).find('.aUl').css('display','block').css('color','white'); 
																		$(this).addClass('ui-state-active')
																			   .css('color','blue'); 
																			   
																		
																		$(this).filter(function() {
																					  return $(this).text() == 'Human Organ System Analyzer 1';
																					})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Human Organ System Analyzer 1</p><p>The Orominer program shows a hierarchical organization of the human body constitution.'+
												' Its top level is Organ Systems.  It uses JavaScript, JQuery for dynamic resizing of text during zooming and event synchronization between hierarchical display and graphic display.  DOM HTML elements ' +
												'are used to dynamically generate SVG graphical elements.  MySQL Database information is converted into XML format using PHP for up front access by the code for generation of Hierachical Display.  Unfortunately ONLY THE First 3 NODES Of DATA was developed at Project Completion.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						
																						$(this).css('color','yellow');
																						$("#itemform input[name='itemchoice']").val('orominer');
																						$("#itemform input[name='itemchoice2']").val('none');
																						$('#itemform').submit();
																					});  
							
																		$(this).filter(function() {
																				  return $(this).text() == 'Human Organ System Analyzer 2';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Human Organ System Analyzer 2</p><p>This orominer program contains Histological Data within the Hierarchical Organization of Human Body makeup.  Histological Data is information about' +
																						      ' Human Organs and their tissues and cells</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						$("#itemform input[name='itemchoice']").val('oroHist');
																						$("#itemform input[name='itemchoice2']").val('none');
																						$('#itemform').submit();
																					});	
																		

                                                                        $(this).filter(function() {
																				  return $(this).text() == 'Vegas Caribbean Catering - in Development';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Vegas Caribbean Catering - in Development</p><p>A Simple WordPress skeleton site for a friends\' Catering business.' +
																						' The Woo Commerce Plug-in could be used for online ordering and payment transactions, but the client wants it kept simple.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						var url = "http://rlsworks.com/wordpress/vcc";    
																						$(location).attr('href',url);
																					});	

																					
																		$(this).filter(function() {
																				  return $(this).text() == 'Caribbean Food Store - in Development';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Caribbean Food Store - in Development</p><p>A WordPress site for a friends Caribbean Food Catering' +
																						' The Woo Commerce Plug-in is utilized ordering and payment transactions.  This site is in development.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						var url = "http://rlsworks.com/cfs/wordpress";    
																						$(location).attr('href',url);
																					});				

										                                 $(this).filter(function() {
																				  return $(this).text() == 'Code Repository';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Code Repository</p><p>Link to Repository of Code I have written.  The \'ci_XXXXX.zip\' file is the code' +
																						' for this site done within the CodeIgniter MVC Framework.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						var url = "https://www.asuswebstorage.com/navigate/s/BA74CC5EF08D4B6796CF5774272284324";    
																						$(location).attr('href',url);
																					});	 											
																					
																			

																		$(this).filter(function() {
																				  return $(this).text() == 'WordPress Work Portfolio';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">WordPress Work Portfolio</p><p>Link to a WordPress version of My work portfolio</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						var url = "http://rlsworks.wordpress.com/";    
																						$(location).attr('href',url);
																					});	 		
																			
																					
																		
																		$(this).filter(function() {
																				  return $(this).text() == 'Play Othello Game';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Play Othello Game</p><p>This is an adaptation of the Classic Othello game where one player competes with the Computer.'+
											'Two Player Play could be implemented, as well as, making levels of difficulty for game play.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						$("#itemform input[name='itemchoice']").val('othello');
																						$("#itemform input[name='itemchoice2']").val('none');
																						$('#itemform').submit();
																					});		
																			
																		$(this).filter(function() {
																				  return $(this).text() == 'Amino Acid Code Sequence Analyzer';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Amino Acid Code Sequence Analyzer</p><p>This program gives statistics for all combinations of amino acid sequences within a protein.  The protein sequence is parsed by regex techniques from a text file, into a MySQL database.'+
											'The first and last amino acid is chosen in the GUI, as well as, the desired statistical output.  The database accessed from JavaScript AJAX to PHP on the server side which returns the statistics.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						$("#itemform input[name='itemchoice']").val('miniMotif');
																						$("#itemform input[name='itemchoice2']").val('none');
																						$('#itemform').submit();
																					});		
																		

																		$(this).filter(function() {
																				  return $(this).text() == 'Code Development Specification';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Code Development Specification</p><p>This is a technical specification for' + 
																				' guidance in developing Object Oriented Code.  It was written as a HTML document.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						$("#itemform input[name='itemchoice']").val('codetech');
																						$("#itemform input[name='itemchoice2']").val('none');
																						$('#itemform').submit();
																					});		
																					
																		$(this).filter(function() {
																				  return $(this).text() == 'Web Page Technologies Used';
																				})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						$("#itemform input[name='itemchoice']").val('webTech');
																						$("#itemform input[name='itemchoice2']").val('none');
																						$('#itemform').submit();
																					});	
																					
																					
																					
																					
																		$(this).filter(function() {
																				  return $(this).text() == 'Dynamic HTML Resume w/Downloads';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Dynamic HTML Resume w/Downloads</p><p>Resume for Richard L. Sypert Jr. in Html and PDF formats.  The HTML Resume Format Only Uses CSS and no JavaScript!</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						$("#itemform input[name='itemchoice']").val('resume');
																						$("#itemform input[name='itemchoice2']").val('none');
																						$('#itemform').submit();
																					});	

																					
																		$(this).filter(function() {
																				  return $(this).text() == 'Having Vegas Family Fun';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Having Vegas Family Fun</p><p>Living in Las Vegas has been a Discovery.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');
																						$("#itemform input[name='itemchoice']").val('livingInVegas');
																						$("#itemform input[name='itemchoice2']").val('none');
																						$('#itemform').submit();
																					});				
																		
																		$(this).filter(function() {
																				  return $(this).text() == 'White Paper';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">White Paper</p><p>This is a revision of the White Paper for the ' +
								           ' Motor Efficiency Controller (MEC).  It contained a fuller explanation of the electrical induction of power and torque' + 
										   ' in an electrical motor.  It was written in Microsoft Word.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						$(this).css('color','yellow');	
																						$("#itemform input[name='itemchoice']").val('whitePaper');
																						$("#itemform input[name='itemchoice2']").val('none');
																						$('#itemform').submit();
																					
																					});				
																		
																		$(this).filter(function() {
																				  return $(this).text() == 'Engineering Specification';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Engineering Specification</p><p>This is technical specification of the' + 
								           ' requirements of approval and methodology of granting approval for land improvement in Clark County, as it pertains to water' + 
										   ' and sewer utility construction.  It was written in Microsoft Word.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						 $(this).css('color','yellow');	
																						 $("#itemform input[name='itemchoice']").val('engSpec');
																						 $("#itemform input[name='itemchoice2']").val('none');
																						 $('#itemform').submit();
																					});			
																		
																		$(this).filter(function() {
																				  return $(this).text() == 'Making Contact';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Making Contact</p><p>Email me if you like.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						 $(this).css('color','yellow');	
																						 $("#itemform input[name='itemchoice']").val('email1');
																						 $("#itemform input[name='itemchoice2']").val('none');
																						 $('#itemform').submit();
																					});	
																		 $(this).filter(function() {
																				  return $(this).text() == 'Web Page Technologies Used';
																				})
																				.on('mouseover mouseenter mousemove',function()
																					{
																						$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Web Page Technologies Used</p><p>This Page explains' +
																						' the web technologies used to program this site.</p>');
																					
																					})
																				.on('mouseleave',function()
																					{
																						$('#menuDescription').css('display','none').html('');
																					
																					})
																				.on('mousedown',function()
																					{
																						 $(this).css('color','yellow');	
																						 $("#itemform input[name='itemchoice']").val('webTech');
																						 $("#itemform input[name='itemchoice2']").val('none');
																						 $('#itemform').submit();
																					});			
																					
																		/* .filter(function() {
																		  return $(this).text() == 'Some text';
																		});  */
																		
																
																		
																	})
																.on('mouseleave',function()
																	 {
																		$(this).find('ul').css('display','none');
																		$(this).removeClass('ui-state-active');
																		//$(this).css('color','yellow');	
																			$(this).parent().find('.aLi:nth-child(even)').css('color','white');
																			$(this).parent().find('.aLi:nth-child(odd)').css('color','orange');
																   
																	 })
																})		// end of each $thisLi			
																.find('.aUl')
																.each(function()
																		{
																		  var $thisUl2 = $(this);
																		  $thisUl2.on('mouseenter',function()
																				    {
																						$(this).addClass('ui-state-active')
																					   .css('color','blue')
																					   .css('display','block'); 
																					   
																					   //$(this).filter(function() {
																					//	  return $(this).text() == 'ABCDE';
																						//})
																					   $(this,':contains("ABCDE")')
																					    .on('mouseover mouseenter mousemove',function()
																							{
																								$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Grainger ABCDE Series B</p><p>This is a Maintenance and Product Information Manual tailored for a customers implementation of a ' +
								           ' Motor Efficiency Controller (MEC).  It is a new generation product manual.  I wrote it in Adobe InDesign according to the customer\'s style rules</p>');
																							
																							})
																						.on('mouseleave',function()
																							{
																								$('#menuDescription').css('display','none').html('');
																							
																							})
																						.on('mousedown',function()
																							{   
																								$(this).css('color','yellow');	
																								$("#itemform input[name='itemchoice2']").val('GraingerABCDE');
																								$("#itemform input[name='itemchoice']").val('none');
																								$('#itemform').submit();
																							});
																							
																						$(this).filter(function() {
																								return $(this).text() == 'Grainger CDE';
																						})
																						.on('mouseover mouseenter mousemove',function()
																							{
																								$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Grainger CDE</p><p>This is a Maintenance and Product Information Manual tailored for a customers implementation of a ' +
								           ' Motor Efficiency Controller (MEC).  It is a new generation product manual.  I wrote it in Adobe InDesign according to the customer\'s style rules</p>');
																							
																							})
																						.on('mouseleave',function()
																							{
																								$('#menuDescription').css('display','none').html('');
																							
																							})
																						.on('mousedown',function()
																							{
																								$(this).css('color','yellow');	
																								$("#itemform input[name='itemchoice2']").val('GraingerCDE');
																								$("#itemform input[name='itemchoice']").val('none');
																								$('#itemform').submit();
																							});	
																							
																						$(this).filter(function() {
																						  return $(this).text() == 'MEC Product Manual VT 1.6';
																						})
																						.on('mouseover mouseenter mousemove',function()
																							{
																								$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">MEC Product Manual VT 1.6</p><p>This is a Product Manual for a ' +
								           ' Motor Efficiency Controller (MEC).  It is a new generation product manual.  I wrote it in Adobe InDesign according to the customer\'s style rules</p>');
																							
																							})
																						.on('mouseleave',function()
																							{
																								$('#menuDescription').css('display','none').html('');
																							
																							})
																						.on('mousedown',function()
																							{
																								$(this).css('color','yellow');	
																								$("#itemform input[name='itemchoice2']").val('mecProductManual');
																								$("#itemform input[name='itemchoice']").val('none');
																								$('#itemform').submit();
																							});	
																								
																							
																				  })	
																		        .on('mouseleave',function()
																				     {
																				 	  
																						$(this).removeClass('ui-state-active')
																							.css('color','white'); 
																				
																			    	  });
																		});  //end of find each $thisUl2
													});  // end of find each thisUl1					
																		
																		
													
														
										$('button .aUl .aLi .aUl').css('display','none'); 
										// button state, color and list color
										$thisButton.addClass('ui-state-active')
											       .addClass('ui-state-focus')
											       .css('color','blue')
											       .find('.aUl')
												   .each(function()
														{
															$(this).css('color','white');
														});
											   
										
										var x = 0
										$thisButton.click(function(e)
										{
										
											
										
											if(x == 1)
												{
													$(this)
													   .find('span.ui-icon-locked')
													   .removeClass('ui-icon-locked')
													   .addClass('ui-icon-unlocked'); 
													$(this)
														.find('.aUl')
														.each(function()
															{
																$(this).css('display','block')
																$(this).css('color','white')
																$(this).fadeIn(1000).css('opacity','1.0');
															});
											
											
													$('button .aUl .aLi .aUl').css('display','none'); 
													$(this).addClass('ui-state-active')
														   .addClass('ui-state-focus');
													x = 0;
												}else{
													$(this).find('.aUl')
													       .each(function()
																{
																   $(this).css('display','none').fadeOut(2000)
																   $(this).css('opacity','0.0');
																});
													$(this).removeClass('ui-state-active')
														   .removeClass('ui-state-focus')
														   .find('span.ui-icon-unlocked')
															   .removeClass('ui-icon-unlocked')
															   .addClass('ui-icon-locked');
															   
													x = 1;
													}
													e.preventDefault();
										});
										
										
											   
										//unlock icon on mouse enter	   
										$thisButton.find('span.ui-icon-locked')
										           .removeClass('ui-icon-locked')
											       .addClass('ui-icon-unlocked');
											
										
									
									});   // end of each $thisButton
								$('button').mouseleave(function()
									{
										$(this).css('color','white')
										       .css('border','2px solid white');
											   
											   
									
									});
									
								$('button:contains("Home")')
								        .on('mousedown',function()
												{
													$(this).css('color','yellow');
														
													$("#itemform input[name='itemchoice']").val('frontPage');
													$("#itemform input[name='itemchoice2']").val('none');
													$('#itemform').submit();
												})
										.on('mouseover mouseenter mousemove',function()
															{
																$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Home</p><p>Return to the Front Page, which is a GUI of its own that enables navigation of this site.' +
																   '  If you are using Google, check-out the 3-D File Cabinet below as it also allows site navigation</p>');
															
															})
										.on('mouseleave',function()
											{
												$('#menuDescription').css('display','none').html('');
											
											});
								
									

								$('button:contains("About")')
								        .on('mousedown',function()
												{
													$(this).css('color','yellow');
														
													$("#itemform input[name='itemchoice']").val('frontPage');
													$("#itemform input[name='itemchoice2']").val('none');
													$('#itemform').submit();
												})
										.on('mouseover mouseenter mousemove',function()
															{
																$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">About</p><p>Choose links below to find out about the technologies used to program this site, or to' +
																' Send the author of this site \(Me\) an email.</p>');
															
															})
										.on('mouseleave',function()
											{
												$('#menuDescription').css('display','none').html('');
											
											});
											
											
											
								$('button:contains("Software Development")')
								        .on('mousedown',function()
												{
													$(this).css('color','yellow');
														
													$("#itemform input[name='itemchoice']").val('frontPage');
													$("#itemform input[name='itemchoice2']").val('none');
													$('#itemform').submit();
												})
										.on('mouseover mouseenter mousemove',function()
															{
																$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Software Development</p><p>See links below for software applications I have programmed.' +
																' The list also include a link to a Code Repository including code for this site \(ci_xxxx.zip\) which utilizes the CodeIgniter MVC Framework.&nbsp;&nbsp; Also a WordPress portfolio link is included.</p>');
															
															})
										.on('mouseleave',function()
											{
												$('#menuDescription').css('display','none').html('');
											
											});
											
											
											
								$('button:contains("Technical Writing")')
								        .on('mousedown',function()
												{
													$(this).css('color','yellow');
														
													$("#itemform input[name='itemchoice']").val('frontPage');
													$("#itemform input[name='itemchoice2']").val('none');
													$('#itemform').submit();
												})
										.on('mouseover mouseenter mousemove',function()
															{
																$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Technical Writing</p><p>I am also a Technical Writer and the list below includes' +
																' documents I have written using Microsoft Word, Adobe InDesign, as well as,  OpenOffice Writer and Illustrator programs.</p>');
															
															})
										.on('mouseleave',function()
											{
												$('#menuDescription').css('display','none').html('');
											
											});
											
											
											
									$('button:contains("My Resume")')
								        .on('mousedown',function()
												{
													$(this).css('color','yellow');
														
													$("#itemform input[name='itemchoice']").val('frontPage');
													$("#itemform input[name='itemchoice2']").val('none');
													$('#itemform').submit();
												})
										.on('mouseover mouseenter mousemove',function()
															{
																$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">My Resume</p><p>A link to my Resume is below.</p>');
															
															})
										.on('mouseleave',function()
											{
												$('#menuDescription').css('display','none').html('');
											
											});
											
											
									$('button:contains("Living In Vegas")')
								        .on('mousedown',function()
												{
													$(this).css('color','yellow');
														
													$("#itemform input[name='itemchoice']").val('frontPage');
													$("#itemform input[name='itemchoice2']").val('none');
													$('#itemform').submit();
												})
										.on('mouseover mouseenter mousemove',function()
															{
																$('#menuDescription').css('display','block').css('font-size','1.0em').html('<p class="descHdr">Living In Vegas</p><p>A link about Las Vegas is below</p>');
															
															})
										.on('mouseleave',function()
											{
												$('#menuDescription').css('display','none').html('');
											
											});
									
				  //Dynamically Adjust header Font Sizes
				/*	var hmHeight = $('#hmenuContainer').height();
					var fSize = 0.032*hmHeight;
					$('#hmenuContainer').css('font-size',fSize+'px');	*/
		
				}
	</script>
	</head>
	<body onload="{JQFunctions();JQFunctions2();}">

	<div id="headbar" class="ui-widget ui-state-default">
		<div id="hmenuContainer">
			<div id="btn1" class="bCon">
				<button>Home</button>
			</div>
			<div id="btn2" class="bCon"> 
				<button>About&nbsp;&nbsp;&nbsp;&nbsp;</button>
				<div id="abUl1" class="aUl">
						<div id="abLi1" class="aLi">Web Page Technologies Used</div>
						<div id="abLi2" class="aLi" >Making Contact</div>
				</div>
			</div>
			<div id="btn3" class="bCon">
				<button name='softDev'>Software Development</button>
				<div id="sdUl1" class="aUl">
					<div id="sdLi1" class="aLi">Amino Acid Code Sequence Analyzer</div>
					<div id="sdLi2" class="aLi">Play Othello Game</div>
					<div id="sdLi3" class="aLi">Human Organ System Analyzer 1</div>
					<div id="sdLi4" class="aLi">Human Organ System Analyzer 2</div>
					<div id="sdLi5" class="aLi">Vegas Caribbean Catering - in Development</div>
					<div id="sdLi6" class="aLi">Caribbean Food Store - in Development</div>
					<div id="sdLi7" class="aLi">Code Repository</div>
					<div id="sdLi8" class="aLi">WordPress Work Portfolio</div>
				</div>
			</div>
			<div id="btn4" class="bCon">
				<button>Technical Writing</button>
				<div id="twUl1" class="aUl">
						<div id="twLi1" class="aLi">Product and Maintenance Manuals
							<div id="twUl2" class="aUl">Grainger ABCDE Series B</div>
							<div id="twUl3" class="aUl">Grainger CDE</div>
							<div id="twUl1" class="aUl">MEC Product Manual VT 1.6</div>
						</div>
						<div id="twLi2" class="aLi">White Paper</div>
						<div id="twLi3" class="aLi">Engineering Specification</div>
						<div id="twLi4" class="aLi">Code Development Specification</div>
				</div>
			</div>
			<div id="btn5" class="bCon">
				<button>My Resume</button>
				<div id="mrUl1" class="aUl">
						<div id="mrLi1" class="aLi">Dynamic HTML Resume w/Downloads</div>
				</div>
			</div>
			<div id="btn6" class="bCon">
				<button>Living In Vegas</button>
				<div id="lvUl1" class="aUl">
						<div id="lvLi1" class="aLi">Having Vegas Family Fun</div>
				</div>
			</div>
			
		</div>
		<br/><div id="menuDescription"></div>
	</div>
	
