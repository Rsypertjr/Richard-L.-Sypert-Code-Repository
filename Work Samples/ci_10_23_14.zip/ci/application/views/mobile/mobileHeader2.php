<!DOCTYPE html>
<html>
<head>
	<title>RLS Career Portfolio</title>

	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link href = "<?php echo $mobileCSS; ?>" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.3/jquery.mobile-1.4.3.min.css" />
	<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.4.3/jquery.mobile-1.4.3.min.js"></script>
</head>
<body>