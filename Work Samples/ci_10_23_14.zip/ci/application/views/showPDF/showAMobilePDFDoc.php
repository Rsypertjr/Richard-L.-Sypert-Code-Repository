<script type="text/javascript">

//JavaScript in Body 
//http://docs.google.com/gview?embedded=true&url=   

function JQFunctions()
	{;}
</script>



<div id="showPDFDiv">
	<object data="http://www.rlsworks.com/ci/pdf/<?php echo $pdfFileName;?>" type="application/pdf" width="100%" height="70%">
		alt : <a href="http://www.rlsworks.com/ci/pdf/<?php echo $pdfFileName;?>"><?php echo $pdfFileName;?></a>
	</object>
</div>