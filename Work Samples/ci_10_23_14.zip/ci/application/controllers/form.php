<?php
class Form extends CI_Controller {
	function index()
	{
		$this->load->helper(array('form','url'));
		
		$this->load->library('form_validation');
		
		// Setting rules basically
		//$this->form_validation->set_rules('username','Username','required');
		//$this->form_validation->set_rules('password','Password','required');
		//$this->form_validation->set_rules('passconf','Password Confirmation','required');
		//$this->form_validation->set_rules('email','Email','required');
		
		// Setting rules using array
		/*
		$config = array(
						array(
							'field' => 'username',
							'label' => 'Username',
							'rules' => 'required'
							),
						array(
							'field' => 'password',
							'label' => 'Password',
							'rules' => 'required'
							),
						array(
							'field' => 'passconf',
							'label' => 'Password Confirmation',
							'rules' => 'required'
							),
						array(
							'field' => 'email',
							'label' => 'Email',
							'rules' => 'required'
							)
						);
						*/
						
						
		
		// Setting rules using Piping
		//$this->form_validation->set_rules('username','Username','required|min_length[5]|max_length[12]|is_unique(users.username)');
		//$this->form_validation->set_rules('password','Password','required|matches[passconf]');
		//$this->form_validation->set_rules('passconf','Password Confirmation','trim|required');
		//$this->form_validation->set_rules('email','Email','trim|required|valid_email');
		
		// Prepping Data
		
	//	$this->form_validation->set_rules('username','Username','trim|required|min_length[5]|max_length[12]|xss_clean');
	//	$this->form_validation->set_rules('password','Password','trim|required|matches[passconf]|md5');
	//	$this->form_validation->set_rules('passconf','Password Confirmation','required');
	//	$this->form_validation->set_rules('email','Email','required|valid_email|is_unique(users.email)');
		
		
		// Callbacks to Validation Functions
		//$this->form_validation->set_rules('username','Username','callback_username_check');
						
		//$this->form_validation->set_rules($config);
		
		if($this->form_validation->run('signup') == FALSE)  // Using 'signup' array for Rule Group in form_validation.php 
		{
			$this->load->view('myform');
		}
		else
		{
			$this->load->view('formsuccess');
		}
		
		
	}
	
	public function username_check($str)
		{
			if($str == 'test')
				{
					$this->form_validation->set_message('username_check','The %s field can not be the word "test"');
					return FALSE;
				}
			else
				{
					return TRUE;
				}
		}
		
		
	
	
	
	
	
	
}
?>