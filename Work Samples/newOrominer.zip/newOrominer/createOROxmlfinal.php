<html>
<head>
<title>Create Orominer XML File</title>
</head>
<body>
<?php
// This file generates the oro_xml4 XML file which the orominer_contact_final file utilizes as a Database.   It uses php MySQL queries to create 
// XML file from databases.  Note:  Dashes need to be replaced with underscores in database table names.
 
// -------------------------------------------------------------------------------------------------------

function connectToMySQL($server,$user,$pssword,&$message)
{
   $isConnected ="Connection Made";
   if($conn = mysql_connect($server,$user,$pssword))
     {
       $message = $isConnected;
       return $conn;
     }

   else
    {
    $message ='Could not connect: ' . mysql_error();
    return NULL;
    }
}

function executeSQL($sql,$conn,&$message)
{
//execute SQL
$querySucceeded = "Query succeeded";

if($result = mysql_query($sql,$conn))
   {
   $message = $querySucceeded;
   return $result;
   }
else 
   {
   $message= "<br/>Query error: ". mysql_error();
   return NULL;
   }
}

//echo "gets here";
$conn=connectToMySQL("localhost","root","root",$mess);  //connect to MySQL
//echo $conn;
mysql_select_db("orominer");
 
$xml = new DOMDocument('1.0');
$xml->formatOutput = true;

$top = $xml->createElement('top');  // create root element
$top = $xml->appendChild($top);


// Select Organ Systems
$sql = 'SELECT DISTINCT organ_system_name, organ_system_uid  FROM enum_organ_system ORDER BY organ_system_name';
//echo "gets here";
$esql = executeSQL($sql,$conn,$mess);
//echo $esql;
$organsystemuid = array();
$organsystemname = array();
$osuidmax = array();


if(!esql)
	die($mess);
else
{
 while($newArray = mysql_fetch_array($esql))
   { 
   $organsystemuid[]=$newArray[organ_system_uid];
   $organsystemname[] = $newArray[organ_system_name];
   //$osuidmax[]= $newArray[osidmax];
  
	}
}


//  Loop thru Organ Systems in building XML File
echo sizeof($organsystemname);
for($i=0;$i < sizeof($organsystemuid);$i++)
	{
	      
		 $sys = $xml->createElement('System');
		 $in = (int)$i;
		 $sysname = $xml->createTextNode($organsystemname[$in]);
		 $sys->appendChild($sysname);
		
		 $top->appendChild($sys);
		 
		$osid = $organsystemuid[$i]; 
		$osname = $organsystemname[$i];
		$sys->setAttribute('id',$osname);
		$top->appendChild($sys);
		 // Selecting Organs for each particular Organ System
	     $sql = 'SELECT DISTINCT eo.organ_name AS eon, poo.organ_uid AS pooid '.
				' FROM part_of_organ_organ_system AS poo, enum_organ AS eo WHERE poo.organ_system_uid = "'.$osid.'"'.
				' AND (eo.organ_uid = poo.organ_uid ) ORDER BY eo.organ_name';    
		
		 $esql = executeSQL($sql,$conn,$mess);
		 
		 //echo $esql; 
		 
		 $organuid = array();
		 $organname = array();
		 
		 if(!$esql)
			die($mess);
		 else
		 {
		  //echo mysql_fetch_array($esql);
		  while($newArray = mysql_fetch_array($esql))
			{ 
			$organname[]=$newArray[eon];
			$organuid[]=$newArray[pooid];
			}
		 }
		 
		 
		 
		 
		 //echo sizeof($organuid)."\n";
		 // Loop through Organs
		for($j=0;$j<sizeof($organuid);$j++)
			{
			    //echo "gets in here";
			    //echo $organuid[$j]."\n";
				//echo "\n";
				$org = $xml->createElement("Organ");
				$organcontacts = $xml->createElement("OrganContacts");
				
				$orgtext = $xml->createTextNode($organname[$j]);
				$org->appendChild($orgtext);
				$org->appendChild($organcontacts);
				
				$sys->appendChild($org);
				
				$organid = $organuid[$j];
				$orgname = $organname[$j];
				$org->setAttribute('id',$osname.'_'.$orgname);
				$sys->appendChild($org);
				// Select Common Systems for Organs
				// -----------------------------------------------------------------------
				$sql = 'SELECT DISTINCT poos.organ_system AS poosn FROM part_of_organ_organ_system AS poos '.
				' WHERE poos.organ_uid = "'.$organid.'" AND poos.organ_system <> "'.$osname.'" ORDER BY poos.organ_system';
				
				$commonsystemname = array();
								
				$esql = executeSQL($sql,$conn,$mess);
				if(!$esql)
					die($mess);
				else
				 {
				  //echo mysql_fetch_array($esql);
				 
				  $text = "";
				  while($newArray = mysql_fetch_array($esql))
						{
						$commonsystemname[]=$newArray[poosn];
						}
				 }
				 //echo sizeof($commonsystemname);
				 
			    // Add Common System Element to Organ
				for($cs=0;$cs<sizeof(commonsystemname);$cs++)
					{
						$commonsystem = $xml->createElement("CommonSystem");
						$cstext = $xml->createTextNode($commonsystemname[$cs]);
						$commonsystem->appendChild($cstext);
						$org->appendChild($commonsystem);
						
					}	 // End of Common System

			
			   // Select Contact Organs for Organs
				$sql = 'SELECT DISTINCT eo.organ_name AS eon, coo.organ_b_uid AS cooid FROM enum_organ AS eo, contact_organ_organ AS coo '.
				' WHERE coo.organ_uid = "'.$organid.'" AND eo.organ_uid=coo.organ_b_uid ORDER BY eo.organ_name';
				
				$contactorganname = array();
				$contactorganuid = array();
				
				$esql = executeSQL($sql,$conn,$mess);
				if(!$esql)
					die($mess);
				else
				 {
				  //echo mysql_fetch_array($esql);
				 
				  $text = "";
				  while($newArray = mysql_fetch_array($esql))
						{
						$contactorganname[]=$newArray[eon];
						$contactorganuid[]=$newArray[cooid];
						}
				 }
				 //echo sizeof($contactorganname);
				 
			    // Add Contact Organ Element to Organ
				for($jj1=0;$jj1<sizeof($contactorganname);$jj1++)
					{
						$contactorgan = $xml->createElement("OrganContactOrgan");
						$cotext = $xml->createTextNode($contactorganname[$jj1]);
						$contactorgan->appendChild($cotext);
						$organcontacts->appendChild($contactorgan);
		
						//echo $contactorganname[0];
						$contactorganid = $contactorganuid[$jj1];
									
					}	 // End of Contact Organ 
	
	
				  // Select Tissues for Organs  
				  // ------------------------------------------------------
				  
				$sql = 'SELECT DISTINCT et.tissue_name AS etn, et.tissue_uid AS etid, et.source_sheet, eo.organ_uid FROM enum_tissue AS et, enum_organ AS eo '.
				' WHERE eo.organ_uid = "'.$organid.'" AND eo.organ_name=et.source_sheet ORDER BY et.tissue_name';
				
				$tissuename = array();
				$tissueuid = array();
				
				$esql = executeSQL($sql,$conn,$mess);
				if(!$esql)
					die($mess);
				else
				 {
				  //echo mysql_fetch_array($esql);
				 
				  $text = "";
				  while($newArray = mysql_fetch_array($esql))
						{
						$tissuename[]=$newArray[etn];
						$tissueuid[]=$newArray[etid];
						}
				 }
				 //echo sizeof($tissuename);
				 
				 // Add Tissue Element to Organ
				for($jj3=0;$jj3<sizeof($tissuename);$jj3++)
					{
						$tissue = $xml->createElement("Tissue");
						$tstext = $xml->createTextNode($tissuename[$jj3]);
						$tissue->appendChild($tstext);
						$tissue->setAttribute('id',$osname.'_'.$orgname.'_'.$tissuename[$jj3]);
						$org->appendChild($tissue);
						
						//echo $tissuename[0];
						$tissueid = $tissueuid[$jj3];
						//echo "--".$tissueid."--";	
					
						
						// Select Lumens for Tissue 	
						$sql = 'SELECT DISTINCT plt.lumen AS pltn, plt.tissue_uid AS plttid, plt.source_sheet FROM'.
						'  part_of_lumen_tissue AS plt'.
							' WHERE plt.tissue_uid="'.$tissueid.'" AND plt.source_sheet="'.$orgname.'" ORDER BY plt.lumen';
							
																	
						$esql = executeSQL($sql,$conn,$mess);
						$lumenname = array();
						$lumenuid = array();
					   
						
						if(!$esql)
								die($mess);
						else
							{
							  //echo mysql_fetch_array($esql);
							  while($newArray = mysql_fetch_array($esql))
								{ 
									//echo "gets here";
									$lumenname[]=$newArray[pltn];
									$lumenuid[]=$newArray[plttid];
								
								}
							}
														
						//echo sizeof($lumenname)."\n";
					
						//Add Lumens to Tissue
						for($jj4=0;$jj4<sizeof($contactorganpartname);$jj4++)
							{
							 $lumen = $xml->createElement("Lumen");
							 $lumentext = $xml->createTextNode($lumenname[$jj4]);
							 $lumen->appendChild($lumentext);
							 $tissue->appendChild($lumen);
							 $lumenid = $lumenuid[$jj4];	 
							 //echo $lumenid."\n";
							 
							 
								// Change to Select Connected Lumen
								// ------------------------------------------------------------------
								$sql = 'SELECT DISTINCT cll.lumen_b AS clln, cll.lumen_a_uid AS cllid, cll.source_sheet FROM'.
								'  connected_lumen_lumen AS cll'.
									' WHERE cll.lumen_a_uid="'.$lumenid.'" AND cll.source_sheet= "'.$orgname;
									
																			
								$esql = executeSQL($sql,$conn,$mess);
								$connectedlumenname = array();
								$connectedlumenuid = array();
							   
								
								if(!$esql)
										die($mess);
								else
									{
									  //echo mysql_fetch_array($esql);
									  while($newArray = mysql_fetch_array($esql))
										{ 
											//echo "gets here";
											$connectedlumenname[]=$newArray[clln];
											$connectedlumenuid[]=$newArray[cllid];
										
										}
									}
																
								//echo sizeof($connectedlumenname)."\n";
							
								//Add Connected Lumen element to Lumen
								for($jj5=0;$jj5<sizeof($connectedlumenname);$jj5++)
									{
									 $connectedlumen = $xml->createElement("LumenConnectedLumen");
									 $clumentext = $xml->createTextNode($connectedlumenname[$jj5]);
									 $connectedlumen->appendChild($clumentext);
									 $lumen->appendChild($connectedlumen);
									 $connectedlumenid = $connectedlumenuid[$jj5];	 
									 //echo $connectedlumenid."\n";
				
									}  // End of Connected Lumens to Lumens
					
							}
					
					
						// Add Matrix to Tissue  -- Table is empty
						// ------------------------------------------------------------------
						
						
						
						
						// Add Cell to Tissue
						$sql = 'SELECT DISTINCT pct.cell AS pctcn, pct.cell_uid AS pctcid, pct.tissue_uid, pct.source_sheet  FROM'.
						'  part_of_cell_tissue AS pct'.
							' WHERE pct.tissue_uid="'.$tissueid.'" AND pct.source_sheet= "'.$orgname.'" ORDER BY pct.cell';
							
																	
						$esql = executeSQL($sql,$conn,$mess);
						$cellname = array();
						$celluid = array();
					   
						
						if(!$esql)
								die($mess);
						else
							{
							  //echo mysql_fetch_array($esql);
							  while($newArray = mysql_fetch_array($esql))
								{ 
									//echo "gets here";
									$cellname[]=$newArray[pctcn];
									$celluid[]=$newArray[pctcid];
								
								}
							}
														
						//echo sizeof($cellname)."\n";
					
						//Loop to add Cells to Tissue
						for($jj8=0;$jj8<sizeof($cellname);$jj8++)
							{
							 $cell = $xml->createElement("Cell");
							 $celltext = $xml->createTextNode($cellname[$jj8]);
							 $cell->appendChild($celltext);
							 $tissue->appendChild($cell);
							 $cellid = $celluid[$jj8];	 
							 //echo $cellid."\n";
									 
						// Add Contact Cells to Cell
							$sql = 'SELECT DISTINCT ccc.cell_b AS cccbn, ccc.cell_a_uid AS cccaid, ccc.source_sheet FROM'.
							'  contact_cell_cell AS ccc'.
								' WHERE ccc.cell_a_uid="'.$cellid.'" AND ccc.source_sheet="'.$orgname.'" ORDER BY ccc.cell_b';
								
																		
							$esql = executeSQL($sql,$conn,$mess);
							$cellbname = array();
							
						   
							
							if(!$esql)
									die($mess);
							else
								{
								  //echo mysql_fetch_array($esql);
								  while($newArray = mysql_fetch_array($esql))
									{ 
										//echo "gets here";
										$cellbname[]=$newArray[cccbn];
										
									
									}
								}
															
							//echo sizeof($cellbname)."\n";
						
							//Loop to add Contact Cells to Cell
							for($jj10=0;$jj10<sizeof($cellbname);$jj10++)
								{
								 $contactcell = $xml->createElement("CellContactCell");
								 $ccelltext = $xml->createTextNode($cellbname[$jj10]);
								 $contactcell->appendChild($ccelltext);
								 $cell->appendChild($contactcell);
								} 
						 
						 
							 
							

							// Add Contact Lumens to Cell
							$sql = 'SELECT DISTINCT ccl.lumen AS ccln, ccl.cell_uid , ccl.source_sheet FROM'.
							'  contact_cell_lumen AS ccl'.
								' WHERE ccl.cell_uid="'.$cellid.'" AND ccl.source_sheet="'.$orgname.'" ORDER BY ccl.lumen';
								
																		
							$esql = executeSQL($sql,$conn,$mess);
							$contactlumenname2 = array();
							
						   
							
							if(!$esql)
									die($mess);
							else
								{
								  //echo mysql_fetch_array($esql);
								  while($newArray = mysql_fetch_array($esql))
									{ 
										//echo "gets here";
										$contactlumenname2[]=$newArray[ccln];
										
									
									}
								}
															
							//echo sizeof($contactlumenname2)."\n";
						
							//Loop to add Contact Lumens to Cell
							for($jj10=0;$jj10<sizeof($contactlumenname2);$jj10++)
								{
								 $contactlumen = $xml->createElement("CellContactLumen");
								 $cln2 = $contactlumenname2[$jj10];
								 $cltext = $xml->createTextNode($cln2);
								 $contactlumen->appendChild($cltext);
								 $cell->appendChild($contactlumen);
								} 
						 
						
							
							// Add Contact Matrix to Cell
							$sql = 'SELECT DISTINCT ccm.matrix AS ccmn, ccm.cell_uid, ccm.source_sheet FROM '.
							'  contact_cell_matrix AS ccm '.
								' WHERE ccm.cell_uid="'.$cellid.'" AND ccm.source_sheet = "'.$orgname.'" ORDER BY ccm.matrix';
								
																		
							$esql = executeSQL($sql,$conn,$mess);
							$contactmatrixname = array();
							
						   
							
							if(!$esql)
									die($mess);
							else
								{
								  //echo mysql_fetch_array($esql);
								  while($newArray = mysql_fetch_array($esql))
									{ 
										//echo "gets here";
										$contactmatrixname[]=$newArray[ccmn];
										
									
									}
								}
															
							//echo sizeof($cellmatrix)."\n";
						
							//Loop to add Contact Matrix to Cell
							for($jj11=0;$jj11<sizeof($contactmatrixname);$jj11++)
								{
								 $contactmatrix = $xml->createElement("CellContactMatrix");
								 $cmtext = $xml->createTextNode($contactmatrixname[$jj11]);
								 $contactmatrix->appendChild($cmtext);
								 $cell->appendChild($contactmatrix);
								} 
						 
						 




						 
							// Add Contact Tissue to Cell
							$sql = 'SELECT DISTINCT cct.tissue AS cctn, cct.cell_uid, cct.source_sheet FROM'.
							'  contact_cell_tissue AS cct'.
								' WHERE cct.cell_uid="'.$cellid.'" AND cct.source_sheet = "'.$orgname.'" ORDER BY cct.tissue';
								
																		
							$esql = executeSQL($sql,$conn,$mess);
							$contacttissuename = array();
							
						   
							
							if(!$esql)
									die($mess);
							else
								{
								  //echo mysql_fetch_array($esql);
								  while($newArray = mysql_fetch_array($esql))
									{ 
										//echo "gets here";
										$contacttissuename[]=$newArray[cctn];
										
									
									}
								}
															
							//echo sizeof($cellmatrix)."\n";
						
							//Loop to add Contact Matrix to Cell
							for($jj12=0;$jj12<sizeof($contacttissuename);$jj12++)
								{
								 $contacttissue = $xml->createElement("CellContactTissue");
								 $cttext = $xml->createTextNode($contacttissuename[$jj12]);
								 $contacttissue->appendChild($cttext);
								 $cell->appendChild($contacttissue);
								} 
			
							}  // Add Cell to Tissue
	
					
					}	 // End of TISSUE
	

					// Select Organ parts per organ
					$sql = 'SELECT DISTINCT pop.organ_part AS popn, pop.organ_uid, pop.organ_part_uid AS popid FROM part_of_organ_part_organ AS pop'.
					' WHERE pop.organ_uid = "'.$organid.'" ORDER BY pop.organ_part';
									
					$esql = executeSQL($sql,$conn,$mess);
					$organpartuid = array();
					$organpartname = array();
										
					if(!$esql)
						die($mess);
					else
					{
					  //echo mysql_fetch_array($esql);
					  while($newArray = mysql_fetch_array($esql))
						{ 
							//echo "gets here";
							$organpartuid[]=$newArray[popid];
							$organpartname[]=$newArray[popn];
							
						}
					}
					
					//echo $organpartname[0];
					// echo "\n";
					//echo sizeof($organpartuid);	
					
					
					
							
				// Loop thru Parts of organ
				for($j2=0;$j2<sizeof($organpartuid);$j2++)
					{
						$part = $xml->createElement('Part');
						$parttext = $xml->createTextNode($organpartname[$j2]);
						$part->appendChild($parttext);
						$org->appendChild($part);  // append part to org and org to sys
						$organpartid = $organpartuid[$j2];
						//echo $organpartid."--"."\n";									
				
						// Select Contact Organs to Parts	
						$sql = 'SELECT DISTINCT cop.organ_part_b AS copbn, cop.source_sheet, cop.organ_part_a_uid  FROM'.
						'  contact_organ_part_organ_part  AS cop'.
							' WHERE cop.source_sheet= "'.$orgname.'" AND cop.organ_part_a_uid="'.$organpartid.'"'.
							' ORDER BY cop.organ_part_b';
							
																	
						$esql = executeSQL($sql,$conn,$mess);
						$contactorganpartname = array();
						$contactorganpartuid = array();
					   
						
						if(!$esql)
								die($mess);
						else
							{
							  //echo mysql_fetch_array($esql);
							  while($newArray = mysql_fetch_array($esql))
								{ 
									//echo "gets here";
									$contactorganpartname[]=$newArray[copbn];
								
								
								}
							}
														
						//echo sizeof($contactorganpartname)."\n";
						
						//Add Contact Part elements to Part
							
							
						for($jj2=0;$jj2<sizeof($contactorganpartname);$jj2++)
							{
									 $contactorganpart = $xml->createElement("PartContactOrgan");
									 $contactorganparttext = $xml->createTextNode($contactorganpartname[$jj2]);
									 $contactorganpart->appendChild($contactorganparttext);
									 $part->appendChild($contactorganpart);
								
							}  // End of Add Contact Organs to Parts
						
					}  // End of Loop thru parts
					
					
					// Change to Contact Lumen
						// ------------------------------------------------------------------
						$sql = 'SELECT DISTINCT col.lumen AS coln, col.organ_uid, col.lumen_uid AS colid FROM'.
						'  contact_organ_lumen AS col'.
							' WHERE col.organ_uid="'.$organid.'" ORDER BY col.lumen';
							
																	
						$esql = executeSQL($sql,$conn,$mess);
						$contactlumenname = array();
						$contactlumenuid2 = array();
						   
						
						if(!$esql)
								die($mess);
						else
							{
							  //echo mysql_fetch_array($esql);
							  while($newArray = mysql_fetch_array($esql))
								{ 
									//echo "gets here";
									$contactlumenname[]=$newArray[coln];
									$contactlumenuid[]=$newArray[colid];
								
								}
							}
														
						//echo sizeof($contactlumen)."\n";
					
						//Add Contact Lumens to Organs
						for($jj6=0;$jj6<sizeof($contactlumen);$jj6++)
							{
							 $contactlumen = $xml->createElement("OrganContactLumen");
							 $cnlumentext = $xml->createTextNode($contactlumenname[$jj6]);
							 $contactlumen->appendChild($cnlumentext);
							 $organcontacts->appendChild($contactlumen);
							 $lumenid2 = $contactlumenuid[$jj6];
							
								
								
								// Select Connected Lumen to Contact Lumens
								// ------------------------------------------------------------------
								$sql = 'SELECT DISTINCT cll.lumen_b AS clln, cll.lumen_a_uid FROM'.
								'  connected_lumen_lumen AS cll'.
									' WHERE cll.lumen_a_uid="'.$lumenid2.'" ORDER BY cll.lumen_b';
									
																			
								$esql = executeSQL($sql,$conn,$mess);
								$connectedlumenname2 = array();
								$connectedlumenuid2 = array();
							   
								
								if(!$esql)
										die($mess);
								else
									{
									  //echo mysql_fetch_array($esql);
									  while($newArray = mysql_fetch_array($esql))
										{ 
											//echo "gets here";
											$connectedlumenname2[]=$newArray[clln];
										
										}
									}
																
								//echo sizeof($connectedlumenname2)."\n";
							
								//Add Connected Lumen element to Lumen
								for($jj7=0;$jj7<sizeof($connectedlumenname2);$jj7++)
									{
									 $connectedlumen2 = $xml->createElement("LumenConnectedLumen");
									 $clumentext2 = $xml->createTextNode($connectedlumenname2[$jj7]);
									 $connectedlumen2->appendChild($clumentext2);
									 $contactlumen->appendChild($connectedlumen2);
												
									}  // End of Connected Lumens to Lumens
	
							}  // End of Contact Lumens to Parts
				
	
			} // End of Loop thru organs
			

	}  // Loop thru organ systems
	
echo "gets done";	
echo '--Wrote: ' . $xml->save("oro_xml4.xml") . ' bytes';	
// end of build xml file



?>
</body>
</html>
