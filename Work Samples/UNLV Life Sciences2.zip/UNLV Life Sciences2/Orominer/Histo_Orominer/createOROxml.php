<html>
<head>
<title>Create Orominer XML File</title>
</head>
<body>
<?php
// This program generates the oro_xml XML database file which the orominer_histo_latest program runs from.  It uses php MySQL queries to create 
// XML file from databases.  Note:  Dashes need to be replaced with underscores in database table names.

function connectToMySQL($server,$user,$pssword,&$message)
{
   $isConnected ="Connection Made";
   if($conn = mysql_connect($server,$user,$pssword))
     {
       $message = $isConnected;
       return $conn;
     }

   else
    {
    $message ='Could not connect: ' . mysql_error();
    return NULL;
    }
}


function executeSQL($sql,$conn,&$message)
{
//execute SQL
$querySucceeded = "Query succeeded";

if($result = mysql_query($sql,$conn))
   {
   $message = $querySucceeded;
   return $result;
   }
else 
   {
   $message= "<br/>Query error: ". mysql_error();
   return NULL;
   }
}


$conn=connectToMySQL("localhost","root","root",$mess);  //connect to MySQL
mysql_select_db("orominer");
 
$xml = new DOMDocument('1.0');
$xml->formatOutput = true;

$top = $xml->createElement('top');  // create root element
$top = $xml->appendChild($top);


// Select Organ Systems
$sql = 'SELECT DISTINCT organ_system_name, organ_system_uid  FROM organ_system  WHERE organ_system_uid <> 0 ORDER BY organ_system_name  ';

$esql = executeSQL($sql,$conn,$mess);
$organsystemuid = array();
$organsystemname = array();
$osuidmax = array();


if(!esql)
	die($mess);
else
{
 while($newArray = mysql_fetch_array($esql))
   { 
   $organsystemuid[]=$newArray[organ_system_uid];
   $organsystemname[] = $newArray[organ_system_name];
   //$osuidmax[]= $newArray[osidmax];
  
	}
}


//  Loop thru Organ Systems in building XML File
$organsubpartid = 0;
$organlayerid = 0;
$hislayerid = 0;
$hissublayerid = 0;
$hischarid = 0;
for($i=0;$i < sizeof($organsystemuid);$i++)
	{
	      
		 $sys = $xml->createElement('System');
		 $in = (int)$i;
		 $sysname = $xml->createTextNode($organsystemname[$in]);
		 $sys->appendChild($sysname);
		 $top->appendChild($sys);
		 
		 // Selecting Organs for each particular Organ System
	     $sql = 'SELECT DISTINCT o.organ_name AS oname, do.organ_uid AS doid '.
				' FROM defined_organ AS do, organ AS o WHERE (do.organ_system_uid = "'.$organsystemuid[$i].'"'.
				' AND (o.organ_uid = do.organ_uid)) ORDER BY o.organ_name';    
		
		 $esql = executeSQL($sql,$conn,$mess);

		 $organuid = array();
		 $organname = array();
		 $osid = $organsystemuid[$i];
		
		
		
		
		 if(!$esql)
			die($mess);
		 else
		 {
		
		  while($newArray = mysql_fetch_array($esql))
			{ 
			$organname[]=$newArray[oname];
			$organuid[]=$newArray[doid];
			}
		 }
		 
	
		 // Loop through Organs
		for($j=0;$j<sizeof($organuid);$j++)
			{
			  
				$org = $xml->createElement("Organ");
				$orgtext = $xml->createTextNode($organname[$j]);
				$org->appendChild($orgtext);
				$sys->appendChild($org);
				
				$organid = $organuid[$j];
													
			   // Select Organ Layers 
				$sql = 'SELECT DISTINCT ol.organ_layer_name AS oln, dol.organ_layer_uid AS dolid FROM defined_organ_layer AS dol, organ_layer AS ol '.
				' WHERE dol.organ_uid = "'.$organid.'" AND ol.organ_layer_uid=dol.organ_layer_uid ORDER BY ol.organ_layer_name';
				
				$organlayername = array();
				$organlayeruid = array();
				
				$esql = executeSQL($sql,$conn,$mess);
				if(!$esql)
					die($mess);
				else
				 {
				
				 
				  $text = "";
				  while($newArray = mysql_fetch_array($esql))
						{
						$organlayername[]=$newArray[oln];
						$organlayeruid[]=$newArray[dolid];
						}
				 }
			
				// Add Organ Layer Element to Organ
				for($jj=0;$jj<sizeof($organlayername);$jj++)
					{
						$organlayer = $xml->createElement("Organ_Layer");
						$oltext = $xml->createTextNode($organlayername[$jj]);
						$organlayer->appendChild($oltext);
						$org->appendChild($organlayer);
		
						$organlayerid = $organlayeruid[$jj];
						
					
					}	 // End of Organ Layer		 

					// Select Organ parts per organ
					$sql = 'SELECT DISTINCT op.organ_part_name AS opn, dop.organ_uid, dop.organ_part_uid AS dopopid FROM defined_organ_part AS dop, organ_part AS op'.
					' WHERE dop.organ_uid = "'.$organid.'" AND op.organ_part_uid=dop.organ_part_uid AND dop.organ_part_uid <> 0 ORDER BY op.organ_part_name';
									
					$esql = executeSQL($sql,$conn,$mess);
					$organpartuid = array();
					$organpartname = array();
										
					if(!$esql)
						die($mess);
					else
					{
					
					  while($newArray = mysql_fetch_array($esql))
						{ 
							
							$organpartuid[]=$newArray[dopopid];
							$organpartname[]=$newArray[opn];
							
						}
					}
					
				
							
				// Loop thru Parts of organ
				for($j2=0;$j2<sizeof($organpartuid);$j2++)
					{
						$part = $xml->createElement('Part');
						$parttext = $xml->createTextNode($organpartname[$j2]);
						$part->appendChild($parttext);
						$org->appendChild($part);  // append part to org and org to sys
						$organpartid = $organpartuid[$j2];
					
						// Select SubParts			
						$sql = 'SELECT DISTINCT osp.organ_subpart_name AS ospn, dop.organ_subpart_uid AS dopospid FROM'.
						'  defined_organ_part AS dop, organ_subpart AS osp'.
							' WHERE dop.organ_part_uid="'.$organpartid.'" AND dop.organ_uid="'.$organid.
							'" AND (osp.organ_subpart_uid = dop.organ_subpart_uid ) ORDER BY osp.organ_subpart_name';
							
																	
						$esql = executeSQL($sql,$conn,$mess);
						$organsubpartname = array();
						$organsubpartuid = array();
					   
						
						if(!$esql)
								die($mess);
						else
							{
							 
							  while($newArray = mysql_fetch_array($esql))
								{ 
									
									$organsubpartname[]=$newArray[ospn];
									$organsubpartuid[]=$newArray[dopospid];
									//$organsubpartuid[]=$newArray[dhlospid];
								}
							}
														
					
						
						//Add Sub Part elements to Part
						for($jj2=0;$jj2<sizeof($organsubpartname);$jj2++)
							{
							 $osubpart = $xml->createElement("Subpart");
							 $osubparttext = $xml->createTextNode($organsubpartname[$jj2]);
							 $osubpart->appendChild($osubparttext);
							 $part->appendChild($osubpart);
							
							 $organsubpartid = $organsubpartuid[$jj2];	 
						
							//Select Histological Layer
							$sql='SELECT DISTINCT hl.hist_layer_name AS hln, dhl.hist_layer_uid AS dhlid FROM defined_hist_layer AS dhl, hist_layer AS hl'.
							' WHERE dhl.organ_part_uid = "'.$organpartid.'"'.
							' AND dhl.organ_subpart_uid = "'.$organsubpartid.'" AND hl.hist_layer_uid = dhl.hist_layer_uid'.
							' AND dhl.hist_layer_uid <> 0 ORDER BY hl.hist_layer_name';
					 
						
							
							$esql = executeSQL($sql,$conn,$mess);
							$histolayerid = array();
							$histolayername = array();
													
							if(!$esql)
										die($mess);
								else
									{
									 
									  while($newArray = mysql_fetch_array($esql))
										{ 
											
											$histolayerid[]=$newArray[dhlid];
											$histolayername[]=$newArray[hln];
										}
									}	 
									 
								 // Add histological layer to Subpart
							
								 for($jj3=0;$jj3<sizeof($histolayername);$jj3++)
									{
										// Add histological layer to Part
										$histolayer = $xml->createElement("histo_Layer");
										$hlayernametext = $xml->createTextNode($histolayername[$jj3]);
										$histolayer->appendChild($hlayernametext);
										$hislayerid = $histolayerid[$jj3];
										
										if($organsubpartid == 0)
											$part->appendChild($histolayer);
										else											
											$osubpart->appendChild($histolayer);
										
										// Query for selecting histological sublayer
										$sql = 'SELECT MAX(dhsl.hist_sublayer_uid) AS mx FROM defined_hist_sublayer AS dhsl';
							
										$esql = executeSQL($sql,$conn,$mess);
										$maxhistslid = 0;
									
										if(!$esql)
												die($mess);
										else
												$row = mysql_fetch_object($esql);
									
										$maxhistslid = $row->mx;
																								
										// Select histological sublayer
										$sql = 'SELECT DISTINCT hsl.hist_sublayer_name AS hsln, dhsl.hist_sublayer_uid dhslid  '.
											' FROM defined_hist_sublayer AS dhsl, hist_sublayer AS hsl'.
											' WHERE dhsl.hist_layer_uid = "'.$hislayerid.'"'.
											' AND dhsl.organ_uid="'.$organid.'" AND dhsl.hist_layer_uid = "'.$hislayerid.'"'. 
											' AND (hsl.hist_sublayer_uid=dhsl.hist_sublayer_uid ) '.
											' AND dhsl.hist_sublayer_uid <> 0 ORDER BY hsl.hist_sublayer_name';
																									
											$esql = executeSQL($sql,$conn,$mess);
											$histosublayername = array();
											$histosublayeruid = array();
											if(!$esql)
													die($mess);
											else
												{
												
												  while($newArray = mysql_fetch_array($esql))
													{ 
														
														$histosublayername[]=$newArray[hsln];
														$histosublayeruid[]=$newArray[dhslid];
													}
												}	 
										
											$sofhsln = sizeof($histosublayeruid);
											
											// Add histological sublayer to Part
											  
												for($jj4=0;$jj4<$sofhsln;$jj4++)
													{  
														$histosublayer = $xml->createElement("histo_Sublayer");
														$hsublayertext = $xml->createTextNode($histosublayername[$jj4]);
														$histosublayer->appendChild($hsublayertext);
														$histolayer->appendChild($histosublayer);
														$hissublayerid = $histosublayeruid[$jj4];
																	
											
														// Add histo Char to SubPart
														$sql = 'SELECT DISTINCT hc.hist_char_name AS hcn, dhc.hist_char_uid AS dhcid FROM defined_hist_char AS dhc, hist_char AS hc'.
															' WHERE dhc.hist_layer_uid="'.$hislayerid.'" AND dhc.hist_sublayer_uid="'.$hissublayerid.
															'" AND dhc.hist_char_uid <> 0 AND hc.hist_char_uid = dhc.hist_char_uid';
															
														$esql = executeSQL($sql,$conn,$mess);
														$histocharname = array();
														$histocharuid = array();
														
														if(!$esql)
																die($mess);
														else
															{
															  
															  while($newArray = mysql_fetch_array($esql))
																{ 
																	$histocharname[]=$newArray[hcn];
																	$histocharuid[]=$newArray[dhcid];
																}
															}	 
														$szofhcid = sizeof($histocharname);
														
														//Add Histological Char to SubPart
														for($jj5=0;$jj5<$szofhcid;$jj5++)
																{
																		//Add histo char layer to histo sublayer
																			$histochar = $xml->createElement("histo_Char");
																			$hchartext = $xml->createTextNode($histocharname[$jj5]);
																			$histochar->appendChild($hchartext);
																			$histosublayer->appendChild($histochar);
																			$hischarid = $histocharuid[$jj5];
																			
																			
																			//Select Extracellular matrix for Histology
																		$sql='SELECT DISTINCT ecm.ecell_matrix_name AS ecmn, decm.hist_layer_uid, decm.hist_sublayer_uid, decm.hist_char_uid FROM defined_ecell_matrix AS decm, '.
																		' ecell_matrix AS ecm WHERE decm.hist_layer_uid = "'.$hislayerid.'" AND decm.hist_sublayer_uid="'.$hissublayerid.
																		'" AND decm.hist_char_uid = "'.$hischarid.'" AND ecm.ecell_matrix_uid=decm.ecell_matrix_uid AND ecm.ecell_matrix_uid <> 0';

																		$esql = executeSQL($sql,$conn,$mess);
																		
																		$ecellmatrixname = array();
																		if(!$esql)
																				die($mess);
																		else
																			{
																			 
																			  while($newArray = mysql_fetch_array($esql))
																				{ 
																					
																					$ecellmatrixname[]=$newArray[ecmn];
																				}
																			}	
																			
																	
																		$ecmsz = sizeof($ecellmatrixname);
																		for($jj7=0;$jj7<$ecmsz;$jj7++)
																			{
																				
																				$ecellmatrix = $xml->createElement("Ecell_Matrix");
																				$ecmtext = $xml->createTextNode($ecellmatrixname[$jj7]);
																				$ecellmatrix->appendChild($ecmtext);
																				$histochar->appendChild($ecellmatrix);
																			}
																			
																			
																		// Get cells 
																		// Add Celltype to Part
																		$sql='SELECT DISTINCT dct.cell_type_uid, dct.hist_layer_uid, dct.hist_sublayer_uid, dct.hist_char_uid, ct.cell_type_name AS ctn, dct.organ_system_uid'.
																		' FROM defined_cell_type AS dct, cell_type AS ct'.
																			' WHERE dct.organ_system_uid = "'.$osid.'" AND dct.organ_uid="'.$organid.'"'.
																			' AND dct.hist_layer_uid = "'.$hislayerid.'" AND dct.hist_sublayer_uid = "'.$hissublayerid.'"'.
																			' AND dct.hist_char_uid = "'.$hischarid.'"'.
																			' AND ct.cell_type_uid = dct.cell_type_uid AND ct.cell_type_uid <> 0 ORDER BY ct.cell_type_name';
																		
																		set_time_limit(120);   
																		$esql = executeSQL($sql,$conn,$mess);
																		$celltypename = array();
																		if(!$esql)
																				die($mess);
																		else
																			{
																			  
																			  while($newArray = mysql_fetch_array($esql))
																				{ 
																					
																					$celltypename[]=$newArray[ctn];
																				}
																			}	 
																	
																		
																		//append cells to Parts
																		for($jj6=0;$jj6<sizeof($celltypename);$jj6++)
																			{
																				$cell = $xml->createElement("Cell");
																				$celltext = $xml->createTextNode($celltypename[$jj6]);
																				$cell->appendChild($celltext);
																				$histochar->appendChild($cell);
																									
																			}	// End of append cells to Parts		
																			
																}  // End of Histological Characteristics
											
													}  // End of add Histological Sublayer to Part 
																
									}  // End of add Histological Layer to Part
							
							}  // End of SubParts
					
					}  // End of Loop thru parts

										
			} // End of Loop thru organs
						
        
	}  // Loop thru organ systems
	
echo "gets done";	
echo '--Wrote: ' . $xml->save("oro_xml.xml") . ' bytes';	
// end of build xml file



?>
</body>
</html>
